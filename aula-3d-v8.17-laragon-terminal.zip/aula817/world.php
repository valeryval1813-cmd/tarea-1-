<?php
declare(strict_types=1);
require_once __DIR__ . '/config/auth.php';
$user = require_login();
$scenarioId = filter_input(INPUT_GET, 'scenario', FILTER_VALIDATE_INT);
$pdo = db();
if (!$scenarioId || $scenarioId < 1 || !can_access_scenario($pdo, (int)$scenarioId, $user)) {
    http_response_code(403);
    exit('Selecciona un escenario asignado desde el portal para entrar al mundo virtual.');
}
$stmt = $pdo->prepare('SELECT id,name FROM scenarios WHERE id=?');
$stmt->execute([$scenarioId]);
$scenario = $stmt->fetch();
if (!$scenario) { http_response_code(404); exit('Escenario no encontrado.'); }
?>
<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#101d2c"><title>Campus virtual SENATI | Aula 3D</title>
<style>
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#101d2c;font-family:Inter,Segoe UI,system-ui,sans-serif;color:#fff}#world{position:fixed;inset:0}#world canvas{display:block;width:100%;height:100%;outline:none;touch-action:none}.topbar{position:fixed;z-index:5;top:16px;left:18px;right:18px;display:flex;align-items:center;gap:14px;pointer-events:none}.brand,.online,.help,.back{pointer-events:auto;background:#101d2ce8;border:1px solid #ffffff24;backdrop-filter:blur(14px);box-shadow:0 10px 35px #0003;border-radius:13px}.brand{padding:10px 14px;display:flex;align-items:center;gap:10px}.logo{width:35px;height:35px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,#0878c9,#20b6c7);font-weight:950}.brand b{display:block;font-size:13px}.brand small{display:block;color:#a9c0d4;font-size:10px;margin-top:2px}.spacer{flex:1}.online{padding:11px 14px;font-size:12px;color:#d9eafa}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#38d996;margin-right:7px;box-shadow:0 0 12px #38d996}.back{padding:11px 14px;color:white;text-decoration:none;font-size:12px;font-weight:800}.help{position:fixed;left:18px;bottom:18px;z-index:5;padding:13px 15px;color:#d9eafa;font-size:11px;line-height:1.7;max-width:245px}.help b{color:#fff}.chat{position:fixed;right:18px;bottom:18px;z-index:6;width:min(350px,calc(100vw - 36px));height:330px;display:flex;flex-direction:column;background:#101d2cf0;border:1px solid #ffffff26;border-radius:16px;backdrop-filter:blur(15px);box-shadow:0 16px 50px #0005;overflow:hidden}.chathead{padding:12px 14px;border-bottom:1px solid #ffffff18;font-size:12px;font-weight:850;display:flex;justify-content:space-between}.chatbody{flex:1;overflow:auto;padding:10px 12px;display:flex;flex-direction:column;gap:8px}.msg{font-size:12px;line-height:1.4;overflow-wrap:anywhere}.msg b{color:#75d9f0;margin-right:5px}.msg.system{color:#9eb4c7;font-style:italic}.chatform{display:flex;gap:7px;padding:10px;border-top:1px solid #ffffff18}.chatform input{min-width:0;flex:1;background:#1c3045;border:1px solid #36506a;border-radius:9px;padding:10px;color:white;outline:none}.chatform button{border:0;border-radius:9px;background:#087fc5;color:#fff;font-weight:850;padding:0 14px;cursor:pointer}.notice{position:fixed;left:50%;top:82px;transform:translateX(-50%);z-index:8;background:#101d2ceF;border:1px solid #ffffff30;border-radius:12px;padding:10px 15px;color:#fff;font-size:12px;box-shadow:0 10px 35px #0005}.notice[hidden]{display:none}.mobile-chat{display:none}@media(max-width:650px){.topbar{top:8px;left:8px;right:8px;gap:6px}.brand{padding:8px}.online{padding:9px;font-size:10px}.back{padding:9px;font-size:10px}.help{left:8px;bottom:8px;font-size:10px;max-width:180px}.chat{right:8px;bottom:8px;width:calc(100vw - 16px);height:245px}.chat.collapsed{height:42px}.chat.collapsed .chatbody,.chat.collapsed .chatform{display:none}.mobile-chat{display:block;border:0;background:transparent;color:#fff;font-weight:900;cursor:pointer}}
</style></head><body>
<div id="world"></div>
<header class="topbar"><div class="brand"><div class="logo">3D</div><div><b>CAMPUS VIRTUAL SENATI</b><small><?=h($scenario['name'])?> · Bienvenido, <?=h($user['name'])?></small></div></div><div class="spacer"></div><div class="online"><span class="dot"></span><span id="online-count">Conectando…</span></div><a class="back" href="./portal.php">Salir al portal</a></header>
<div class="notice" id="connection-notice">Cargando escenario compartido…</div>
<script>window.AULA_WORLD_SCENARIO_ID = <?= (int)$scenarioId ?>;</script>
<div class="help"><b>CONTROLES</b><br>W A S D / Flechas · Caminar<br>Mouse arrastrado · Girar cámara<br>Enter · Escribir en el chat<br>Acércate a otros usuarios para encontrarte con ellos.</div>
<section class="chat" id="chat"><div class="chathead"><span>CHAT DEL CAMPUS · TODOS</span><button class="mobile-chat" id="chat-toggle" type="button">Minimizar</button></div><div class="chatbody" id="chat-messages"><div class="msg system">Bienvenido al campus. Los mensajes se muestran a los usuarios conectados.</div></div><form class="chatform" id="chat-form"><input id="chat-input" maxlength="240" autocomplete="off" placeholder="Escribe un mensaje…"><button type="submit">Enviar</button></form></section>
<script type="module" src="./public/assets/world-client.js?v=2"></script>
</body></html>
