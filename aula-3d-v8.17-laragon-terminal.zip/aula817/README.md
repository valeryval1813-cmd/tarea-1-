# Editor de escenarios 3D — PHP + MySQL + Three.js

**Versión 1.7.9 · SENATI Torre ampliada, aulas distribuidas y ascensores interactivos**

Esta versión incorpora una interfaz clara inspirada en el concepto visual SENATI: barra superior azul y blanca, biblioteca de objetos con miniaturas 3D, herramientas flotantes sobre el visor, configuración a la derecha y una plantilla de aula de cómputo como escena inicial. Incluye miniaturas WebP locales (sin depender de imágenes remotas), vistas rápidas, puertas y ventanas acristaladas, iluminación de aula y alumnos con polo SENATI.

> Importante: las miniaturas de la biblioteca son imágenes ilustrativas. Los objetos y personajes colocados en el escenario siguen siendo geometría 3D de Three.js; no son modelos GLB fotorrealistas. El visor sigue siendo interactivo y no utiliza una captura estática como fondo.

El proyecto pasa de un aula fija a un **editor para construir escenarios desde cero**. El usuario define ancho, largo y altura; después coloca objetos desde una biblioteca, los mueve, rota, duplica, elimina y guarda en MySQL.

> PHP gestiona la aplicación y la persistencia. Three.js continúa siendo JavaScript porque es el motor 3D que renderiza y permite manipular los objetos en el navegador.

## Novedades de esta versión (Aula 3D v8.14)

- La plantilla **SENATI Torre 1** amplía el campus conceptual a 220 × 180 m y conserva tres bloques, dos sótanos, dos bloques laterales de diez pisos y un bloque central de once pisos.
- Se modelan aulas y talleres conceptuales por nivel con mobiliario básico, pasadizos, divisiones interiores y núcleos de circulación. La distribución interior no es un plano oficial.
- Las escaleras conectan niveles consecutivos mediante dos tramos y un descanso; el recorrido en primera y tercera persona acompaña la altura y bloquea el acceso lateral al hueco.
- Los seis ascensores tienen pozos cerrados, puertas de rellano y cabinas animadas. En recorrido, acércate al ascensor y pulsa **E**. El panel permite seleccionar el piso con el menú o con **↑ / ↓**; confirma con **Viajar** o **ENTER**. La cabina llega, abre puertas, permite abordar, se desplaza con aceleración/deceleración suave y permite salir en destino. Los bloques laterales llegan hasta el piso 10; el bloque central llega al piso 11.
- Se reforzaron las colisiones contra fachadas, muros interiores, columnas, mobiliario fijo, laterales de escaleras y cerramientos de ascensores. Las puertas de los ascensores dejan de bloquear el vano al abrirse.
- El exterior incorpora pista, veredas, plaza peatonal, demarcación vial, jardineras y luminarias. La biblioteca añade objetos modulares de mayor tamaño: **Pista asfaltada** (20 × 6.4 m), **Piso exterior** (10 × 10 m) y **Vereda peatonal** (12 × 3 m), para ampliar el mundo.
- El núcleo de escaleras deja libres las conexiones entre plantas y ahora tolera el paso real del usuario entre peldaños, descanso y tramo opuesto; se corrigió el inicio demasiado temprano de la transición.
- La cabina de ascensor permite llamar, seleccionar el nivel servido por el bloque, abordar, viajar con transición suave y salir. Los vanos quedan transitables únicamente mientras las puertas están abiertas.
- El recorrido bloquea fachadas, muros interiores, columnas y cerramientos del hueco; las piezas de pista, pavimento y vereda son superficies transitables y se encuentran agrupadas en **Biblioteca → Mundo exterior**.
- El campus se presenta como un mundo virtual conceptual de 220 × 180 m, con tres bloques, aulas/talleres por planta, plaza, calles, pista, veredas, árboles y luminarias. Se pueden añadir módulos de pista, piso y vereda desde la biblioteca.
- Cada bloque organiza seis espacios por nivel (tres aulas/talleres por ala) alrededor de un pasadizo central de 6 m; se incluyen rótulos de ambientes, accesos y mobiliario distribuido en las aulas.
- Los ascensores se representan mediante seis cabinas visibles dentro de pozos con puertas de rellano, paneles y guías; durante el recorrido se puede llamar la cabina, viajar al piso permitido y salir al llegar.
- No requiere migración SQL. La información sigue guardándose en los campos JSON existentes de escenarios.

**Alcance:** el modo Recorrer permite explorar la torre y usar escaleras/ascensores. La evacuación automática multibloque y multinivel sigue deshabilitada hasta implementar y validar un grafo de rutas específico; no se debe interpretar esta plantilla como un plano ni una evaluación de seguridad oficial.

## Requisitos

- PHP 8.1 o superior.
- MySQL 8.0 o MariaDB compatible.
- Extensión PHP `pdo_mysql` habilitada.
- Node.js 20 o superior y npm para compilar el frontend Three.js.
- Laragon o XAMPP recomendado en Windows.

## Instalación en Windows con Laragon

1. Copia la carpeta `editor-escenarios-3d` dentro de `C:\laragon\www\`.
2. Inicia Apache y MySQL desde Laragon.
3. Abre phpMyAdmin e importa `database/schema.sql`.
   - El script crea la base de datos `aula3d`.
   - Crea las tablas `scenarios`, `scenario_objects`, `object_catalog`, `users` y `scenario_user_access`.
4. Abre una terminal dentro de la carpeta del proyecto y ejecuta:

```bash
npm install
npm run build
```



5. Abre el proyecto en el navegador y crea la cuenta administradora inicial:

```text
http://localhost/editor-escenarios-3d/first-admin.php
```

Crea el primer administrador. La página se bloquea automáticamente cuando ya existe una cuenta administradora. Después inicia sesión desde `login.php`.

### Alternativa sin Laragon

Después de importar la base de datos y compilar el frontend, ejecuta:

```bash
php -S 127.0.0.1:8000
```

Luego abre `http://127.0.0.1:8000`.



## Conexión MySQL

La configuración está en `config/database.php`. Los valores por defecto son:

| Parámetro | Valor |
|---|---|
| Host | `127.0.0.1` |
| Base de datos | `aula3d` |
| Usuario | `root` |
| Contraseña | vacía |

Puedes definir `AULA_DB_HOST`, `AULA_DB_NAME`, `AULA_DB_USER` y `AULA_DB_PASS` como variables de entorno para usar otras credenciales. No publiques credenciales reales.

Si aparece un error de conexión, comprueba que MySQL esté iniciado, que importaste `database/schema.sql` y que PHP tenga habilitada la extensión `pdo_mysql`.


## Acceso, perfiles y permisos

- `login.php`: inicio de sesión con contraseña cifrada mediante `password_hash` / `password_verify`.
- `first-admin.php`: configuración de la primera cuenta administradora; solo permite crearla si todavía no existe ningún administrador.
- `admin.php`: gestión de usuarios, activación/desactivación de cuentas, roles, restablecimiento de contraseñas y asignación de escenarios.
- `portal.php`: portal para usuarios. Muestra únicamente los escenarios asignados a la cuenta.
- `simulador.php?portal=1&scenario=ID`: visor simplificado para entrar al escenario en primera persona. Para cambiar de escenario, pulsa `ESC` y vuelve al portal para elegir otro.
- `index.php`: editor reservado a administradores. Solo los administradores pueden guardar o eliminar escenarios.
- `api/scenarios.php`: valida sesión, rol, permisos por escenario y token CSRF en operaciones de escritura.

### Base de datos: un solo SQL

La carpeta `database` contiene únicamente `schema.sql`. Para una instalación nueva, impórtalo una sola vez desde phpMyAdmin; crea `aula3d` y todas las tablas necesarias, incluyendo apariencia, usuarios y permisos.

Si ya vienes de una versión anterior y tu base `aula3d` funciona con login, usuarios y escenarios, **no importes el SQL otra vez**: conserva la base existente. Esta actualización no requiere migraciones adicionales.

### Flujo recomendado

1. Inicia sesión como administrador.
2. Entra a **Administración**, crea las cuentas de los usuarios y marca qué escenarios pueden recorrer.
3. El usuario entra por `login.php` y llega directamente a su portal de escenarios.
4. Selecciona **Entrar a recorrer**. Al salir con `ESC`, volverás al portal para elegir otro escenario.

Los usuarios normales no tienen acceso al editor y la API rechaza modificaciones aunque intenten enviar peticiones manuales. Los administradores tienen acceso automático a todos los escenarios.

## Cómo usar el editor

1. Define ancho, largo y altura del ambiente.
2. Pulsa **Crear / actualizar escenario**.
3. Elige una categoría en la biblioteca izquierda.
4. Arrastra un objeto al piso o selecciónalo y haz clic en el lugar donde quieres colocarlo.
5. Selecciona un objeto para editar sus coordenadas, escala y rotación desde el inspector derecho.
6. Usa duplicar o eliminar para organizar el ambiente.
7. Escribe el nombre del escenario y pulsa **Guardar**.
8. Para recuperar un diseño, selecciónalo en **Escenarios guardados**. Se abrirá automáticamente y aparecerá una pantalla de carga que bloquea los demás controles mientras se prepara.

### Herramientas

- Ratón: orbitar y acercar/alejar la cámara.
- Arrastrar un objeto ya colocado: moverlo por el piso.
- `R`: rotar el objeto seleccionado 45 grados.
- `Supr`: eliminar el objeto seleccionado.
- `Escape`: cancelar el modo de colocación.
- Botón **Superior**: vista cenital.
- Botón **Techo**: mostrar u ocultar una cubierta visual.
- Botón **Cuadrícula**: mostrar u ocultar la cuadrícula del piso.

## Personalización visual
- Tipos de piso: cerámico cuadrado, madera, concreto pulido y alfombra.
- Colores editables: piso, paredes, escritorios y sillas.
- La apariencia se guarda en `scenarios.appearance_json`.
- En instalaciones existentes que ya usan el portal y autenticación, no se requiere importar SQL adicional.

## Plantilla basada en el aula original
La plantilla `Aula SENATI (Default)` crea un laboratorio de cómputo de 20 × 12 m con muros blancos y zócalo azul, ventanales transparentes, puerta acristalada, pizarra y marca SENATI, profesor con terno, 24 estaciones individuales con alumnos sentados, equipos All-in-One XL, teclados y mouse. Las luminarias se distribuyen por el aula y la cámara se ajusta para encuadrar el salón completo.

## Biblioteca inicial

- **Mobiliario:** escritorio individual y silla giratoria.
- **Computación:** PC All-in-One de 27 pulgadas con teclado y mouse automáticos, teclado y mouse.
- **Personas:** alumnos y alumnas con polo SENATI, versiones casuales, profesor y profesora con vestimenta formal.
- **Arquitectura:** pared, puerta de vidrio, ventana y pizarra. Las miniaturas del catálogo usan imágenes WebP locales; no requieren conexión a Internet.
- **Equipamiento:** fluorescente, ventilador, proyector y planta.

Los objetos son modelos geométricos iniciales construidos localmente con Three.js. Se pueden sustituir posteriormente por modelos 3D GLB/GLTF de mayor realismo.

## Escritorios independientes: regla del proyecto

La plantilla **Crear aula SENATI de ejemplo** crea cada escritorio mediante una instancia independiente. Cada escritorio tiene su propio identificador, posición, rotación y escala; los All-in-One, teclados, mouse y sillas también son objetos independientes.

Por tanto:
- No se crea una mesa gigante por fila.
- Cada escritorio se puede mover o rotar sin mover los demás.
- Los escritorios pueden quedar pegados visualmente, pero siguen siendo registros independientes.
- La plantilla sirve como punto de partida; el usuario puede reorganizar los objetos.

## Persistencia de escenarios

- `scenarios`: nombre y dimensiones del ambiente.
- `scenario_objects`: catálogo de objeto, identificador, posición, rotación, escala y configuración JSON.
- `object_catalog`: catálogo inicial de objetos y categorías.

El guardado se realiza mediante `api/scenarios.php` con PDO y consultas preparadas. Cada escenario se guarda en una transacción y sus objetos se relacionan mediante clave foránea.

## Estructura principal

```text
aula-3d/
├── index.php
├── api/
│   └── scenarios.php
├── config/
│   ├── auth.php
│   └── database.php
├── login.php
├── first-admin.php
├── admin.php
├── portal.php
├── logout.php
├── database/
│   └── schema.sql
├── src/
│   ├── editor.js
│   └── editor.css
├── public/
│   └── assets/              # generado por npm run build
├── legacy/                  # versión anterior del aula prediseñada
├── package.json
├── vite.config.js
└── package.json
```

## Alcance de esta primera versión

El núcleo del editor incorpora biblioteca de objetos, dimensiones configurables, selección, arrastre, transformación básica, plantillas y persistencia PHP/MySQL. La autenticación y los permisos multiusuario se describen en la sección de acceso de esta versión. La carga de modelos 3D externos y el historial de versiones quedan fuera del alcance actual.


## Versión 3: objetos mejorados y recorrido
- Al colocar una PC All-in-One de 27 pulgadas se crean automáticamente teclado y mouse como objetos independientes. Al borrar la PC se eliminan también sus accesorios vinculados.
- Ventilador reconstruido con soporte, eje, motor central y tres aspas conectadas a un rotor; las aspas giran de forma continua.
- Personajes reconstruidos con proporciones más naturales, cabeza, rostro, cuello, torso, extremidades articuladas, calzado y ropa diferenciada.
- Modos **1.ª persona** y **3.ª persona** para recorrer el aula. En ambos, WASD/flechas mueven al usuario y el mouse controla la mirada; ESC permite volver al editor. El modo en tercera persona muestra un avatar que acompaña el movimiento y mantiene los límites, colisiones y transición por escaleras.
- Los accesorios de cada PC se guardan en `config_json` para conservar su vínculo al guardar y volver a abrir escenarios.

## Próximas fases del simulador
1. Editor de animaciones por puntos y tiempos: el profesor entra por la puerta, recorre una ruta y se sienta.
2. Sistema de eventos de riesgo: activar una alarma y una escena de incendio simulado sin peligro real.
3. Simulación de evacuación: señalizar salidas, mostrar rutas seguras, permitir que el usuario camine hacia la salida y registrar si completa el recorrido.
4. Personajes y mobiliario con modelos GLB de mayor fidelidad y animaciones de biblioteca (caminar, sentarse, gestos). La versión actual mejora los modelos procedurales, pero no pretende ser todavía una simulación humana fotorrealista.


## Mejoras de interfaz y estaciones informáticas (v1.2.0)

- Interfaz clara en tonos blancos y grises, con acentos azules suaves.
- Paneles laterales redimensionables arrastrando sus separadores; también pueden contraerse y volver a mostrarse desde la barra del escenario.
- Opción **Equipar escritorios**: al activarla, los escritorios existentes y los nuevos reciben automáticamente una PC All-in-One, teclado y mouse. Al desactivarla, se retiran esos tres elementos y los escritorios quedan vacíos.
- La base de la All-in-One se apoya sobre la superficie del escritorio y el mouse queda junto al teclado.
- Personajes rediseñados con siluetas más redondeadas, cabeza, cabello, manos, ropa y calzado con volúmenes más suaves. Son modelos procedurales; para alcanzar un acabado de videojuego aún más avanzado se recomienda incorporar personajes GLB riggeados.

No requiere cambios en el esquema MySQL: las estaciones se guardan como objetos vinculados dentro de la estructura de objetos existente.


## Importante: recompilar después de actualizar

Esta versión comprueba que `public/assets/editor.js` y `public/assets/editor.css` correspondan al código fuente actual. Si detecta archivos antiguos, muestra una pantalla de aviso en lugar de abrir un editor desalineado o con el visor 3D en negro.

Después de reemplazar el proyecto, ejecuta `COMPILAR-FRONTEND.bat` una vez y espera a que indique que la compilación terminó correctamente. Luego recarga `localhost` con `Ctrl + F5`. No reutilices los archivos compilados de una versión anterior.


## Versión 1.2.2 — correcciones de personajes y distribución

- Personajes con cuello anatómico más estrecho, cabeza integrada y articulaciones suaves.
- Profesor visualmente diferenciado mediante chaqueta, camisa, corbata, credencial y gafas.
- Nueva opción **Llenar asientos**: agrega o retira personas sentadas en las sillas; se guarda su estado en `config_json`.
- Al llenar el aula SENATI, los estudiantes se orientan hacia la pizarra y se sientan en sus sillas.
- **Equipar escritorios** detecta la silla más cercana para identificar el lado del alumno y orientar correctamente monitor, teclado y mouse. Si todavía no hay silla, usa una orientación frontal estándar.
- Paneles laterales con estados de contraer/expandir independientes y rejilla recalculada.
- Botón **Pantalla completa** para ampliar exclusivamente el área 3D; `Esc` permite salir del modo pantalla completa.

Para aplicar esta versión, ejecuta `COMPILAR-FRONTEND.bat` para generar `public/assets` y luego recarga el editor con `Ctrl + F5`. No requiere cambios en el esquema SQL existente.


## Versión 1.3.0 – mejoras de edición y personajes

- Paneles laterales con estado de cuadrícula único; contraer/expandir no modifica `display` ni oculta separadores de forma independiente.
- Redimensionamiento de paneles con límites que preservan un ancho mínimo para el visor 3D.
- Personajes adicionales: hombre y mujer con polo institucional SENATI, además de variantes casuales con colores de polo variados.
- Profesor con vestimenta formal tipo terno.
- Geometría de personajes con mayor suavidad y resolución de render incrementada.
- Las ventanas de la plantilla del aula son objetos independientes seleccionables, movibles y girables.

Para aplicar la actualización, ejecutar `COMPILAR-FRONTEND.bat` y recargar con `Ctrl + F5`. No se agregaron tablas ni columnas a MySQL.

Nota: las figuras siguen siendo modelos geométricos estilizados. Para un acabado humano realmente profesional, la siguiente etapa debe incorporar personajes GLB riggeados y animaciones, no solo aumentar polígonos en figuras procedurales.


## Correccion 1.3.1 para Windows/Laragon

La comprobacion de frontend en `index.php` valida ahora que los dos archivos compilados existan y no esten vacios. Ya no compara fechas de modificacion de fuentes y salida, porque Windows puede conservar o redondear esas marcas de tiempo durante la extraccion del ZIP. Vite usa `publicDir: false` para evitar que `public` se solape con `public/assets`.

Para compilar: ejecutar `COMPILAR-FRONTEND.bat` o `npm install` y `npm run build`. La salida debe contener `public/assets/editor.js` y `public/assets/editor.css`.


### Normalización de escritorios (actualización)

Todos los escritorios individuales usan una dimensión fija de 1.58 m de largo por 0.72 m de fondo. Los escenarios guardados anteriormente se normalizan al cargarse; no se conservan escalas antiguas que alteren su tamaño. La escala queda bloqueada en el inspector para este objeto. El equipamiento automático calcula sus posiciones con la misma huella estándar.

## v6.3 — Escritorio con frente y parte posterior definidos

- Todos los escritorios mantienen una huella estándar de 1.58 m × 0.72 m y altura de superficie de 0.83 m.
- La orientación local es fija: frente `+Z` (lado del alumno) y posterior `-Z` (lado del monitor y pasacables).
- La superficie incorpora una zona visual discreta para teclado, un canal posterior para cableado y una marca frontal.
- El equipamiento automático ya no deduce la orientación a partir de la silla: coloca el monitor en la parte posterior, con la pantalla hacia el frente, y teclado/mouse en la zona marcada.
- Al girar el escritorio, los accesorios vinculados mantienen su posición y orientación relativa.


## Cambios de la versión 1.4.0

- Interfaz reorganizada en tres zonas: biblioteca izquierda, visor 3D central y configuración derecha.
- Biblioteca con miniaturas 3D locales para personas, escritorios, sillas, equipos, ventanas, puerta, pizarra y luminarias.
- Profesora con terno disponible en el catálogo.
- Iconografía SVG consistente para categorías y vistas rápidas.
- El control de pantalla completa conserva su tamaño y su icono en la barra flotante.
- Vite ahora emite las miniaturas a `public/assets/library/` con nombres únicos, manteniendo `public/assets/editor.css` y `public/assets/editor.js` para `index.php`.

No se agregan tablas ni columnas a MySQL en esta versión. Para actualizar, sustituye los archivos del proyecto, ejecuta `npm install` y `npm run build`, y recarga con `Ctrl + F5`.


## Actualización de distribución (v7.1)

- La plantilla Aula SENATI ahora mide 20 × 12 m y recupera 24 puestos en cuatro columnas por seis filas.
- Cada puesto mantiene escritorios de 158 × 72 cm y su silla queda delante del escritorio, orientada hacia el monitor y la pizarra.
- Los 24 equipos se generan automáticamente al crear la plantilla.
- Las computadoras All-in-One tienen pantalla, soporte y base ampliados; el teclado y mouse también se escalan proporcionalmente.
- Las luminarias se distribuyen por toda la sala y mantienen una orientación paralela al ancho del aula.
- La cámara inicial y las vistas rápidas se ajustan al ancho y largo del salón para encuadrar el aula completa.


## Versión 7.2

- Selección de objetos con contorno naranja de alto contraste y realce visual; al seleccionar se abre automáticamente la pestaña Propiedades.
- Inspector de PC All-in-One con selector de pantalla: Windows 11, logo SENATI o presentación neutra. La elección se guarda en `config_json` del objeto.
- Nuevos objetos de seguridad: señal de SALIDA y panel de reglas. La plantilla SENATI los coloca junto a la puerta de vidrio, orientados hacia el interior.
- Nueva categoría Seguridad en la biblioteca.

Compilar en Windows desde la carpeta del proyecto con `npm install` y `npm run build`. No requiere migración SQL; la personalización de pantalla se guarda en la configuración JSON ya existente.

## Actualización 1.4.3 — Señalización y seguridad del aula

La biblioteca incluye ahora una categoría **Seguridad** con señales y equipos de prevención:

- Señal de SALIDA.
- Panel de reglas de seguridad.
- Extintor 3D con etiqueta identificativa.
- Señal de botiquín / primeros auxilios.
- Advertencia de riesgo eléctrico.
- Señal de zona segura.
- Señal direccional de ruta de evacuación.

La plantilla Aula SENATI (Default) coloca automáticamente la señal de salida sobre la puerta, el panel de reglas junto al acceso, y añade el extintor y señalización complementaria en paredes próximas. Los elementos son objetos individuales seleccionables, movibles, rotables, duplicables y eliminables. Son recursos de señalización para una simulación educativa; deben ajustarse a las normas y al plano de evacuación oficial del centro antes de usarse como señalización real.


## Simulador mixto de emergencias (MVP)

Se incorpora `simulador.php`, una vista independiente que reutiliza los escenarios guardados en el diseñador mediante `api/scenarios.php?action=load`. Permite seleccionar escenario y tipo de evento (incendio, terremoto, accidente o riesgo eléctrico), iniciar/pausar/reiniciar, activar alarma y emitir órdenes del instructor. Los participantes se representan en una escena Three.js y se desplazan hacia la puerta registrada en el escenario.

El simulador requiere una sesión iniciada. La lista y carga de escenarios se limitan a los permisos del usuario; para una base existente, importa `database/upgrade-auth.sql`.

**Alcance:** es un primer prototipo funcional de navegación y control mixto. Todavía no implementa navegación con malla de obstáculos, animaciones humanoides GLB, evaluación certificable, ni protocolos oficiales; los resultados son demostrativos y deben validarse antes de cualquier uso formativo real.


## Versión 1.5.1 – Recorrido inmersivo y simulador mejorado
- El modo Recorrer solicita pantalla completa sobre el visor, oculta los paneles de edición y bloquea la cámara en primera persona; incluye botón visible para salir.
- El simulador incluye vistas superior, frontal, isométrica y ajuste de escena.
- La cámara se encuadra según las dimensiones reales del escenario cargado.
- Los incidentes tienen representación visual diferenciada: fuego/humo, zona de accidente y riesgo eléctrico.
- La evacuación usa puntos intermedios para orientar a los participantes primero hacia un pasillo y luego a la salida. Es una aproximación visual educativa, no un cálculo de evacuación certificado.


## Versión 1.5.2 – Navegación de evacuación
- Añade un navegador A* sobre una cuadrícula de 20 cm para calcular recorridos transitables.
- Modela escritorios, sillas, profesor, plantas, extintor y obstáculos de incidente con huella y margen de seguridad.
- Cada participante parte desde su asiento; se ignora únicamente la silla asociada a su posición inicial para permitir levantarse.
- La ruta se simplifica mediante comprobación de línea libre y muestra líneas de recorrido opcionales.
- Se aplica separación y reducción de velocidad entre personas, con salidas escalonadas para evitar que todos se amontonen en el acceso.
- El profesor sale después del grupo.
- La escena genera un vano de puerta en el muro y una hoja de vidrio visualmente entreabierta.
- Los incidentes de incendio, accidente y riesgo eléctrico añaden zonas bloqueadas para provocar desvíos; el terremoto incluye una fase de sacudida antes de iniciar el desplazamiento.
- La navegación es una simulación educativa aproximada. No representa un estudio de evacuación certificado ni sustituye un plan de seguridad aprobado.
- El panel del simulador muestra el contador de participantes sin ruta y permite reanudar tras una orden de detención del instructor.
- Los participantes se ordenan por proximidad a la salida y usan tres franjas de paso dentro del ancho estimado de la puerta.


## Versión 1.5.3 – Fidelidad de escena y señales de acceso
- El simulador importa el mismo constructor 3D de objetos que usa el diseñador; ya no simplifica mesas, sillas, computadoras, ventanas, puertas, señales, luminarias, plantas y personas a bloques genéricos.
- Carga dimensiones, apariencia, posición, rotación, escala y configuración JSON de cada objeto guardado. Las pantallas All-in-One recuperan el modo guardado (Windows 11, SENATI o neutra).
- La textura de pantalla se coloca por delante del panel del monitor para evitar que el bisel/pantalla opaca la oculte. El selector de pantalla del inspector ahora actualiza la textura y marca el escenario como modificado.
- La plantilla SENATI ya no añade botiquín ni flecha de evacuación; el rótulo sobre la puerta dice SALIDA sin flecha. Se conserva la señal de reglas y el resto de señalización solicitada.
- El simulador muestra las seis vistas rápidas del diseñador, control de techo/cuadrícula y modo Recorrer en pantalla completa. No muestra la biblioteca ni el inspector de creación.
- Los ajustes de techo, cuadrícula, sombras e iluminación se guardan junto con la apariencia; se aplican al simulador en escenarios guardados con esta versión.
- La navegación y los incidentes de la versión anterior se mantienen. Las rutas son una aproximación educativa y no una validación técnica de planes reales de evacuación.

- Para que un escenario antiguo deje de mostrar los objetos retirados de la plantilla (botiquín/flecha de evacuación), vuelve al diseñador, pulsa Aula SENATI (Default) y guarda el resultado sobre ese escenario. Los objetos guardados se conservan deliberadamente en otros escenarios personalizados.


## Versión 1.5.4 – Navegación por espacio libre y ancho real
- La cuadrícula de navegación pasa a resolución de 10 cm y exige 62 cm de espacio libre aproximado para el centro de paso del participante.
- Se utiliza la huella de escritorios, sillas, plantas, extintores y paredes colocadas en el escenario; se mantiene fuera del cálculo el equipamiento que está sobre los escritorios.
- La puerta se trata como un cuello de botella de una sola fila según su ancho libre estimado (1.28 m); se elimina la falsa distribución de tres carriles simultáneos.
- Los participantes se ordenan hacia la puerta y salen con intervalos para reducir adelantamientos y aglomeraciones.
- Se conserva el primer punto libre calculado: si la pose inicial está junto a la silla/escritorio, el personaje debe despejar primero ese espacio antes de continuar por el pasillo.
- Si no existe ancho suficiente, la ruta se marca como no calculable en lugar de dibujar un recorrido que atraviese mobiliario.
- La navegación es una aproximación educativa basada en huellas 2D y no sustituye un estudio profesional de evacuación.


## Versión 1.5.6
- La plantilla Aula SENATI inicia con el techo oculto y la casilla «Mostrar techo» desactivada.
- Se añade control de clima del escenario: día despejado, noche y lluvia.
- El clima se guarda con la apariencia del escenario y se conserva al abrirlo en el simulador.
- La lluvia se representa con partículas animadas; día/noche/lluvia ajustan fondo e iluminación.


## Plantilla Default 2: edificio de dos pisos

El editor incorpora la plantilla **Edificio de 2 pisos (Default 2)**. Incluye una planta superior, escalera recta con huellas y pasamanos, pasadizo de salida en el primer nivel y ocho participantes ubicados en el segundo piso. La simulación de esta plantilla calcula las rutas por nivel y encadena el descenso por la escalera con el recorrido del pasadizo hasta la puerta exterior. Cada escenario se simula por separado.

Para probarla: abre el diseñador, entra a **Escenarios**, selecciona **Edificio de 2 pisos · Default 2**, pulsa **Guardar escenario** y luego abre el simulador para elegirlo.


## Versión 1.5.7 – Recorrido transitable entre pisos
- La vista Recorrer incorpora detección de la zona de escalera y ajuste de altura del observador conforme avanza por los peldaños.
- Se puede subir desde el primer piso, llegar al descanso superior y desplazarse por el segundo nivel; también se permite bajar por la misma escalera.
- Los pasamanos delimitan el ancho transitable y se bloquea el paso lateral por el hueco de la escalera o por debajo del tramo.
- La colisión de objetos se calcula por el piso activo para evitar que el mobiliario del otro nivel bloquee el recorrido.


## Edición por pisos y recorrido (v1.5.8)
- El panel **Construcción por pisos** permite añadir o quitar el segundo nivel en escenarios propios.
- **Piso donde construir** selecciona el nivel de colocación; **Alcance de edición** aplica el acabado del suelo al edificio completo o solo al piso elegido.
- Las dimensiones generales se aplican al edificio. El formato actual permite hasta dos niveles conectados por la escalera configurable del escenario.
- En **Recorrer**, los paneles laterales se ocultan. En escenarios de dos pisos se inicia al pie de la escalera; la altura de cámara acompaña la rampa, se impide salir por los lados del hueco y se cambia de nivel solo cuando el escenario tiene el piso superior.
- Pulsa **Salir del recorrido · ESC** o `Escape` para volver al editor.




## Versión 1.7.0 — experiencia de acceso y administración

- La página de inicio de sesión presenta Aula 3D como una plataforma para crear escenarios, explorarlos en primera persona y realizar simulaciones.
- Administración se organiza en pestañas separadas: Resumen, Usuarios, Permisos de acceso y Escenarios.
- Creación, edición, restablecimiento de contraseña y asignación de escenarios se realizan en ventanas modales; los listados se muestran en tablas con búsqueda.
- El modo Recorrer no depende del bloqueo del puntero ni de pantalla completa: WASD mueve la cámara y mantener pulsado/arrastrar el mouse orienta la vista. Esto permite que el botón Salir siga siendo clicable mientras se recorre.
- ESC y el botón de salida terminan explícitamente el modo Recorrer. El portal sigue mostrando únicamente los escenarios autorizados por la cuenta.

## Versión 1.6.0 — acceso multiusuario y portal de recorridos

- Login independiente y cierre seguro de sesión.
- Roles de administrador y usuario, con creación inicial del administrador.
- Panel administrativo para crear/editar cuentas, activar o desactivar usuarios y restablecer contraseñas.
- Asignación individual de escenarios para cada usuario.
- Portal de escenarios que muestra solo los escenarios autorizados.
- Visor de usuario a pantalla completa en primera persona, con selector para cambiar de escenario después de liberar el mouse con `ESC`.
- API protegida: lectura limitada a escenarios asignados y escritura reservada a administradores con validación CSRF.


## Portal de recorrido inmersivo (1.7.1)

Los usuarios que acceden desde `portal.php` entran automáticamente al escenario en primera persona, sin paneles ni controles superpuestos. Las teclas W/A/S/D y flechas permiten desplazarse; al arrastrar el mouse sobre la escena se controla la mirada. La tecla ESC vuelve al portal para seleccionar otro escenario.


## Versión 1.7.2 — recorrido dual y panel optimizado

- El editor ofrece dos modos de recorrido: primera persona y tercera persona, con un avatar visible y cámara de seguimiento en tercera persona. Ambos reutilizan la navegación por pisos, la escalera y las colisiones del recorrido.
- El selector de escenarios guardados abre automáticamente el escenario elegido; se eliminó el paso adicional de pulsar Abrir.
- Durante la carga aparece una pantalla bloqueante con el nombre del escenario y un indicador de progreso para evitar acciones simultáneas.
- El panel derecho se organizó en cuatro pestañas: General, Pisos, Equipar y Apariencia. Las dimensiones y vistas rápidas quedan en General; la construcción por niveles queda separada en Pisos.


## Versión 1.7.3 — modelos humanos y mobiliario profesional

- Se renovó el modelo de todas las personas: proporciones corporales más equilibradas, rostro con ojos, cejas, nariz, boca, orejas y cabello; manos con dedos, calzado con suela y detalles de vestimenta.
- Los modelos humanos exponen articulaciones de brazos, codos, piernas y rodillas para animación. En tercera persona, el avatar reutiliza el mismo modelo de la biblioteca y acompaña el desplazamiento con balanceo alternado de brazos y piernas.
- En la evacuación, los participantes que caminan animan brazos, piernas y rodillas, tanto si comenzaron sentados como si estaban de pie.
- Se suavizaron los bordes de los elementos de mobiliario y equipamiento mediante geometrías redondeadas; la silla de aula ahora tiene respaldo acolchado, soportes, elevador central y base con cinco ruedas.
- Se añadieron detalles al mouse y se ajustó la iluminación/exposición para reducir el acabado plástico y mejorar el contraste de materiales.


## Plantilla SENATI Torre 1 (v1.7.4)

Se agregó una plantilla conceptual del Centro Tecnológico SENATI Torre 1: tres bloques, dos sótanos, bloque central de once pisos, dos laterales de diez pisos y puentes de conexión esquemáticos. Se amplió el administrador de niveles a trece posiciones para representar dos sótanos, planta baja y once pisos.

**Importante:** no se encontró una planta arquitectónica pública completa del edificio ejecutado. La distribución interior y la ubicación exacta de los puentes en esta plantilla son aproximaciones editables; no deben usarse como planos oficiales ni para un plan real de evacuación. La navegación/simulación de evacuación vertical de los trece niveles aún no está implementada.


## SENATI Torre explorable (v1.7.8)

- La plantilla conceptual se amplía a una huella de 180 × 146 m, con tres bloques de 30 × 40 m, dos sótanos, planta baja y niveles superiores. Son dimensiones de modelado para crear un mundo virtual, no cotas oficiales.
- Se incorporan aulas y talleres por nivel, pasadizos, patios, plaza, pistas y veredas.
- Las escaleras utilizan dos tramos y un descanso, con control de transición entre niveles adyacentes y bloqueo lateral del hueco.
- Los seis ascensores (dos por bloque) permiten seleccionar un piso servido por el bloque, llamar la cabina, abrir puertas, entrar, viajar y salir. La cámara acompaña el movimiento vertical.
- La colisión del recorrido considera muros, columnas, cerramientos y puertas de ascensor. Las hojas del ascensor dejan de bloquear al abrirse; las superficies de pista, piso exterior y vereda son transitables.
- La biblioteca incluye piezas de pista asfaltada, piso exterior y vereda para continuar ampliando el entorno.

**Alcance:** es una maqueta conceptual editable y explorable; no representa planos arquitectónicos oficiales ni sirve para certificar evacuaciones. La evacuación automática multi-bloque y multi-piso sigue fuera del alcance.


## Campus virtual multijugador (primera fase)

Consulta `README-MULTIJUGADOR.md` para instalar y ejecutar el campus compartido en Windows 11 con Laragon. Requiere Node.js además de Apache/MySQL. El chat y las posiciones son en tiempo real y en memoria; esta fase todavía no integra la Torre editable ni guarda mensajes.


## v8.16 — Escenarios compartidos en el mundo virtual

- En el portal, cada escenario asignado ofrece dos accesos: recorrido individual y mundo multijugador.
- El mundo multijugador carga el escenario guardado en MySQL y reutiliza sus modelos.
- La plantilla SENATI Torre utiliza el generador arquitectónico compartido del editor (campus, bloques, interiores, escaleras y ascensores como geometría).
- Cada escenario tiene una sala WebSocket independiente: dos usuarios deben entrar al mismo escenario para verse y chatear juntos.
- Se corrigió la orientación de las sillas del template SENATI Default para que miren hacia el escritorio y se alineó la orientación del alumno sentado.

**Límite de esta etapa:** el escenario ya se representa en el mundo compartido y los avatares/chat se sincronizan por escenario. La sincronización de altura y piso para subir escaleras/ascensores en multijugador aún no está implementada; los pisos superiores se representan visualmente, pero el protocolo actual de jugadores sigue sincronizando X/Z.
