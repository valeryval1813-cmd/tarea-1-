# SENATI Torre 1 – referencias y límites del modelo

## Identificación
Las imágenes aportadas coinciden con el Centro Tecnológico SENATI / Torre 1 de la sede Independencia, Lima. No deben confundirse con el edificio SENATI histórico de los años 1965–1966 ni con propuestas arquitectónicas posteriores no necesariamente construidas.

## Datos documentados
- El conjunto ejecutado está compuesto por tres edificios conectados: uno de once pisos y dos de diez, además de dos sótanos destinados a estacionamientos.
- El área construida reportada está alrededor de 19,500 m² (las publicaciones muestran cifras cercanas de 19,506.94 a 19,611 m²).
- Los usos reportados incluyen aulas, salas de cómputo, talleres, laboratorios, sala de conferencias, biblioteca, comedor, sala de instructores y áreas administrativas.
- La ficha de Binswanger reporta muro cortina y seis ascensores para la Torre 1.
- El perfil de Prisma Ingenieros identifica para el edificio emblemático de once pisos un sistema estructural de muros de concreto armado y un área construida aproximada de 17,711 m².
- Una publicación institucional anterior indica que el bloque central de Torre 1 fue concebido con una altura cercana a 50 m.

## Qué se representa en Aula 3D (versión 8.13 / paquete 1.7.8)
- Tres bloques académicos: dos laterales con diez niveles sobre rasante y un bloque central con once niveles, además de dos sótanos compartidos en el modelo conceptual.
- Dos sótanos conceptuales con columnas y marcas de estacionamiento.
- Núcleos esquemáticos con escaleras de dos tramos y descanso; seis ascensores (dos por bloque) con cabina animada y puertas por nivel; muro cortina, bandas horizontales y diagonales de fachada inspiradas en las fotografías.
- Puentes esquemáticos entre bloques en algunos niveles. Su ubicación exacta no se conoce en las fuentes públicas consultadas.
- Plantas interiores con aulas/talleres esquemáticos, mobiliario básico, pasadizos y muros colisionables; pueden editarse y equiparse.
- Entorno exterior de campus con pista, veredas, plaza, señalización vial, jardineras y luminarias. También hay piezas modulares de pista, piso exterior y vereda en la biblioteca.

## Límites importantes
No se encontró un juego público verificable de plantas arquitectónicas piso por piso, planos estructurales, dimensiones exactas de ejes, ubicación de escaleras, ascensores por bloque ni cotas oficiales. Las medidas de la plantilla (180 × 146 m para el conjunto, huellas de bloque de 30 × 40 m, alturas de 4.45 m entre niveles y posiciones de puentes) son valores de modelado aproximados, no datos del expediente técnico. La disposición de aulas, talleres, escaleras y ascensores es esquemática y no sustituye los planos del expediente. Los objetos de pista, pavimento exterior y vereda son módulos de construcción editables; sus dimensiones tampoco representan cotas oficiales.

Esta plantilla es una reconstrucción visual para edición y exploración conceptual. No es un plano oficial, no acredita cumplimiento normativo y no debe utilizarse para decisiones de ingeniería, aforo o evacuación real. La navegación a pie con escaleras y ascensores permite explorar los niveles construidos. La evacuación automática multibloque y multinivel para los 13 niveles todavía requiere un grafo de rutas específico y validación independiente.

## Fuentes públicas consultadas
1. SENATI, *Memoria Institucional 2018*, p. 74: tres edificios de diez y once pisos, puentes, áreas educativas y 3,000 puestos de aprendizaje por turno. https://www.senati.edu.pe/sites/default/files/archivos/2019/publicaciones/03/memoria_2018.pdf
2. Binswanger Perú, *SENATI*: tres edificios de 10 y 11 pisos, 19,506.94 m², usos principales, muro cortina y seis ascensores. https://binswanger.com.pe/es/casos/senati
3. Prisma Ingenieros, perfil institucional: diseño estructural del edificio emblemático SENATI Torre 1, once pisos, muros de concreto armado, área aproximada de 17,711 m². https://admin.lider.com.pe/storage/files/projects/documents/p-16161674616054c225528e8.pdf
4. SENATI, *Revista Institucional N.º 84* (oct.-nov. 2017), pp. 8–9: separación del proyecto en tres estructuras, bloque central cercano a 50 m y render del conjunto. https://www.senati.edu.pe/sites/default/files/archivos/2017/publicaciones/10/senati-revista-84.pdf
5. Agencia Andina, nota de inauguración: una torre de once pisos y dos de diez, con dos sótanos para estacionamientos. https://andina.pe/agencia/noticia-senati-aumentara-40-capacidad-instalada-gracias-a-nuevo-centro-tecnologico-772326.aspx


**Actualización del modelo virtual v1.7.8:** la huella se amplió a 180 × 146 m y cada bloque se modela con 30 × 40 m para permitir recorridos, pistas, veredas, patios y salones editables. Estas dimensiones son parámetros de visualización, no mediciones oficiales del edificio.

**Recorrido vertical y entorno virtual:** se ajustó la entrada a las escaleras para coincidir con el paso de navegación y se integró el viaje en ascensor con selección de pisos servidos por cada bloque, apertura/cierre animado de puertas y traslado de cámara/personaje. La biblioteca agrupa los módulos Pista asfaltada, Piso exterior y Vereda peatonal en la sección Mundo exterior. Las colisiones de muros se aplican durante el recorrido; la prueba de navegador debe hacerse en el equipo de instalación.
