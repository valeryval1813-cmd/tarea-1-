<?php
declare(strict_types=1);

require_once __DIR__ . '/database.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
    if (isset($_SESSION['auth_last_activity']) && time() - (int)$_SESSION['auth_last_activity'] > 28800) {
        unset($_SESSION['auth_user']);
    }
    $_SESSION['auth_last_activity'] = time();
    header('Cache-Control: no-store, private');
    header('Pragma: no-cache');
}

function current_user(): ?array
{
    static $checked = false;
    static $resolved = null;
    if ($checked) return $resolved;
    $checked = true;
    $stored = $_SESSION['auth_user'] ?? null;
    if (!is_array($stored) || !isset($stored['id'])) return null;
    try {
        $stmt = db()->prepare('SELECT id,name,email,role,is_active FROM users WHERE id=? LIMIT 1');
        $stmt->execute([(int)$stored['id']]);
        $fresh = $stmt->fetch();
        if (!$fresh || (int)$fresh['is_active'] !== 1) {
            unset($_SESSION['auth_user']);
            return null;
        }
        $resolved = [
            'id' => (int)$fresh['id'],
            'name' => (string)$fresh['name'],
            'email' => (string)$fresh['email'],
            'role' => (string)$fresh['role'],
        ];
        $_SESSION['auth_user'] = $resolved;
        return $resolved;
    } catch (Throwable $e) {
        error_log('[Aula3D auth] ' . $e->getMessage());
        unset($_SESSION['auth_user']);
        return null;
    }
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        $next = $_SERVER['REQUEST_URI'] ?? 'portal.php';
        header('Location: ./login.php?next=' . rawurlencode($next));
        exit;
    }
    return $user;
}

function require_admin(): array
{
    $user = require_login();
    if (($user['role'] ?? '') !== 'admin') {
        header('Location: ./portal.php');
        exit;
    }
    return $user;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['csrf_token'];
}

function csrf_is_valid(?string $token): bool
{
    return is_string($token) && isset($_SESSION['csrf_token'])
        && hash_equals((string)$_SESSION['csrf_token'], $token);
}

function can_access_scenario(PDO $pdo, int $scenarioId, ?array $user = null): bool
{
    $user ??= current_user();
    if (!$user) return false;
    if (($user['role'] ?? '') === 'admin') return true;
    $stmt = $pdo->prepare('SELECT 1 FROM scenario_user_access WHERE user_id = ? AND scenario_id = ? LIMIT 1');
    $stmt->execute([(int)$user['id'], $scenarioId]);
    return (bool)$stmt->fetchColumn();
}

function accessible_scenarios(PDO $pdo, ?array $user = null): array
{
    $user ??= current_user();
    if (!$user) return [];
    if (($user['role'] ?? '') === 'admin') {
        return $pdo->query('SELECT id, name, width_m, depth_m, height_m, updated_at FROM scenarios ORDER BY updated_at DESC, id DESC')->fetchAll();
    }
    $stmt = $pdo->prepare(
        'SELECT s.id, s.name, s.width_m, s.depth_m, s.height_m, s.updated_at
         FROM scenarios s INNER JOIN scenario_user_access a ON a.scenario_id = s.id
         WHERE a.user_id = ? ORDER BY s.updated_at DESC, s.id DESC'
    );
    $stmt->execute([(int)$user['id']]);
    return $stmt->fetchAll();
}

function h(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
