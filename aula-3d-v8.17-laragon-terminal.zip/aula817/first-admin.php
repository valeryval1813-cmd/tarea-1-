<?php
declare(strict_types=1);
require_once __DIR__ . '/config/auth.php';
if (current_user()) { header('Location: ./admin.php'); exit; }
$error = '';
$done = false;
try {
    $pdo = db();
    $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
    if ($adminCount > 0) { header('Location: ./login.php'); exit; }
} catch (Throwable $e) {
    $error = 'No se encuentran las tablas de autenticación. Importa primero database/schema.sql o database/upgrade-auth.sql.';
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    if (!csrf_is_valid($_POST['csrf_token'] ?? null)) $error = 'Formulario vencido. Recarga la página.';
    else {
        $name = trim((string)($_POST['name'] ?? ''));
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $password = (string)($_POST['password'] ?? '');
        $confirm = (string)($_POST['confirm'] ?? '');
        if ($name === '' || strlen($name) > 120 || !filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'Completa un nombre y un correo válidos.';
        elseif (strlen($password) < 10) $error = 'La contraseña debe tener al menos 10 caracteres.';
        elseif ($password !== $confirm) $error = 'Las contraseñas no coinciden.';
        else {
            try {
                $pdo->beginTransaction();
                $existingAdmin = $pdo->query("SELECT id FROM users WHERE role='admin' LIMIT 1 FOR UPDATE")->fetchColumn();
                if ($existingAdmin) throw new RuntimeException('Ya se creó un administrador. Inicia sesión.');
                $stmt = $pdo->prepare("INSERT INTO users (name,email,password_hash,role,is_active) VALUES (?,?,?,'admin',1)");
                $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
                $pdo->commit();
                $done = true;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = $e instanceof PDOException ? 'No se pudo crear la cuenta. Verifica que el correo no esté registrado.' : $e->getMessage();
            }
        }
    }
}
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Crear administrador inicial | Aula 3D</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#f3f6fb;color:#17243a;font-family:system-ui}.card{width:min(100%,520px);background:#fff;border:1px solid #e1e8f0;border-radius:18px;padding:28px;box-shadow:0 20px 60px #1f345115}h1{margin:0 0 8px}.muted{color:#64748b;line-height:1.5}.field{display:block;font-size:13px;font-weight:700;margin:14px 0 6px}.field input{display:block;width:100%;margin-top:6px;padding:12px;border:1px solid #d8e1ec;border-radius:9px;font:inherit}.btn{margin-top:18px;width:100%;border:0;border-radius:9px;padding:13px;background:#195da9;color:#fff;font-weight:800;cursor:pointer}.msg{padding:12px;border-radius:9px;background:#fff0ef;color:#a32d27;margin:14px 0}.ok{padding:14px;border-radius:9px;background:#eaf8f0;color:#19623a;margin:14px 0}</style></head><body><main class="card"><h1>Administrador inicial</h1><p class="muted">Esta pantalla solo funciona mientras no exista ninguna cuenta administradora. Después de crearla, se bloqueará automáticamente.</p><?php if($error):?><div class="msg"><?=h($error)?></div><?php endif;?><?php if($done):?><div class="ok">Administrador creado correctamente. Ya puedes iniciar sesión.</div><a href="./login.php">Ir al inicio de sesión</a><?php else: ?><form method="post"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><label class="field">Nombre<input name="name" maxlength="120" required></label><label class="field">Correo<input name="email" type="email" maxlength="190" required></label><label class="field">Contraseña<input name="password" type="password" minlength="10" required></label><label class="field">Confirmar contraseña<input name="confirm" type="password" minlength="10" required></label><button class="btn">Crear administrador</button></form><?php endif;?></main></body></html>
