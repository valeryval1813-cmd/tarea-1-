-- AULA 3D - ESQUEMA UNICO
-- Importar este archivo una vez en phpMyAdmin para una instalacion nueva.
-- Incluye escenarios, objetos, apariencia, usuarios y permisos.
-- En una instalacion existente con datos, NO volver a importar para evitar confusiones;
-- conservar la base actual. Este archivo no elimina tablas ni registros.
-- Base de datos del editor de escenarios 3D
CREATE DATABASE IF NOT EXISTS aula3d
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE aula3d;

CREATE TABLE IF NOT EXISTS scenarios (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  width_m DECIMAL(7,2) NOT NULL DEFAULT 20.00,
  depth_m DECIMAL(7,2) NOT NULL DEFAULT 12.00,
  height_m DECIMAL(6,2) NOT NULL DEFAULT 3.40,
  appearance_json JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_scenarios_updated (updated_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS object_catalog (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  object_key VARCHAR(40) NOT NULL UNIQUE,
  label VARCHAR(100) NOT NULL,
  category VARCHAR(40) NOT NULL,
  description VARCHAR(180) NULL,
  model_path VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scenario_objects (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  scenario_id BIGINT UNSIGNED NOT NULL,
  object_uuid VARCHAR(64) NOT NULL,
  catalog_key VARCHAR(40) NOT NULL,
  label VARCHAR(80) NOT NULL,
  pos_x DECIMAL(10,3) NOT NULL DEFAULT 0,
  pos_y DECIMAL(10,3) NOT NULL DEFAULT 0,
  pos_z DECIMAL(10,3) NOT NULL DEFAULT 0,
  rot_x DECIMAL(10,5) NOT NULL DEFAULT 0,
  rot_y DECIMAL(10,5) NOT NULL DEFAULT 0,
  rot_z DECIMAL(10,5) NOT NULL DEFAULT 0,
  scale_x DECIMAL(7,3) NOT NULL DEFAULT 1,
  scale_y DECIMAL(7,3) NOT NULL DEFAULT 1,
  scale_z DECIMAL(7,3) NOT NULL DEFAULT 1,
  config_json JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_scene_objects_scenario FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE CASCADE,
  INDEX idx_scene_objects_scenario (scenario_id),
  INDEX idx_scene_objects_catalog (catalog_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_email (email),
  INDEX idx_users_role_active (role, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS scenario_user_access (
  user_id BIGINT UNSIGNED NOT NULL,
  scenario_id BIGINT UNSIGNED NOT NULL,
  granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, scenario_id),
  CONSTRAINT fk_scenario_access_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_scenario_access_scenario FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE CASCADE,
  INDEX idx_scenario_access_scenario (scenario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO object_catalog (object_key,label,category,description) VALUES
('desk','Escritorio individual','mobiliario','Mesa independiente'),
('chair','Silla giratoria','mobiliario','Base de cinco radios'),
('aio','PC All-in-One 27 pulgadas','computacion','Monitor integrado con teclado y mouse automáticos'),
('keyboard','Teclado','computacion','Teclado independiente'),
('mouse','Mouse','computacion','Mouse óptico'),
('man','Persona hombre','personas','Figura masculina'),
('woman','Persona mujer','personas','Figura femenina'),
('teacher','Profesor','personas','Docente de pie'),
('wall','Pared','arquitectura','Tramo de pared'),
('door','Puerta de vidrio','arquitectura','Puerta con marco'),
('window','Ventana','arquitectura','Ventana de pared'),
('whiteboard','Pizarra','arquitectura','Pizarra blanca'),
('fluorescent','Fluorescente','equipamiento','Luminaria rectangular'),
('fan','Ventilador','equipamiento','Ventilador de techo'),
('projector','Proyector','equipamiento','Proyector de techo'),
('plant','Planta decorativa','equipamiento','Maceta decorativa')
ON DUPLICATE KEY UPDATE label=VALUES(label),category=VALUES(category),description=VALUES(description);
