# Aula 3D – primera versión del campus virtual multijugador

Esta actualización agrega un **prototipo multijugador compartido** al proyecto PHP/MySQL + Three.js. Mantiene el editor, el portal, el login y los escenarios existentes.

## Qué puedes probar

- Entrar con una cuenta que ya exista en Aula 3D.
- Abrir el portal, elegir un escenario y pulsar **Entrar al mundo multijugador**.
- Ver un campus exterior 3D conceptual con tres bloques, plaza, pistas, veredas y jardines.
- Mover un avatar con `W`, `A`, `S`, `D` o flechas.
- Girar la cámara arrastrando el mouse.
- Ver otros usuarios conectados en tiempo real.
- Enviar mensajes en el chat global del campus.
- El chat limita la longitud a 240 caracteres y aplica un intervalo mínimo entre mensajes.

**Alcance de esta primera fase:** el campus compartido es una escena de demostración independiente. Todavía no carga los edificios y escenarios guardados por el editor, no sincroniza objetos construidos, no tiene voz, inventario, persistencia de chat ni instancias por edificio. La siguiente fase debe conectar el campus con la Torre SENATI y permitir entrar a sus interiores sin perder la sesión multijugador.

## Requisitos en Windows 11

1. Laragon con Apache y MySQL funcionando.
2. Node.js LTS instalado (incluye `node` y `npm`).
3. El proyecto copiado dentro de `C:\laragon\www\aula-3d` (o la carpeta que ya utilizas).
4. Base de datos de Aula 3D existente y configurada en `config/database.php`.

No se necesita importar otro SQL para esta función.

## Instalación paso a paso

1. Haz una copia de seguridad de la carpeta actual del proyecto.
2. Descomprime esta versión sobre la carpeta del proyecto, conservando `config/database.php` y los datos actuales.
3. Abre Laragon e inicia Apache y MySQL.
4. Abre una terminal en la carpeta del proyecto (Laragon: Menú > Terminal) y ejecuta:

   ```bat
   npm install
   npm run build
   ```

5. Cuando termine la compilación, abre una **segunda terminal** en la misma carpeta y ejecuta:

   ```bat
   npm run multiplayer
   ```

   Deja esa ventana abierta mientras se use el mundo virtual. Debe mostrar: `Aula 3D multijugador escuchando en ws://0.0.0.0:3001`.

6. Entra a tu portal con tu usuario y abre **Campus virtual multijugador**, o visita:

   `http://localhost/aula-3d/portal.php`

   Si tu proyecto utiliza otro puerto o nombre de carpeta, conserva la URL que ya utilizas en Laragon y cambia solo la ruta final a `/portal.php`.

No se incluyen archivos `.bat`: inicia y administra todo desde la terminal de Laragon, como en los pasos anteriores.

## Probar con dos usuarios en la misma PC

1. Abre el portal en una ventana normal e inicia sesión con el primer usuario.
2. Abre una ventana privada/incógnito e inicia sesión con otro usuario.
3. En ambas ventanas entra al Campus virtual.
4. Los dos avatares deben aparecer en la misma escena y los mensajes deben verse en ambos chats.

No compartas una misma sesión/cuenta para esta prueba: utiliza dos cuentas activas diferentes.

## Probar desde otra PC de la red local

1. Averigua la IPv4 de la PC que ejecuta Laragon con `ipconfig`.
2. En el firewall de Windows permite conexiones TCP entrantes al puerto `3001` (y Apache en el puerto que estés usando).
3. Desde la otra PC abre `http://IP-DE-LA-PC/aula-3d/login.php`.
4. Inicia sesión y entra al mundo. El navegador se conectará al WebSocket de esa misma IP en el puerto `3001`.
5. Ambas computadoras deben estar en la misma red local.

No publiques el puerto directamente en Internet. Para acceso externo se debe configurar HTTPS/WSS, proxy inverso, autenticación reforzada, límites y despliegue seguro.

## Seguridad y datos

- `api/world-ticket.php` emite un ticket firmado solo para usuarios autenticados.
- `multiplayer/server.js` valida la firma y la caducidad antes de admitir una conexión.
- El ticket dura tres minutos y se usa para abrir el WebSocket.
- `multiplayer/secret.key` es una clave compartida entre PHP y Node. No la publiques ni la envíes por chat. El directorio `multiplayer` incluye `.htaccess` para impedir que Apache sirva esa clave.
- Los mensajes se transmiten en vivo y no se guardan en MySQL.
- La posición de los avatares se mantiene en memoria del servidor; al reiniciar Node todos vuelven a entrar desde el punto inicial.

## Solución de problemas

- **“No se pudo conectar al servidor multijugador”**: comprueba que `npm run multiplayer` siga ejecutándose y que el puerto `3001` no esté bloqueado.
- **Pantalla sin campus**: ejecuta `npm run build` y verifica que exista `public/assets/world-client.js`.
- **No carga el ticket**: confirma que hayas iniciado sesión y que Apache/PHP puedan leer `multiplayer/secret.key`.
- **Dos usuarios no se ven**: usa dos cuentas, comprueba que ambas URL apunten al mismo servidor y que el proceso Node siga activo.
- **Otro equipo no conecta**: revisa la IP local, el firewall y que ambos equipos estén en la misma red.

## Comandos de uso diario

Compilar después de actualizar el frontend:

```bat
npm run build
```

Iniciar el servidor compartido:

```bat
npm run multiplayer
```


## Integración con escenarios guardados (v8.16)

Desde el portal, cada tarjeta permite elegir **Entrar al mundo multijugador**. El servidor carga el escenario guardado desde MySQL y crea una sala compartida exclusiva para ese escenario. Los usuarios que seleccionen el mismo escenario se ven y conversan en la misma sala; los escenarios distintos quedan separados. Para la plantilla SENATI Torre se reutiliza el generador arquitectónico `tower-world.js` del editor; para escenarios de aula se reutilizan los modelos de `scene-models.js`.

La integración carga la geometría guardada y sincroniza usuarios en una sala exclusiva por escenario. La navegación vertical multijugador (replicar altura/piso en el protocolo de movimiento) queda como siguiente etapa; no debe confundirse con la simulación de evacuación.
