<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/auth.php';
$user = require_login();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
$secretPath = __DIR__ . '/../multiplayer/secret.key';
$secret = is_file($secretPath) ? trim((string)file_get_contents($secretPath)) : '';
if (strlen($secret) < 32 || str_starts_with($secret, 'REPLACE_')) {
    http_response_code(503);
    echo json_encode(['error' => 'Configura multiplayer/secret.key con una clave aleatoria de al menos 32 caracteres.']);
    exit;
}
$scenarioId = filter_input(INPUT_GET, 'scenario', FILTER_VALIDATE_INT);
if (!$scenarioId || $scenarioId < 1 || !can_access_scenario(db(), (int)$scenarioId, $user)) {
    http_response_code(403);
    echo json_encode(['error' => 'No tienes permiso para entrar a este escenario del campus.']);
    exit;
}
$payload = [
    'sub' => (int)$user['id'],
    'name' => mb_substr((string)$user['name'], 0, 32),
    'role' => (string)$user['role'],
    'exp' => time() + 180,
    'room' => 'senati-scenario-' . (int)$scenarioId
];
$body = rtrim(strtr(base64_encode(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)), '+/', '-_'), '=');
$sig = rtrim(strtr(base64_encode(hash_hmac('sha256', $body, $secret, true)), '+/', '-_'), '=');
echo json_encode(['ticket' => $body . '.' . $sig, 'name' => $payload['name'], 'room' => $payload['room']]);
