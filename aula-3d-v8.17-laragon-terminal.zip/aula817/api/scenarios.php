<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, private');

require_once __DIR__ . '/../config/auth.php';

function respond(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function requestBody(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '[]', true);
    if (!is_array($data)) {
        respond(['success' => false, 'message' => 'El cuerpo de la solicitud no es JSON válido.'], 400);
    }
    return $data;
}

function safeText(mixed $value, int $max = 100): string
{
    $text = trim((string)$value);
    if ($text === '') return 'Escenario sin título';
    return function_exists('mb_substr') ? mb_substr($text, 0, $max) : substr($text, 0, $max);
}

$user = current_user();
if (!$user) respond(['success' => false, 'message' => 'Tu sesión venció. Inicia sesión nuevamente.'], 401);

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = (string)($_GET['action'] ?? '');
if (in_array($action, ['save', 'delete'], true)) {
    if (($user['role'] ?? '') !== 'admin') respond(['success' => false, 'message' => 'Solo los administradores pueden modificar escenarios.'], 403);
    if ($method !== 'POST') respond(['success' => false, 'message' => 'Método no permitido.'], 405);
    if (!csrf_is_valid($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null)) respond(['success' => false, 'message' => 'Token de seguridad inválido. Recarga el editor.'], 403);
}

try {
    $pdo = db();

    if ($action === 'list' && $method === 'GET') {
        respond(['success' => true, 'scenarios' => accessible_scenarios($pdo, $user)]);
    }

    if ($action === 'load' && $method === 'GET') {
        $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if (!$id || $id < 1) respond(['success' => false, 'message' => 'Identificador de escenario inválido.'], 422);
        if (!can_access_scenario($pdo, (int)$id, $user)) respond(['success' => false, 'message' => 'No tienes permiso para acceder a este escenario.'], 403);
        $stmt = $pdo->prepare('SELECT id, name, width_m, depth_m, height_m, appearance_json FROM scenarios WHERE id = ?');
        $stmt->execute([$id]);
        $scenario = $stmt->fetch();
        if (!$scenario) respond(['success' => false, 'message' => 'No se encontró el escenario.'], 404);
        $objects = $pdo->prepare(
            'SELECT object_uuid, catalog_key, label, pos_x, pos_y, pos_z,
                    rot_x, rot_y, rot_z, scale_x, scale_y, scale_z, config_json
             FROM scenario_objects WHERE scenario_id = ? ORDER BY id ASC'
        );
        $objects->execute([$id]);
        $scenario['objects'] = $objects->fetchAll();
        respond(['success' => true, 'scenario' => $scenario]);
    }

    if ($action === 'save' && $method === 'POST') {
        $data = requestBody();
        $name = safeText($data['name'] ?? 'Mi escenario', 100);
        $dimensions = $data['dimensions'] ?? [];
        $width = (float)($dimensions['width'] ?? 0);
        $depth = (float)($dimensions['depth'] ?? 0);
        $height = (float)($dimensions['height'] ?? 0);
        $objects = $data['objects'] ?? [];
        $appearance = $data['appearance'] ?? [];
        if (!is_array($appearance)) $appearance = [];
        $appearanceJson = json_encode($appearance, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($width < 3 || $width > 250 || $depth < 3 || $depth > 250 || $height < 2.2 || $height > 20) respond(['success' => false, 'message' => 'Dimensiones fuera del rango permitido (máximo 250 m de ancho y largo).'], 422);
        if (!is_array($objects) || count($objects) > 1000) respond(['success' => false, 'message' => 'Cantidad de objetos no válida (máximo 1000).'], 422);

        $pdo->beginTransaction();
        $scenarioId = isset($data['id']) && (int)$data['id'] > 0 ? (int)$data['id'] : null;
        if ($scenarioId) {
            $check = $pdo->prepare('SELECT id FROM scenarios WHERE id = ?');
            $check->execute([$scenarioId]);
            if (!$check->fetchColumn()) $scenarioId = null;
        }
        if ($scenarioId) {
            $update = $pdo->prepare('UPDATE scenarios SET name=?,width_m=?,depth_m=?,height_m=?,appearance_json=? WHERE id=?');
            $update->execute([$name,$width,$depth,$height,$appearanceJson,$scenarioId]);
            $pdo->prepare('DELETE FROM scenario_objects WHERE scenario_id=?')->execute([$scenarioId]);
        } else {
            $insert = $pdo->prepare('INSERT INTO scenarios (name,width_m,depth_m,height_m,appearance_json) VALUES (?,?,?,?,?)');
            $insert->execute([$name,$width,$depth,$height,$appearanceJson]);
            $scenarioId = (int)$pdo->lastInsertId();
        }
        $insertObject = $pdo->prepare(
            'INSERT INTO scenario_objects
             (scenario_id,object_uuid,catalog_key,label,pos_x,pos_y,pos_z,rot_x,rot_y,rot_z,scale_x,scale_y,scale_z,config_json)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        );
        $allowedKeys = [
            'desk','chair','aio','keyboard','mouse','man','woman','man-senati','woman-senati','teacher',
            'wall','door','door-normal','window','whiteboard','fluorescent','fan','projector','plant','teacher-f','road','ground','sidewalk',
            'safety-exit','safety-rules','fire-extinguisher','safety-first-aid','safety-electrical','safety-safe-zone','safety-evacuation'
        ];
        foreach ($objects as $object) {
            if (!is_array($object)) continue;
            $key = (string)($object['catalogKey'] ?? '');
            if (!in_array($key, $allowedKeys, true)) continue;
            $position = $object['position'] ?? [];
            $rotation = $object['rotation'] ?? [];
            $scale = $object['scale'] ?? [];
            $uuid = safeText($object['id'] ?? bin2hex(random_bytes(8)), 64);
            $label = safeText($object['label'] ?? $key, 80);
            $config = json_encode($object['config'] ?? new stdClass(), JSON_UNESCAPED_UNICODE);
            $insertObject->execute([
                $scenarioId,$uuid,$key,$label,
                (float)($position['x'] ?? 0),(float)($position['y'] ?? 0),(float)($position['z'] ?? 0),
                (float)($rotation['x'] ?? 0),(float)($rotation['y'] ?? 0),(float)($rotation['z'] ?? 0),
                max(0.1,min(5,(float)($scale['x'] ?? 1))),max(0.1,min(5,(float)($scale['y'] ?? 1))),max(0.1,min(5,(float)($scale['z'] ?? 1))),$config
            ]);
        }
        $pdo->commit();
        respond(['success' => true, 'id' => $scenarioId, 'message' => 'Escenario guardado.']);
    }

    if ($action === 'delete' && $method === 'POST') {
        $data = requestBody();
        $id = (int)($data['id'] ?? 0);
        if ($id < 1) respond(['success' => false, 'message' => 'Identificador inválido.'], 422);
        $stmt = $pdo->prepare('DELETE FROM scenarios WHERE id=?');
        $stmt->execute([$id]);
        respond(['success' => true, 'deleted' => $stmt->rowCount()]);
    }

    respond(['success' => false, 'message' => 'Acción o método no permitido.'], 405);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    error_log('[Aula3D] ' . $e->getMessage());
    respond(['success' => false, 'message' => 'Error del servidor. Verifica la conexión MySQL y que hayas importado el esquema actualizado.'], 500);
}
