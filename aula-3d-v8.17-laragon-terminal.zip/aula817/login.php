<?php
declare(strict_types=1);
require_once __DIR__ . '/config/auth.php';

if (current_user()) {
    $u = current_user();
    header('Location: ' . (($u['role'] ?? '') === 'admin' ? './admin.php' : './portal.php'));
    exit;
}
$error = '';
$setupMessage = '';
try {
    $pdo = db();
    $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
    if ($adminCount === 0) $setupMessage = 'Todavía no existe un administrador. Crea la cuenta inicial para comenzar.';
} catch (Throwable $e) {
    $setupMessage = 'Antes de iniciar, importa database/schema.sql (instalación nueva) o database/upgrade-auth.sql (base existente).';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_is_valid($_POST['csrf_token'] ?? null)) {
        $error = 'La sesión del formulario venció. Recarga la página e inténtalo otra vez.';
    } else {
        $now = time();
        $blockedUntil = (int)($_SESSION['login_blocked_until'] ?? 0);
        if ($blockedUntil > $now) {
            $error = 'Demasiados intentos. Vuelve a intentarlo en ' . ($blockedUntil - $now) . ' segundos.';
        } else {
            $email = strtolower(trim((string)($_POST['email'] ?? '')));
            $password = (string)($_POST['password'] ?? '');
            try {
                $stmt = db()->prepare('SELECT id,name,email,password_hash,role,is_active FROM users WHERE email = ? LIMIT 1');
                $stmt->execute([$email]);
                $user = $stmt->fetch();
                if ($user && (int)$user['is_active'] === 1 && password_verify($password, $user['password_hash'])) {
                    session_regenerate_id(true);
                    $_SESSION['auth_user'] = [
                        'id' => (int)$user['id'],
                        'name' => (string)$user['name'],
                        'email' => (string)$user['email'],
                        'role' => (string)$user['role'],
                    ];
                    $_SESSION['login_failures'] = 0;
                    unset($_SESSION['login_blocked_until']);
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    db()->prepare('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([(int)$user['id']]);
                    $destination = (($user['role'] ?? '') === 'admin') ? './admin.php' : './portal.php';
                    $next = (string)($_POST['next'] ?? '');
                    if ($next !== '' && str_starts_with($next, '/') && !str_starts_with($next, '//') && !str_contains($next, "\n")) {
                        $destination = $next;
                    }
                    header('Location: ' . $destination);
                    exit;
                }
                $failures = (int)($_SESSION['login_failures'] ?? 0) + 1;
                $_SESSION['login_failures'] = $failures;
                if ($failures >= 5) {
                    $_SESSION['login_blocked_until'] = $now + 60;
                    $_SESSION['login_failures'] = 0;
                    $error = 'Demasiados intentos. La entrada quedó pausada durante 60 segundos.';
                } else {
                    $error = 'Correo o contraseña incorrectos, o la cuenta está desactivada.';
                }
            } catch (Throwable $e) {
                $error = 'No se pudo consultar la base de datos. Revisa la configuración MySQL y las tablas de autenticación.';
            }
        }
    }
}
$next = (string)($_GET['next'] ?? '');
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#10243f">
<title>Acceder a Aula 3D | Diseña y explora escenarios</title>
<style>
:root{font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:#17243a;background:#eef3f9;font-synthesis:none}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 5% 12%,#d6e8fb 0,transparent 30%),#eef3f9;display:grid;place-items:center;padding:24px}
.layout{width:min(1120px,100%);min-height:650px;background:#fff;border:1px solid #e1e8f0;border-radius:28px;overflow:hidden;display:grid;grid-template-columns:1.12fr .88fr;box-shadow:0 32px 90px #17345420}
.visual{position:relative;isolation:isolate;overflow:hidden;padding:54px 54px 42px;color:#fff;background:linear-gradient(145deg,#0c2340 0%,#123d69 52%,#1769a6 100%)}
.visual:before,.visual:after{content:"";position:absolute;z-index:-1;border:1px solid #ffffff24;border-radius:50%;width:520px;height:520px;right:-260px;top:-180px;box-shadow:0 0 0 44px #ffffff08,0 0 0 92px #ffffff08}
.visual:after{width:360px;height:360px;right:auto;left:-230px;top:auto;bottom:-230px;box-shadow:0 0 0 34px #ffffff08}
.brand{display:flex;align-items:center;gap:12px}.mark{height:46px;width:46px;border-radius:15px;display:grid;place-items:center;background:linear-gradient(140deg,#6db7ff,#2872c7);font-weight:950;letter-spacing:-1px;box-shadow:0 12px 28px #00182c55}.brand strong{display:block;font-size:16px}.brand small{display:block;color:#b9d7f2;font-size:12px;margin-top:3px}
.eyebrow{margin-top:76px;color:#9bd3ff;font-size:11px;letter-spacing:2.1px;font-weight:900}.visual h1{font-size:clamp(32px,4vw,48px);line-height:1.08;letter-spacing:-1.5px;max-width:510px;margin:15px 0}.visual p{max-width:490px;color:#d1e4f6;line-height:1.65;font-size:15px;margin:0}
.features{display:flex;gap:9px;flex-wrap:wrap;margin-top:27px}.feature{border:1px solid #ffffff30;background:#ffffff12;border-radius:100px;padding:8px 11px;color:#e8f5ff;font-size:12px;font-weight:700;backdrop-filter:blur(10px)}
.scene{position:absolute;left:52px;right:44px;bottom:40px;height:170px;border:1px solid #ffffff24;border-radius:18px;background:linear-gradient(135deg,#c5def51c,#ffffff0a);overflow:hidden;perspective:700px}
.scene-grid{position:absolute;inset:0;background-image:linear-gradient(#b6d8f31c 1px,transparent 1px),linear-gradient(90deg,#b6d8f31c 1px,transparent 1px);background-size:26px 26px;transform:perspective(360px) rotateX(57deg) scale(1.55);transform-origin:center bottom;top:-24px}
.block{position:absolute;bottom:35px;border:1px solid #b9dcffb0;background:linear-gradient(145deg,#8dc6f2aa,#2c75b9aa);box-shadow:inset 0 0 20px #ffffff27,0 15px 24px #00182c55;transform:skewY(-25deg)}.block.a{left:17%;width:92px;height:72px}.block.b{left:43%;width:112px;height:104px;bottom:35px;background:linear-gradient(145deg,#d5e9f2dd,#6d9cb9aa)}.block.c{left:72%;width:72px;height:55px;bottom:35px}.scene-label{position:absolute;right:15px;top:13px;font-size:10px;letter-spacing:1.3px;color:#d6edff;font-weight:800}
.login-side{display:flex;align-items:center;justify-content:center;padding:50px 48px;background:linear-gradient(180deg,#fff,#fbfdff)}.login-inner{width:min(100%,370px)}.mini-brand{display:none}.login-side h2{font-size:28px;letter-spacing:-.7px;margin:0 0 8px;color:#14243a}.subtitle{margin:0 0 27px;color:#718096;line-height:1.55;font-size:14px}.field{display:block;margin:16px 0 0;font-size:12px;font-weight:800;color:#40536c}.field input{width:100%;margin-top:8px;padding:14px;border:1px solid #d8e2ee;background:#fbfcfe;border-radius:11px;font:inherit;font-size:14px;color:#17243a;outline:none;transition:.2s}.field input:focus{border-color:#438bd0;box-shadow:0 0 0 4px #438bd01b;background:#fff}.btn{width:100%;border:0;border-radius:11px;padding:14px 16px;margin-top:23px;background:linear-gradient(100deg,#185da7,#287fc4);color:#fff;font:inherit;font-weight:850;cursor:pointer;box-shadow:0 10px 22px #1b67ad2a}.btn:hover{filter:brightness(1.05);transform:translateY(-1px)}.error,.notice{padding:12px 13px;border-radius:10px;margin:15px 0;font-size:12px;line-height:1.5}.error{background:#fff0ef;color:#a32d27;border:1px solid #f3c5c1}.notice{background:#eef6ff;color:#245a96;border:1px solid #cfe2f7}.notice a{color:#174f95;font-weight:800}.trust{display:flex;align-items:center;gap:8px;margin-top:20px;color:#7e8da1;font-size:11px}.trust:before{content:"✓";height:19px;width:19px;border-radius:50%;display:grid;place-items:center;background:#e9f7ef;color:#16834b;font-weight:900}.foot{margin-top:42px;color:#9aa6b5;font-size:11px;text-align:center}
@media(max-width:820px){.layout{grid-template-columns:1fr;max-width:510px;min-height:0}.visual{padding:30px;min-height:355px}.eyebrow{margin-top:45px}.visual h1{font-size:35px}.visual p{font-size:13px}.scene{left:30px;right:30px;bottom:22px;height:105px}.block{bottom:18px!important}.block.a{height:44px}.block.b{height:62px}.block.c{height:34px}.features{margin-top:18px}.login-side{padding:36px 30px}.foot{margin-top:26px}}
@media(max-width:420px){body{padding:10px}.layout{border-radius:19px}.visual{padding:24px;min-height:335px}.visual h1{font-size:31px}.login-side{padding:32px 23px}.scene{left:24px;right:24px}}
</style>
</head>
<body>
<main class="layout">
<section class="visual" aria-label="Aula 3D">
  <div class="brand"><div class="mark">3D</div><div><strong>Aula 3D</strong><small>Diseño y recorridos virtuales</small></div></div>
  <div class="eyebrow">CREA · EXPLORA · SIMULA</div>
  <h1>Convierte tus espacios en experiencias 3D.</h1>
  <p>Construye escenarios, organiza ambientes y permite que tu equipo los recorra en primera persona desde el navegador.</p>
  <div class="features"><span class="feature">◆ Editor de escenarios</span><span class="feature">◎ Recorrido 3D</span><span class="feature">↗ Simulación de evacuación</span></div>
  <div class="scene" aria-hidden="true"><div class="scene-grid"></div><div class="scene-label">VISTA 3D · EN TIEMPO REAL</div><div class="block a"></div><div class="block b"></div><div class="block c"></div></div>
</section>
<section class="login-side">
<div class="login-inner">
  <div class="mini-brand"><div class="mark">3D</div></div>
  <h2>Inicia sesión</h2><p class="subtitle">Accede a tus escenarios asignados o administra el espacio de trabajo.</p>
  <?php if ($error !== ''): ?><div class="error"><?=h($error)?></div><?php endif; ?>
  <?php if ($setupMessage !== ''): ?><div class="notice"><?=h($setupMessage)?> <?php if (str_contains($setupMessage, 'Crea la cuenta')): ?><a href="./first-admin.php">Crear administrador inicial</a><?php endif; ?></div><?php endif; ?>
  <form method="post" autocomplete="on"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="next" value="<?=h($next)?>">
    <label class="field">Correo electrónico<input name="email" type="email" maxlength="190" autocomplete="username" placeholder="nombre@empresa.com" required autofocus></label>
    <label class="field">Contraseña<input name="password" type="password" autocomplete="current-password" placeholder="Ingresa tu contraseña" required></label>
    <button class="btn" type="submit">Entrar a Aula 3D <span aria-hidden="true">→</span></button>
  </form>
  <div class="trust">Acceso protegido y escenarios según permisos de usuario.</div>
  <div class="foot">Aula 3D · Herramienta para crear y explorar entornos virtuales</div>
</div>
</section>
</main>
</body></html>
