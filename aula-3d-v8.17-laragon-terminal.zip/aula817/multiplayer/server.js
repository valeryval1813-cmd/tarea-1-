import { WebSocketServer } from 'ws';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const secret = fs.readFileSync(path.join(here, 'secret.key'), 'utf8').trim();
if (secret.length < 32 || secret.startsWith('REPLACE_')) {
  console.error('Configura multiplayer/secret.key con una clave aleatoria de al menos 32 caracteres.');
  process.exit(1);
}
const PORT = Number(process.env.MULTIPLAYER_PORT || 3001);
const HOST = process.env.MULTIPLAYER_HOST || '0.0.0.0';
const wss = new WebSocketServer({ host: HOST, port: PORT, maxPayload: 4096 });
const clients = new Map();
const lastChat = new Map();
const rooms = new Map();

function decodeTicket(ticket) {
  if (typeof ticket !== 'string' || ticket.length > 2048) return null;
  const [body, signature] = ticket.split('.');
  if (!body || !signature) return null;
  const expected = crypto.createHmac('sha256', secret).update(body).digest();
  let received;
  try { received = Buffer.from(signature.replace(/-/g, '+').replace(/_/g, '/'), 'base64'); } catch { return null; }
  if (received.length !== expected.length || !crypto.timingSafeEqual(received, expected)) return null;
  try {
    const data = JSON.parse(Buffer.from(body.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
    if (!Number.isInteger(data.sub) || data.exp < Math.floor(Date.now() / 1000) || !/^senati-scenario-[1-9][0-9]{0,8}$/.test(String(data.room || ''))) return null;
    return { id: String(data.sub), name: String(data.name || 'Usuario').replace(/[<>\u0000-\u001f]/g, '').slice(0, 32), room: data.room };
  } catch { return null; }
}
function roomPlayers(room) {
  return [...clients.values()].filter(p => p.room === room).map(p => ({ id: p.id, name: p.name, x: p.x, z: p.z, yaw: p.yaw, moving: p.moving }));
}
function send(ws, payload) { if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(payload)); }
function broadcast(room, payload, except = null) {
  for (const [ws, player] of clients) if (player.room === room && ws !== except) send(ws, payload);
}
function cleanText(value) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 240);
}

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, 'http://localhost');
  const identity = decodeTicket(url.searchParams.get('ticket'));
  if (!identity) { ws.close(1008, 'Autenticación requerida'); return; }
  const player = { ...identity, x: 0, z: 57, yaw: 0, moving: false, lastMove: Date.now() };
  clients.set(ws, player);
  send(ws, { type: 'welcome', selfId: player.id, players: roomPlayers(player.room) });
  broadcast(player.room, { type: 'join', player: { id: player.id, name: player.name, x: player.x, z: player.z, yaw: player.yaw, moving: false } }, ws);

  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type === 'move') {
      const now = Date.now();
      if (now - player.lastMove < 35) return;
      const x = Number(msg.x), z = Number(msg.z), yaw = Number(msg.yaw);
      if (![x, z, yaw].every(Number.isFinite) || Math.abs(x) > 115 || Math.abs(z) > 115) return;
      const elapsed = Math.min((now - player.lastMove) / 1000, 0.25);
      const distance = Math.hypot(x - player.x, z - player.z);
      if (distance > Math.max(2.5, elapsed * 12)) return;
      player.x = x; player.z = z; player.yaw = yaw; player.moving = Boolean(msg.moving); player.lastMove = now;
      broadcast(player.room, { type: 'move', player: { id: player.id, x, z, yaw, moving: player.moving } }, ws);
    } else if (msg.type === 'chat') {
      const text = cleanText(msg.text);
      if (!text) return;
      const previous = lastChat.get(player.id) || 0;
      if (Date.now() - previous < 700) { send(ws, { type: 'notice', text: 'Espera un momento antes de enviar otro mensaje.' }); return; }
      lastChat.set(player.id, Date.now());
      const packet = { type: 'chat', id: crypto.randomUUID(), userId: player.id, name: player.name, text, at: Date.now() };
      broadcast(player.room, packet);
    } else if (msg.type === 'ping') send(ws, { type: 'pong', at: Date.now() });
  });
  ws.on('close', () => {
    clients.delete(ws);
    broadcast(player.room, { type: 'leave', id: player.id });
  });
});

setInterval(() => {
  for (const ws of wss.clients) if (ws.readyState === ws.OPEN) send(ws, { type: 'presence', count: clients.size });
}, 5000);
console.log(`Aula 3D multijugador escuchando en ws://${HOST}:${PORT}`);
