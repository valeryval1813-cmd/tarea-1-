import * as THREE from 'three';
import { createSceneModel } from './scene-models.js';
import { buildTowerWorld, TOWER_LAYOUT } from './tower-world.js';

const root = document.getElementById('world');
const notice = document.getElementById('connection-notice');
const onlineCount = document.getElementById('online-count');
const chatMessages = document.getElementById('chat-messages');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const chatBox = document.getElementById('chat');
const chatToggle = document.getElementById('chat-toggle');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x91b9d0);
scene.fog = new THREE.Fog(0x91b9d0, 95, 260);
const camera = new THREE.PerspectiveCamera(65, 1, 0.1, 500);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.7));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
root.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xe5f5ff, 0x66775a, 2.0));
const sun = new THREE.DirectionalLight(0xfff1d6, 2.5);
sun.position.set(-45, 75, 35); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048); sun.shadow.camera.left = -120; sun.shadow.camera.right = 120; sun.shadow.camera.top = 120; sun.shadow.camera.bottom = -120; scene.add(sun);
const defaultCampusGroup = new THREE.Group(); defaultCampusGroup.name = 'Campus base'; scene.add(defaultCampusGroup);
const mat = (color, roughness = .8, metalness = 0) => new THREE.MeshStandardMaterial({ color, roughness, metalness });
const mats = {
 grass: mat(0x557b54), road: mat(0x303b45), sidewalk: mat(0xc5c9c7), concrete: mat(0x9ba5aa), glass: new THREE.MeshPhysicalMaterial({ color: 0x83b7ce, roughness: .22, metalness: .12, transparent: true, opacity: .72 }),
 white: mat(0xe8edf0), dark: mat(0x303b46), blue: mat(0x0877b9), green: mat(0x356d4a), yellow: mat(0xe5bd53)
};
function box(w,h,d,material,x,y,z,cast=true,receive=true){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=cast;m.receiveShadow=receive;defaultCampusGroup.add(m);return m;}
function label(text,x,y,z){const c=document.createElement('canvas');c.width=512;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#123a5a';ctx.fillRect(0,0,512,128);ctx.fillStyle='#fff';ctx.font='bold 48px Arial';ctx.textAlign='center';ctx.fillText(text,256,82);const tex=new THREE.CanvasTexture(c);const mesh=new THREE.Mesh(new THREE.PlaneGeometry(15,3.75),new THREE.MeshBasicMaterial({map:tex,transparent:true}));mesh.position.set(x,y,z);defaultCampusGroup.add(mesh);}
// Terreno, calles y veredas del campus inicial.
box(250,.5,250,mats.grass,0,-.35,0,false,true);
box(250,.12,18,mats.road,0,-.05,57,false,true);box(250,.12,16,mats.road,0,-.05,-63,false,true);box(18,.12,250,mats.road,65,-.05,0,false,true);box(18,.12,250,mats.road,-65,-.05,0,false,true);
for(let z=-115;z<120;z+=9){box(5,.025,.28,mats.yellow,0,.03,z,false,false);}
box(250,.22,4,mats.sidewalk,0,.03,47,false,true);box(250,.22,4,mats.sidewalk,0,.03,67,false,true);box(4,.22,250,mats.sidewalk,53,.03,0,false,true);box(4,.22,250,mats.sidewalk,77,.03,0,false,true);
// Plaza de ingreso.
box(62,.18,42,mats.sidewalk,0,.08,28,false,true);
for(let x=-26;x<=26;x+=13)for(let z=15;z<=41;z+=13){const tree=new THREE.Group();const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.35,.48,4,8),mat(0x72543a));trunk.position.y=2;tree.add(trunk);const crown=new THREE.Mesh(new THREE.SphereGeometry(2.2,12,10),mat(0x3c7547));crown.position.y=5;tree.add(crown);tree.position.set(x,.1,z);tree.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});defaultCampusGroup.add(tree);}
// Tres bloques de campus estilizados inspirados en la torre de referencia.
function tower(cx,cz,width,depth,floors,name){const height=floors*3.6;box(width,height,depth,mats.concrete,cx,height/2,cz);box(width+1,.6,depth+1,mats.dark,cx,height+.3,cz);for(let f=0;f<floors;f++){const y=1.8+f*3.6;box(width+.12,.24,depth+.12,mats.white,cx,y,cz);for(let side of [-1,1]){for(let x=-width/2+2;x<width/2-1;x+=3.2){box(2.45,2.45,.12,mats.glass,cx+x,y,cz+side*(depth/2+.08),false,true);box(.12,2.55,.2,mats.white,cx+x+1.25,y,cz+side*(depth/2+.12),false,false);}}for(let x=-width/2+1;x<=width/2-1;x+=4){box(.16,3.1,.18,mats.white,cx+x,y,cz-depth/2-.12,false,false);}}
// Núcleo oscuro y marquesina de acceso.
box(width*.22,height+.3,depth+.8,mats.dark,cx+width*.33,height/2,cz);box(width*.36,.5,4,mats.blue,cx,height*.12,cz+depth/2+2);label(name,cx,height+5,cz+depth/2+1);
}
tower(-30,-27,34,42,10,'TORRE SENATI');tower(18,-32,28,38,8,'BLOQUE B');tower(57,-28,26,36,8,'BLOQUE C');
// Puentes elevados entre bloques.
box(19,1.1,5,mats.concrete,-5,17,-28);box(17,.3,5,mats.white,39,14,-28);
// Acceso, jardines y mobiliario urbano.
box(8,1.2,1.1,mats.dark,0,.7,6);box(7,.25,.5,mats.blue,0,1.4,6);
for(let i=0;i<8;i++){const x=-32+i*9;box(3,.65,1.2,mat(0x7c8588),x,.35,52);box(3,.08,1.2,mats.dark,x,.72,52,false,false);}


const integratedScenarioGroup = new THREE.Group(); integratedScenarioGroup.name = 'Escenario del editor'; scene.add(integratedScenarioGroup);
let loadedScenario = null;
function scenarioMaterial(color, roughness=.86){return new THREE.MeshStandardMaterial({color,roughness});}
function addScenarioRoom(scenario){
  const width=Number(scenario.width_m)||20, depth=Number(scenario.depth_m)||12, height=Number(scenario.height_m)||3.35;
  const appearance=typeof scenario.appearance_json==='string'?JSON.parse(scenario.appearance_json||'{}'):(scenario.appearance_json||{});
  const floors=Array.isArray(appearance.floors)&&appearance.floors.length?appearance.floors:[{id:1,name:'Piso 1',elevation:0,height}];
  const floorMat=scenarioMaterial(appearance.floorColor||'#dfe5e9');
  floors.forEach((floor,index)=>{
    const elevation=Number(floor.elevation)||0;
    const fm=scenarioMaterial(floor.floorColor||appearance.floorColor||'#dfe5e9');
    const plane=new THREE.Mesh(new THREE.PlaneGeometry(width,depth),fm);plane.rotation.x=-Math.PI/2;plane.position.set(0,elevation,0);plane.receiveShadow=true;integratedScenarioGroup.add(plane);
    const fh=Number(floor.height)||height; const wallMat=scenarioMaterial(appearance.wallColor||'#e4e9ee');
    const wall=(w,h,d,x,y,z)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),wallMat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;integratedScenarioGroup.add(m);};
    const t=.18; wall(width,fh,t,0,elevation+fh/2,-depth/2); wall((width-1.8)/2,fh,t,-(width+1.8)/4,elevation+fh/2,depth/2); wall((width-1.8)/2,fh,t,(width+1.8)/4,elevation+fh/2,depth/2); wall(t,fh,depth,-width/2,elevation+fh/2,0);wall(t,fh,depth,width/2,elevation+fh/2,0);
  });
  addSavedObjects(scenario,appearance);
}
function addSavedObjects(scenario,appearance={}){
  const objects=Array.isArray(scenario.objects)?scenario.objects:[];
  for(const object of objects){
    const key=String(object.catalog_key||object.catalogKey||'');
    if(!key)continue;
    let config=object.config_json||object.config||{};if(typeof config==='string'){try{config=JSON.parse(config)}catch{config={}}}
    let model;try{model=createSceneModel(key,{seated:Boolean(config.seated),screenMode:config.screenMode||'windows11',personConfig:config.personConfig||{},appearance:{deskColor:appearance.deskColor||'#1559a8',chairColor:appearance.chairColor||'#202a38'}})}catch{continue}
    const p={x:Number(object.pos_x??object.position?.x)||0,y:Number(object.pos_y??object.position?.y)||0,z:Number(object.pos_z??object.position?.z)||0};
    const r={x:Number(object.rot_x??object.rotation?.x)||0,y:Number(object.rot_y??object.rotation?.y)||0,z:Number(object.rot_z??object.rotation?.z)||0};
    const sc={x:Number(object.scale_x??object.scale?.x)||1,y:Number(object.scale_y??object.scale?.y)||1,z:Number(object.scale_z??object.scale?.z)||1};
    model.position.set(p.x,p.y,p.z);model.rotation.set(r.x,r.y,r.z);model.scale.set(sc.x,sc.y,sc.z);integratedScenarioGroup.add(model);
  }
}

async function loadSharedScenario(){
  const id=Number(window.AULA_WORLD_SCENARIO_ID||0);if(!id)throw new Error('No se seleccionó un escenario. Regresa al portal.');
  const response=await fetch(`./api/scenarios.php?action=load&id=${encodeURIComponent(id)}`,{credentials:'same-origin',cache:'no-store'});
  if(!response.ok)throw new Error('No se pudo cargar el escenario o no tienes permiso.');
  const data=await response.json();if(!data.success||!data.scenario)throw new Error(data.message||'Escenario no disponible.');
  loadedScenario=data.scenario;const appearance=typeof loadedScenario.appearance_json==='string'?JSON.parse(loadedScenario.appearance_json||'{}'):(loadedScenario.appearance_json||{});
  integratedScenarioGroup.clear();
  if(appearance.buildingPlan==='senati-tower'){
    defaultCampusGroup.visible=false;
    const floors=Array.isArray(appearance.floors)?appearance.floors:[];
    const built=buildTowerWorld(integratedScenarioGroup,appearance,{height:Number(loadedScenario.height_m)||4.45});
    integratedScenarioGroup.userData.tower=built;
    addSavedObjects(loadedScenario,appearance);
    x=0;z=Number(built.layout?.streetZ||TOWER_LAYOUT.streetZ)-11;yaw=Math.PI;
  }else{
    defaultCampusGroup.visible=true;
    addScenarioRoom(loadedScenario);x=0;z=(Number(loadedScenario.depth_m)||12)/2+3;yaw=Math.PI;
  }
  local.position.set(x,0,z);local.rotation.y=yaw;camera.position.set(x,4.2,z+10);camera.lookAt(x,1.5,z);
  document.title=`${loadedScenario.name} · Campus virtual SENATI`;
  logMessage('',`Escenario cargado: ${loadedScenario.name}. Los usuarios que entren a este mismo escenario compartirán el mundo.`,true);
}

function setNameTag(group,name){if(group.userData.nameTag){group.remove(group.userData.nameTag);group.userData.nameTag.material.map?.dispose();}const canvas=document.createElement('canvas');canvas.width=512;canvas.height=128;const ctx=canvas.getContext('2d');ctx.fillStyle='rgba(10,28,45,.88)';ctx.beginPath();ctx.roundRect(8,8,496,112,28);ctx.fill();ctx.fillStyle='#ffffff';ctx.font='bold 42px Arial';ctx.textAlign='center';ctx.fillText(String(name||'Usuario').slice(0,28),256,78);const texture=new THREE.CanvasTexture(canvas);const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,transparent:true,depthTest:false}));sprite.position.set(0,3.25,0);sprite.scale.set(3.4,.85,1);group.add(sprite);group.userData.nameTag=sprite;}
function makeAvatar(color=0x1687c8){const group=new THREE.Group();const skin=mat(0xd8a77f), shirt=mat(color), pants=mat(0x263d55), shoes=mat(0x18232e), hair=mat(0x292421);const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.78,4,8),shirt);torso.position.y=1.55;group.add(torso);const head=new THREE.Mesh(new THREE.SphereGeometry(.34,16,12),skin);head.position.y=2.48;group.add(head);const hairCap=new THREE.Mesh(new THREE.SphereGeometry(.35,14,8,0,Math.PI*2,0,Math.PI*.55),hair);hairCap.position.y=2.57;group.add(hairCap);const eyes=mat(0x18202a);for(const s of [-1,1]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.035,8,6),eyes);eye.position.set(s*.12,2.5,.3);group.add(eye);}const limbs=[];for(const s of [-1,1]){const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.14,.58,4,7),shirt);arm.position.set(s*.62,1.55,0);arm.rotation.z=s*.16;group.add(arm);const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.18,.68,4,7),pants);leg.position.set(s*.23,.62,0);group.add(leg);const foot=new THREE.Mesh(new THREE.BoxGeometry(.34,.16,.55),shoes);foot.position.set(s*.23,.13,.12);group.add(foot);limbs.push({arm,leg,foot,side:s});}group.userData.limbs=limbs;group.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});return group;}
const local=makeAvatar(0x087fc5);scene.add(local);const others=new Map();const playerData=new Map();
let socket=null,selfId=null,connected=false;let x=0,z=57,yaw=0,velocity=0,remoteTarget=new Map();const keys=new Set();let dragging=false,lastPointer=null,cameraYaw=0.0,cameraPitch=.24;let lastSend=0,lastChatFocus=false;
function addOther(p){if(p.id===selfId||others.has(p.id))return;const avatar=makeAvatar(0x8b65c8);setNameTag(avatar,p.name||'Usuario');avatar.position.set(p.x,0,p.z);avatar.rotation.y=p.yaw||0;scene.add(avatar);others.set(p.id,avatar);playerData.set(p.id,p.name||'Usuario');remoteTarget.set(p.id,{x:p.x,z:p.z,yaw:p.yaw||0,moving:false});}
function logMessage(name,text,system=false){const el=document.createElement('div');el.className='msg'+(system?' system':'');if(system){el.textContent=text;}else{const b=document.createElement('b');b.textContent=name+':';const span=document.createElement('span');span.textContent=' '+text;el.append(b,span);}chatMessages.appendChild(el);while(chatMessages.children.length>80)chatMessages.removeChild(chatMessages.firstChild);chatMessages.scrollTop=chatMessages.scrollHeight;}
async function connect(){try{await loadSharedScenario();}catch(err){notice.textContent=err.message;return;}fetch(`./api/world-ticket.php?scenario=${encodeURIComponent(window.AULA_WORLD_SCENARIO_ID||'')}`,{credentials:'same-origin',cache:'no-store'}).then(r=>{if(!r.ok)throw new Error('No se pudo validar tu sesión');return r.json();}).then(data=>{setNameTag(local,data.name||'Tú');const protocol=location.protocol==='https:'?'wss:':'ws:';socket=new WebSocket(`${protocol}//${location.hostname}:3001/?ticket=${encodeURIComponent(data.ticket)}`);socket.addEventListener('open',()=>{connected=true;notice.hidden=true;logMessage('', 'Conectado al mundo compartido.',true);});socket.addEventListener('message',ev=>{let m;try{m=JSON.parse(ev.data);}catch{return;}if(m.type==='welcome'){selfId=m.selfId;(m.players||[]).forEach(addOther);onlineCount.textContent=`${(m.players||[]).length+1} conectado(s)`;}else if(m.type==='join'){addOther(m.player);logMessage('',`${m.player.name} entró al campus.`,true);}else if(m.type==='leave'){const name=playerData.get(m.id)||'Un usuario';const a=others.get(m.id);if(a)scene.remove(a);others.delete(m.id);remoteTarget.delete(m.id);playerData.delete(m.id);logMessage('',`${name} salió del campus.`,true);}else if(m.type==='move'){const t=remoteTarget.get(m.player.id);if(t){t.x=m.player.x;t.z=m.player.z;t.yaw=m.player.yaw;t.moving=m.player.moving;}}else if(m.type==='chat'){logMessage(m.name,m.text);}else if(m.type==='presence'){onlineCount.textContent=`${m.count} conectado(s)`;}else if(m.type==='notice'){logMessage('',m.text,true);}});socket.addEventListener('close',()=>{connected=false;notice.hidden=false;notice.textContent='Conexión perdida. Recarga la página para volver a entrar.';});socket.addEventListener('error',()=>{notice.hidden=false;notice.textContent='No se pudo conectar al servidor multijugador (puerto 3001).';});}).catch(err=>{notice.textContent=err.message;});}
connect();
chatForm.addEventListener('submit',e=>{e.preventDefault();const text=chatInput.value.trim();if(!text)return;if(socket?.readyState===WebSocket.OPEN)socket.send(JSON.stringify({type:'chat',text}));else logMessage('', 'No estás conectado al servidor.',true);chatInput.value='';chatInput.blur();});
chatToggle?.addEventListener('click',()=>{chatBox.classList.toggle('collapsed');chatToggle.textContent=chatBox.classList.contains('collapsed')?'Abrir':'Minimizar';});
window.addEventListener('keydown',e=>{if(document.activeElement===chatInput){if(e.key==='Escape')chatInput.blur();return;}if(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)){keys.add(e.code);e.preventDefault();}if(e.key==='Enter'){chatInput.focus();} });window.addEventListener('keyup',e=>keys.delete(e.code));
renderer.domElement.addEventListener('pointerdown',e=>{dragging=true;lastPointer={x:e.clientX,y:e.clientY};renderer.domElement.setPointerCapture(e.pointerId);});renderer.domElement.addEventListener('pointermove',e=>{if(!dragging||!lastPointer)return;const dx=e.clientX-lastPointer.x,dy=e.clientY-lastPointer.y;cameraYaw-=dx*.004;cameraPitch=THREE.MathUtils.clamp(cameraPitch+dy*.002,-.05,.65);lastPointer={x:e.clientX,y:e.clientY};});renderer.domElement.addEventListener('pointerup',()=>{dragging=false;lastPointer=null;});renderer.domElement.addEventListener('pointercancel',()=>{dragging=false;lastPointer=null;});
function resize(){const w=root.clientWidth,h=root.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);}window.addEventListener('resize',resize);resize();
const clock=new THREE.Clock();function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05);let forward=0,side=0;if(keys.has('KeyW')||keys.has('ArrowUp'))forward+=1;if(keys.has('KeyS')||keys.has('ArrowDown'))forward-=1;if(keys.has('KeyA')||keys.has('ArrowLeft'))side-=1;if(keys.has('KeyD')||keys.has('ArrowRight'))side+=1;const moving=forward!==0||side!==0;if(moving){const len=Math.hypot(forward,side);forward/=len;side/=len;const dirYaw=cameraYaw;const dx=(-Math.sin(dirYaw)*forward+Math.cos(dirYaw)*side)*7*dt;const dz=(-Math.cos(dirYaw)*forward-Math.sin(dirYaw)*side)*7*dt;x=THREE.MathUtils.clamp(x+dx,-112,112);z=THREE.MathUtils.clamp(z+dz,-112,112);yaw=Math.atan2(dx,dz);local.rotation.y=yaw;velocity+=dt*9;}else velocity=Math.max(0,velocity-dt*12);local.position.set(x,0,z);local.userData.limbs.forEach((l,i)=>{const phase=velocity>0?Math.sin(clock.elapsedTime*10+l.side*Math.PI)*.55:0;l.arm.rotation.x=phase*.75;l.leg.rotation.x=-phase;l.foot.rotation.x=-phase*.35;});const desired=new THREE.Vector3(x+Math.sin(cameraYaw)*10,4.2+cameraPitch*5,z+Math.cos(cameraYaw)*10);camera.position.lerp(desired,1-Math.exp(-dt*5));camera.lookAt(x,1.5,z);
for(const [id,a] of others){const t=remoteTarget.get(id);if(!t)continue;a.position.x=THREE.MathUtils.damp(a.position.x,t.x,8,dt);a.position.z=THREE.MathUtils.damp(a.position.z,t.z,8,dt);a.rotation.y=THREE.MathUtils.damp(a.rotation.y,t.yaw,8,dt);a.userData.limbs.forEach((l)=>{const phase=t.moving?Math.sin(clock.elapsedTime*10+l.side*Math.PI)*.45:0;l.arm.rotation.x=phase*.7;l.leg.rotation.x=-phase;});}
const now=performance.now();if(connected&&socket?.readyState===WebSocket.OPEN&&now-lastSend>65){socket.send(JSON.stringify({type:'move',x,z,yaw,moving}));lastSend=now;}renderer.render(scene,camera);}animate();
window.addEventListener('beforeunload',()=>socket?.close());
