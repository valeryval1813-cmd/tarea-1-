import * as THREE from 'three';

export const TOWER_LAYOUT = Object.freeze({
  // Huella ampliada para que el campus se sienta como un entorno explorable,
  // no como una maqueta compacta. Son medidas de modelado, no cotas oficiales.
  width: 220,
  depth: 180,
  centers: [-48, 0, 48],
  blockWidth: 36,
  blockDepth: 48,
  streetZ: 68,
  sidewalkZ: 59,
  stairOffsets: [-11, -8.2],
  stairTopZ: -11.6,
  stairBottomZ: -5.1,
  stairWidth: 2.1,
  elevatorOffsets: [-1.35, 1.35],
  // El frente del ascensor queda en el corredor central, visible desde el acceso.
  elevatorZ: -2.8,
  coreZ: -10.0,
});

const makeMat = (color, roughness = .78, metalness = 0) => new THREE.MeshStandardMaterial({ color, roughness, metalness });

function addBox(parent, w, h, d, material, x, y, z, options = {}) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  mesh.position.set(x, y, z);
  mesh.castShadow = options.castShadow !== false;
  mesh.receiveShadow = true;
  if (options.name) mesh.name = options.name;
  if (options.userData) Object.assign(mesh.userData, options.userData);
  parent.add(mesh);
  return mesh;
}

function addPlane(parent, w, d, material, x, y, z) {
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(w, d), material);
  plane.rotation.x = -Math.PI / 2;
  plane.position.set(x, y, z);
  plane.receiveShadow = true;
  parent.add(plane);
  return plane;
}

function addSolidWall(parent, collision, floorIndex, x, y, z, w, h, d, material, opts = {}) {
  addBox(parent, w, h, d, material, x, y, z, { name: opts.name || 'tower-wall' });
  if (opts.solid !== false) collision.push({ x, z, halfW: w / 2, halfD: d / 2, minY: y - h / 2, maxY: y + h / 2, floorIndex });
}

function addWallAlongX(parent, collision, floorIndex, cx, z, x1, x2, y, h, material, gaps = []) {
  const sorted = [...gaps].sort((a, b) => a[0] - b[0]);
  let cursor = x1;
  for (const [gapStart, gapEnd] of sorted) {
    if (gapStart > cursor + .02) addSolidWall(parent, collision, floorIndex, (cursor + gapStart) / 2, y, z, gapStart - cursor, h, .22, material);
    cursor = Math.max(cursor, gapEnd);
  }
  if (x2 > cursor + .02) addSolidWall(parent, collision, floorIndex, (cursor + x2) / 2, y, z, x2 - cursor, h, .22, material);
}

function addWallAlongZ(parent, collision, floorIndex, x, z1, z2, y, h, material, gaps = []) {
  const sorted = [...gaps].sort((a, b) => a[0] - b[0]);
  let cursor = z1;
  for (const [gapStart, gapEnd] of sorted) {
    if (gapStart > cursor + .02) addSolidWall(parent, collision, floorIndex, x, y, (cursor + gapStart) / 2, .22, h, gapStart - cursor, material);
    cursor = Math.max(cursor, gapEnd);
  }
  if (z2 > cursor + .02) addSolidWall(parent, collision, floorIndex, x, y, (cursor + z2) / 2, .22, h, z2 - cursor, material);
}

function addLabel(parent, text, x, y, z, color = '#164675', width = 3.5, height = .88, rotationY = 0) {
  const canvas = document.createElement('canvas');
  canvas.width = 512; canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = color; ctx.font = '900 54px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, 256, 64);
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(width, height), new THREE.MeshBasicMaterial({ map: texture, transparent: true, side: THREE.DoubleSide }));
  plane.position.set(x, y, z); plane.rotation.y = rotationY; parent.add(plane);
}

function buildSite(parent, layout = TOWER_LAYOUT) {
  const grass = makeMat(0x829d79, .96), plaza = makeMat(0xc4cbd0, .9), road = makeMat(0x343b43, .97), sidewalk = makeMat(0xb8bec4, .92), curb = makeMat(0xe2e4e6, .9), paint = makeMat(0xf5f2e8, .72), planter = makeMat(0x59656d, .9), bark = makeMat(0x76543b, .96), foliage = makeMat(0x4d8655, .94), lamp = makeMat(0x3d4b59, .45, .4), lampGlow = new THREE.MeshStandardMaterial({ color: 0xfff2c4, emissive: 0xffdc8a, emissiveIntensity: .75 });
  const halfW = layout.width / 2, halfD = layout.depth / 2;
  addPlane(parent, layout.width, layout.depth, grass, 0, -.34, 0);
  // Plaza de ingreso conectada con la vereda y la puerta principal.
  const plazaZ = layout.blockDepth / 2 + 9.5;
  addPlane(parent, layout.width * .76, 20, plaza, 0, -.12, plazaZ);
  for (let x = -halfW * .72; x <= halfW * .72; x += 2) for (let z = plazaZ - 8.5; z <= plazaZ + 8.5; z += 2) {
    addBox(parent, 1.96, .018, 1.96, makeMat(0xb2bbc2, .92), x, -.095, z, { castShadow: false });
  }
  // Vía frontal y veredas: piezas continuas del entorno exterior.
  addPlane(parent, layout.width, 15.2, road, 0, -.10, layout.streetZ);
  addPlane(parent, layout.width, 3.6, sidewalk, 0, -.045, layout.sidewalkZ);
  addPlane(parent, layout.width, 3.6, sidewalk, 0, -.045, layout.streetZ + 9.4);
  // Calles y aceras perimetrales para dar continuidad al mundo virtual.
  for (const side of [-1, 1]) {
    const roadX = side * (halfW - 3.8), walkX = side * (halfW - 10.0);
    addPlane(parent, 7.2, layout.depth, road, roadX, -.105, 0);
    addPlane(parent, 3.2, layout.depth, sidewalk, walkX, -.045, 0);
    for (let z = -halfD + 5; z < halfD - 2; z += 8) addBox(parent, .16, .025, 3.2, paint, roadX, -.035, z, { castShadow: false });
  }
  for (const z of [layout.streetZ - 7.6, layout.streetZ + 7.6]) addBox(parent, layout.width, .15, .24, curb, 0, -.01, z);
  for (let x = -halfW + 5; x <= halfW - 5; x += 9) {
    addBox(parent, 3.4, .025, .16, paint, x, -.035, layout.streetZ - 1.5, { castShadow: false });
    addBox(parent, 3.4, .025, .16, paint, x, -.035, layout.streetZ + 1.5, { castShadow: false });
  }
  // Cruce peatonal alineado con el ingreso del campus.
  for (let i = 0; i < 10; i++) addBox(parent, .62, .024, 3.4, paint, -3.1 + i * .7, -.025, layout.streetZ, { castShadow: false });
  // Jardineras, árboles y luminarias distribuidos alrededor del campus.
  for (const x of [-78, -64, -50, 50, 64, 78]) {
    addBox(parent, 3.2, .45, 1.8, planter, x, .12, plazaZ + 1.4);
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.11, .16, 2.4, 12), bark); trunk.position.set(x, 1.5, plazaZ + 1.4); parent.add(trunk);
    const crown = new THREE.Mesh(new THREE.SphereGeometry(1.35, 16, 12), foliage); crown.position.set(x, 3.0, plazaZ + 1.4); crown.scale.set(1, 1.15, 1); parent.add(crown);
  }
  for (const x of [-78, -56, -34, 34, 56, 78]) {
    addBox(parent, .12, 5.3, .12, lamp, x, 2.55, layout.sidewalkZ);
    addBox(parent, .82, .12, .16, lamp, x + .28, 5.12, layout.sidewalkZ);
    addBox(parent, .48, .08, .35, lampGlow, x + .56, 5.02, layout.sidewalkZ);
  }
  // Pequeñas áreas verdes laterales que amplían el campus sin cerrar la circulación.
  for (const side of [-1, 1]) {
    addPlane(parent, 10, layout.depth * .58, grass, side * (halfW - 17), -.30, -4);
    for (let z = -halfD * .62; z <= halfD * .62; z += 13) {
      const x = side * (halfW - 17);
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.09, .13, 2.1, 10), bark);
      trunk.position.set(x, 1.25, z); parent.add(trunk);
      const crown = new THREE.Mesh(new THREE.SphereGeometry(1.2, 14, 10), foliage);
      crown.position.set(x, 2.8, z); parent.add(crown);
    }
  }
}

function addFacadeBay(parent, collision, floorIndex, cx, blockWidth, blockDepth, height, materials, groundEntrance) {
  const front = blockDepth / 2;
  const back = -blockDepth / 2;
  const glass = materials.glass, steel = materials.steel, dark = materials.dark;
  // Cristal frontal con entrada libre al centro en todos los bloques en planta baja.
  const gap = groundEntrance ? 3.5 : 0;
  const leftEnd = cx - blockWidth / 2, rightEnd = cx + blockWidth / 2;
  if (gap) {
    addBox(parent, (blockWidth - gap) / 2, height - .38, .12, glass, cx - gap / 2 - (blockWidth - gap) / 4, height / 2, front, { name: 'curtain-wall' });
    addBox(parent, (blockWidth - gap) / 2, height - .38, .12, glass, cx + gap / 2 + (blockWidth - gap) / 4, height / 2, front, { name: 'curtain-wall' });
    addSolidWall(parent, collision, floorIndex, cx - gap / 2 - (blockWidth - gap) / 4, height / 2, front, (blockWidth - gap) / 2, height - .38, .12, glass);
    addSolidWall(parent, collision, floorIndex, cx + gap / 2 + (blockWidth - gap) / 4, height / 2, front, (blockWidth - gap) / 2, height - .38, .12, glass);
  } else {
    addSolidWall(parent, collision, floorIndex, cx, height / 2, front, blockWidth, height - .38, .12, glass);
  }
  // Zócalo y dintel de fachada.
  addBox(parent, blockWidth, .22, .32, steel, cx, .17, front + .08);
  addBox(parent, blockWidth, .22, .32, steel, cx, height - .17, front + .08);
  for (let i = 0; i <= 7; i++) {
    const x = leftEnd + i * blockWidth / 7;
    addBox(parent, .075, height - .22, .15, steel, x, height / 2, front + .08);
  }
  // Laterales, machones y parte posterior.
  addSolidWall(parent, collision, floorIndex, leftEnd, height / 2, 0, .56, height, blockDepth, dark);
  addSolidWall(parent, collision, floorIndex, rightEnd, height / 2, 0, .56, height, blockDepth, dark);
  addSolidWall(parent, collision, floorIndex, cx, height / 2, back, blockWidth, height, .30, dark);
  for (const z of [-blockDepth * .3, 0, blockDepth * .3]) {
    addBox(parent, .10, height - .48, .16, steel, leftEnd + .32, height / 2, z);
    addBox(parent, .10, height - .48, .16, steel, rightEnd - .32, height / 2, z);
  }
  return { front, back, leftEnd, rightEnd };
}

function buildFloorWithCoreOpening(parent, cx, width, depth, floorMat, slabMat, open = true, layout = TOWER_LAYOUT) {
  const left = cx - width / 2, right = cx + width / 2, back = -depth / 2, front = depth / 2;
  if (!open) {
    addBox(parent, width, .28, depth, slabMat, cx, -.15, 0);
    addPlane(parent, width - .65, depth - .65, floorMat, cx, .005, 0);
    return;
  }
  // Huecos independientes y contenidos: caja de escalera y seis pozos de ascensor.
  // El resto de la planta conserva losa continua para evitar caídas por grandes atrios.
  const stairMinX = cx + Math.min(...layout.stairOffsets) - layout.stairWidth / 2 - .82;
  const stairMaxX = cx + Math.max(...layout.stairOffsets) + layout.stairWidth / 2 + .82;
  const holes = [{
    minX: stairMinX, maxX: stairMaxX,
    minZ: layout.stairTopZ - .82, maxZ: layout.stairBottomZ + .82
  }, ...layout.elevatorOffsets.map(offset => ({
    minX: cx + offset - 1.12, maxX: cx + offset + 1.12,
    minZ: layout.elevatorZ - 1.42, maxZ: layout.elevatorZ + 1.42
  }))];
  const xs = [...new Set([left, right, ...holes.flatMap(h => [Math.max(left, h.minX), Math.min(right, h.maxX)])])].sort((a,b)=>a-b);
  const zs = [...new Set([back, front, ...holes.flatMap(h => [Math.max(back, h.minZ), Math.min(front, h.maxZ)])])].sort((a,b)=>a-b);
  for (let xi=0; xi<xs.length-1; xi++) for (let zi=0; zi<zs.length-1; zi++) {
    const x1=xs[xi],x2=xs[xi+1],z1=zs[zi],z2=zs[zi+1];
    if (x2-x1<.1 || z2-z1<.1) continue;
    const mx=(x1+x2)/2,mz=(z1+z2)/2;
    if (holes.some(h=>mx>h.minX&&mx<h.maxX&&mz>h.minZ&&mz<h.maxZ)) continue;
    const w=x2-x1,d=z2-z1;
    addBox(parent,w,.28,d,slabMat,(x1+x2)/2,-.15,(z1+z2)/2);
    addPlane(parent,Math.max(.1,w-.16),Math.max(.1,d-.16),floorMat,(x1+x2)/2,.005,(z1+z2)/2);
  }
}

function buildClassroomPartitions(parent, collision, floorIndex, cx, width, depth, height, materials) {
  const y = height / 2;
  const left = cx - width / 2 + .55, right = cx + width / 2 - .55;
  const corridorLeft = cx - 3.0, corridorRight = cx + 3.0;
  const partition = materials.partition;
  const coreFront = -depth / 2 + 20.0;
  const front = depth / 2 - 1.2;
  const zoneLength = (front - coreFront) / 3;
  const boundaries = [coreFront, coreFront + zoneLength, coreFront + zoneLength * 2, front];
  const westLabels = ['AULA TEÓRICA', 'AULA TIC', 'LAB. ELÉCTRICO'];
  const eastLabels = ['TALLER MECÁNICA', 'LAB. ROBÓTICA', 'SALA PROYECTOS'];
  const rooms = [];
  for (let zone = 0; zone < 3; zone++) {
    rooms.push({ side: 'west', x: (left + corridorLeft) / 2, z: (boundaries[zone] + boundaries[zone + 1]) / 2, label: westLabels[zone], x1: left, x2: corridorLeft, z1: boundaries[zone], z2: boundaries[zone + 1] });
    rooms.push({ side: 'east', x: (corridorRight + right) / 2, z: (boundaries[zone] + boundaries[zone + 1]) / 2, label: eastLabels[zone], x1: corridorRight, x2: right, z1: boundaries[zone], z2: boundaries[zone + 1] });
  }
  const gaps = rooms.map(room => [room.z - .92, room.z + .92]);

  // Corredor longitudinal de 6 m con accesos alineados a cada ambiente.
  addWallAlongZ(parent, collision, floorIndex, corridorLeft, coreFront, front, y, height - .14, partition, gaps);
  addWallAlongZ(parent, collision, floorIndex, corridorRight, coreFront, front, y, height - .14, partition, gaps);

  // Tres ambientes por ala; las divisiones llegan hasta el muro del corredor.
  for (const z of boundaries.slice(1, -1)) {
    addWallAlongX(parent, collision, floorIndex, cx, z, left, corridorLeft, y, height - .14, partition);
    addWallAlongX(parent, collision, floorIndex, cx, z, corridorRight, right, y, height - .14, partition);
  }
  // Cerramiento posterior de las aulas, dejando libre el vestíbulo central.
  addWallAlongX(parent, collision, floorIndex, cx, coreFront, left, corridorLeft, y, height - .14, partition);
  addWallAlongX(parent, collision, floorIndex, cx, coreFront, corridorRight, right, y, height - .14, partition);

  rooms.forEach(room => {
    const boundaryX = room.side === 'west' ? corridorLeft : corridorRight;
    const frameX = boundaryX + (room.side === 'west' ? .10 : -.10);
    for (const dz of [-.96, .96]) addBox(parent, .12, 2.35, .12, materials.steel, frameX, 1.18, room.z + dz);
    addBox(parent, .12, .12, 2.04, materials.steel, frameX, 2.36, room.z);
    const signX = room.side === 'west' ? boundaryX - .24 : boundaryX + .24;
    addLabel(parent, room.label, signX, 2.72, room.z, '#124d87', 3.45, .58, room.side === 'west' ? -Math.PI / 2 : Math.PI / 2);
  });

  // Rótulos de orientación sobre la zona de distribución vertical.
  addLabel(parent, 'VESTÍBULO PRINCIPAL', cx, 2.85, coreFront - .35, '#124d87', 5.6, .65);
  return { rooms, corridor: { left: corridorLeft, right: corridorRight, startZ: coreFront, endZ: front } };
}

function buildClassroomFurniture(parent, collision, floorIndex, cx, floorHeight, materials, blockWidth = TOWER_LAYOUT.blockWidth, blockDepth = TOWER_LAYOUT.blockDepth) {
  const deskMat = makeMat(0x8c9aa8, .56, .08), topMat = makeMat(0x9d7955, .68);
  const frameMat = makeMat(0x465666, .42, .3), screenMat = makeMat(0x111a25, .28, .16);
  const screenGlow = new THREE.MeshStandardMaterial({ color: 0x8fc7eb, emissive: 0x225a84, emissiveIntensity: .52, roughness: .28 });
  const chairMat = makeMat(0x263a51, .6);
  const left = cx - blockWidth / 2 + .55, right = cx + blockWidth / 2 - .55;
  const corridorLeft = cx - 3.0, corridorRight = cx + 3.0;
  const coreFront = -blockDepth / 2 + 20.0;
  const front = blockDepth / 2 - 1.2;
  const zoneLength = (front - coreFront) / 3;
  const rooms = [];
  for (let zone = 0; zone < 3; zone++) {
    const z1 = coreFront + zone * zoneLength, z2 = z1 + zoneLength;
    rooms.push({ x1: left, x2: corridorLeft, z1, z2, side: 'west', zone });
    rooms.push({ x1: corridorRight, x2: right, z1, z2, side: 'east', zone });
  }
  const addWorkstation = (x, z, facing = -1) => {
    addBox(parent, 1.55, .10, .72, topMat, x, .78, z);
    addBox(parent, 1.58, .035, .76, deskMat, x, .845, z);
    for (const dx of [-.64, .64]) for (const dz of [-.25, .25]) addBox(parent, .055, .73, .055, frameMat, x + dx, .38, z + dz);
    addBox(parent, .68, .45, .065, screenMat, x, 1.12, z + facing * .20);
    addBox(parent, .62, .36, .018, screenGlow, x, 1.13, z + facing * .24);
    addBox(parent, .34, .03, .22, frameMat, x, .87, z - facing * .15);
    const chairZ = z + (facing < 0 ? .76 : -.76);
    addBox(parent, .54, .10, .52, chairMat, x, .49, chairZ);
    addBox(parent, .54, .58, .10, chairMat, x, .79, chairZ + (facing < 0 ? .23 : -.23));
    for (const dx of [-.20, .20]) addBox(parent, .055, .42, .055, frameMat, x + dx, .25, chairZ);
    collision.push({ x, z, halfW: .82, halfD: .42, minY: 0, maxY: 1.34, floorIndex, furniture: true });
    collision.push({ x, z: chairZ, halfW: .32, halfD: .36, minY: 0, maxY: 1.15, floorIndex, furniture: true });
  };
  rooms.forEach((room, roomIndex) => {
    const centerX = (room.x1 + room.x2) / 2;
    const centerZ = (room.z1 + room.z2) / 2;
    const facing = room.side === 'west' ? -1 : 1;
    // Tres estaciones por ambiente, separadas del vano de entrada.
    const tableZ = centerZ + (room.zone === 1 ? .15 : 0);
    addWorkstation(centerX - 3.0, tableZ - 1.0, facing);
    addWorkstation(centerX + 3.0, tableZ - 1.0, facing);
    addWorkstation(centerX, tableZ + 1.85, facing);
    // Puesto docente, pantalla frontal y área de demostración.
    const teacherZ = room.zone === 0 ? room.z1 + 1.05 : room.z2 - 1.05;
    addBox(parent, 1.85, .10, .72, topMat, centerX, .84, teacherZ);
    for (const dx of [-.76, .76]) addBox(parent, .07, .80, .07, frameMat, centerX + dx, .40, teacherZ);
    addBox(parent, 2.05, 1.18, .10, screenMat, centerX, 1.98, teacherZ + (facing < 0 ? .58 : -.58));
    collision.push({ x: centerX, z: teacherZ, halfW: .96, halfD: .40, minY: 0, maxY: 1.10, floorIndex, furniture: true });
  });
}

function buildTowerStair(parent, spec, rise, materials, floorIndex) {
  const steps = 14, run = spec.bottomZ - spec.topZ, halfRise = rise / 2, tread = run / steps;
  const stairMaterial = materials.stair, steel = materials.steel;
  for (let i = 0; i < steps; i++) {
    const p = (i + .5) / steps;
    const zA = spec.bottomZ - p * run;
    const yA = p * halfRise;
    addBox(parent, spec.width, .14, tread + .04, stairMaterial, spec.laneA, yA, zA);
    const zB = spec.topZ + p * run;
    const yB = halfRise + p * halfRise;
    addBox(parent, spec.width, .14, tread + .04, stairMaterial, spec.laneB, yB, zB);
  }
  addBox(parent, Math.abs(spec.laneB - spec.laneA) + spec.width, .18, 1.05, materials.slab, (spec.laneA + spec.laneB) / 2, halfRise, spec.topZ);
  // Barandas continuas y postes de soporte, respetando el hueco real.
  for (const lane of [spec.laneA, spec.laneB]) {
    for (const side of [-1, 1]) {
      const x = lane + side * (spec.width / 2 + .06);
      const railLength = Math.hypot(run, halfRise);
      const railBaseY = lane === spec.laneA ? halfRise / 2 : halfRise + halfRise / 2;
      const hand = addBox(parent, .075, .075, railLength, steel, x, railBaseY + .62, (spec.topZ + spec.bottomZ) / 2);
      hand.rotation.x = -Math.atan2(halfRise, run) * (lane === spec.laneA ? 1 : -1);
      for (let j = 0; j <= steps; j += 2) {
        const p = j / steps;
        const z = lane === spec.laneA ? spec.bottomZ - p * run : spec.topZ + p * run;
        const y = lane === spec.laneA ? p * halfRise + .48 : halfRise + p * halfRise + .48;
        addBox(parent, .055, .9, .055, steel, x, y, z);
      }
    }
  }
  // El cerramiento lateral virtual y físico se crea una sola vez en buildTowerWorld.
}

function buildElevator(parent, collision, elevator, floors, materials) {
  const { x, z, floorElevations } = elevator;
  const shaftW = 2.25, shaftD = 2.75;
  const maxFloorIndex = elevator.maxFloorIndex ?? floorElevations.length - 1;
  const totalLow = Number(floorElevations[0] ?? -6.7);
  const totalHigh = Number(floorElevations[maxFloorIndex] ?? 44.5) + 3.0;
  const shaftHeight = totalHigh - totalLow;
  elevator.doorZ = z + shaftD / 2 + .07;
  elevator.entryZ = elevator.doorZ + 2.35;
  elevator.landingDoors = [];

  // Rieles verticales reales para que el pozo sea legible desde las vistas globales.
  for (const dx of [-shaftW / 2, shaftW / 2]) for (const dz of [-shaftD / 2, shaftD / 2]) {
    const rail = addBox(parent, .10, shaftHeight, .10, materials.steel, x + dx, (totalHigh + totalLow) / 2, z + dz);
    rail.userData.elevatorGuide = elevator.id;
    rail.userData.globalStructure = true;
  }

  floors.forEach((floor, floorIndex) => {
    if (floorIndex > maxFloorIndex) return;
    const levelParent = elevator.levelParents[floorIndex];
    if (!levelParent) return;
    const frameY = 1.24;
    const doorZ = elevator.doorZ;
    const jambMat = materials.steel;

    // Vestíbulo de planta: umbral metálico, marco ancho y dintel iluminado.
    addBox(levelParent, shaftW + .70, .12, 2.25, materials.lobbyFloor, x, .065, doorZ + 1.15);
    addBox(levelParent, shaftW + .72, .035, .10, materials.indicatorGlow, x, .14, doorZ + 2.23);
    addBox(levelParent, .14, 2.65, .20, jambMat, x - shaftW / 2 - .08, frameY, doorZ);
    addBox(levelParent, .14, 2.65, .20, jambMat, x + shaftW / 2 + .08, frameY, doorZ);
    addBox(levelParent, shaftW + .30, .16, .20, jambMat, x, 2.58, doorZ);
    addBox(levelParent, shaftW + .08, .07, .10, materials.indicatorGlow, x, 2.49, doorZ + .16);
    addBox(levelParent, shaftW + .52, .08, .20, materials.panel, x, 3.00, doorZ + .24);

    // Cierre posterior y laterales del cubo: el frente queda como vano de acceso.
    addSolidWall(levelParent, collision, floorIndex, x - shaftW / 2, frameY, z, .13, 2.55, shaftD, materials.concrete, { name: 'elevator-shaft-wall' });
    addSolidWall(levelParent, collision, floorIndex, x + shaftW / 2, frameY, z, .13, 2.55, shaftD, materials.concrete, { name: 'elevator-shaft-wall' });
    addSolidWall(levelParent, collision, floorIndex, x, frameY, z - shaftD / 2, shaftW, 2.55, .13, materials.concrete, { name: 'elevator-shaft-wall' });

    // Puertas correderas con acabado de acero y vidrio tintado; permiten ver la cabina.
    const leftDoor = addBox(levelParent, shaftW / 2 - .035, 2.32, .065, materials.landingDoor, x - shaftW / 4, frameY, doorZ, { name: 'elevator-landing-door' });
    const rightDoor = addBox(levelParent, shaftW / 2 - .035, 2.32, .065, materials.landingDoor, x + shaftW / 4, frameY, doorZ, { name: 'elevator-landing-door' });
    const doorCollision = { x, z: doorZ, halfW: shaftW / 2, halfD: .12, minY: 0, maxY: 2.5, floorIndex, door: true, openAmount: 0 };
    elevator.landingDoors.push({ floorIndex, left: leftDoor, right: rightDoor, closedLeft: leftDoor.position.x, closedRight: rightDoor.position.x, collision: doorCollision });
    collision.push(doorCollision);

    // Panel de llamada visible: display de nivel, flechas y botón iluminado.
    const panelX = x + (elevator.liftIndex === 0 ? -1 : 1) * (shaftW / 2 + .18);
    addBox(levelParent, .48, 1.02, .16, materials.panel, panelX, 1.44, doorZ + .25);
    addBox(levelParent, .34, .22, .035, materials.display, panelX, 1.88, doorZ + .285);
    addLabel(levelParent, `P${floorIndex + 1}`, panelX, 1.89, doorZ + .31, '#e8f7ff', .29, .10);
    addBox(levelParent, .18, .18, .06, materials.indicatorGlow, panelX, 1.50, doorZ + .30);
    addLabel(levelParent, 'ASCENSOR', x, 3.03, doorZ + .34, '#e8f7ff', 2.30, .34);
    addLabel(levelParent, `BLOQUE ${elevator.blockIndex + 1} · ${elevator.liftIndex + 1}`, x, 3.42, doorZ + .34, '#164a80', 2.9, .34);
  });

  // Cabina móvil completa con puertas interiores, panel de botones y luz ambiente.
  const cabin = new THREE.Group();
  cabin.name = `Cabina ${elevator.id}`;
  addBox(cabin, 2.04, .13, 2.45, materials.cabinFloor, 0, .08, 0);
  addBox(cabin, .08, 2.35, 2.45, materials.cabinWall, -1.02, 1.25, 0);
  addBox(cabin, .08, 2.35, 2.45, materials.cabinWall, 1.02, 1.25, 0);
  addBox(cabin, 2.04, 2.35, .08, materials.cabinWall, 0, 1.25, -1.18);
  const cabinLeft = addBox(cabin, .98, 2.30, .065, materials.cabinDoor, -.50, 1.24, 1.20);
  const cabinRight = addBox(cabin, .98, 2.30, .065, materials.cabinDoor, .50, 1.24, 1.20);
  addBox(cabin, 2.04, .09, 2.45, materials.cabinCeiling, 0, 2.43, 0);
  addBox(cabin, .20, 1.15, .10, materials.panel, .90, 1.48, .35);
  for (let i = 0; i < Math.min(floors.length, 13); i++) {
    const row = i % 7, col = Math.floor(i / 7);
    const button = new THREE.Mesh(new THREE.CylinderGeometry(.055, .055, .035, 18), materials.indicatorGlow);
    button.rotation.x = Math.PI / 2;
    button.position.set(.90, 1.92 - row * .14, .42 + col * .06);
    cabin.add(button);
  }
  const cabinLight = new THREE.PointLight(0xfff4d6, 1.15, 5.8, 2);
  cabinLight.position.set(0, 2.10, 0);
  cabin.add(cabinLight);
  cabin.position.set(x, Number(floorElevations[2] ?? floorElevations[0] ?? 0), z);
  cabin.userData.globalStructure = true;
  cabin.userData.elevatorCabin = elevator.id;
  parent.add(cabin);
  elevator.cabin = cabin;
  elevator.cabinDoors = { left: cabinLeft, right: cabinRight, closedLeft: -.50, closedRight: .50 };
  elevator.currentFloor = Number.isFinite(Number(floorElevations[2])) ? 2 : 0;
  elevator.materials = materials;
}

export function buildTowerWorld(root, appearance, room) {
  const layout = { ...TOWER_LAYOUT, ...(appearance.towerModel?.layout || {}) };
  const floors = Array.isArray(appearance.floors) ? appearance.floors : [];
  const collision = [], elevators = [], stairways = [];
  const materials = {
    grass: makeMat(0x829d79, .96), concrete: makeMat(0x555e68, .88), dark: makeMat(0x303944, .84),
    slab: makeMat(0xc7cdd2, .86), steel: makeMat(0xaab7c1, .42, .52), partition: makeMat(0xe5e9ed, .9),
    lobbyFloor: makeMat(0x8998a5, .42, .08), panel: makeMat(0x263749, .38, .45), display: makeMat(0x0f2436, .25, .12),
    indicatorGlow: new THREE.MeshStandardMaterial({ color: 0x8dd7ff, emissive: 0x248dc4, emissiveIntensity: 1.25, roughness: .28 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xa4d2e5, roughness: .13, metalness: .12, transparent: true, opacity: .44, transmission: .18, side: THREE.DoubleSide, depthWrite: false }),
    stair: makeMat(0x81715e, .82), door: makeMat(0x364554, .52, .38),
    landingDoor: new THREE.MeshPhysicalMaterial({ color: 0x9ec9d8, roughness: .20, metalness: .34, transparent: true, opacity: .34, transmission: .34, side: THREE.DoubleSide, depthWrite: false }),
    cabinDoor: new THREE.MeshPhysicalMaterial({ color: 0x7894a7, roughness: .22, metalness: .48, transparent: true, opacity: .46, side: THREE.DoubleSide, depthWrite: false }), cabinFloor: makeMat(0x909ba5, .45, .38),
    cabinWall: makeMat(0x596775, .42, .32), cabinCeiling: makeMat(0xdde4ea, .5)
  };
  const siteGroup = new THREE.Group(); siteGroup.name = 'Entorno exterior'; siteGroup.userData.globalStructure = true; root.add(siteGroup);
  buildSite(siteGroup, layout);
  const blockCenters = layout.centers;
  const blockW = layout.blockWidth, blockD = layout.blockDepth;
  const levelParents = floors.map((floor, index) => {
    const group = new THREE.Group();
    group.name = floor.name || `Nivel ${index + 1}`;
    group.position.y = Number(floor.elevation) || 0;
    group.userData.floorId = index + 1;
    root.add(group);
    return group;
  });
  floors.forEach((floor, floorIndex) => {
    const group = levelParents[floorIndex];
    const floorHeight = Number(floor.height) || (floorIndex < 2 ? 3.35 : room.height);
    blockCenters.forEach((cx, blockIndex) => {
      const maxFloorIndex = 2 + (blockIndex === 1 ? 10 : 9);
      if (floorIndex > maxFloorIndex) return;
      const hasUpper = floorIndex < maxFloorIndex;
      const left = cx - blockW / 2, right = cx + blockW / 2, front = blockD / 2, back = -blockD / 2;
      buildFloorWithCoreOpening(group, cx, blockW, blockD, makeMat(0xe4e8eb, .86), materials.slab, true, layout);
      // Primary columns are visibly structural and remain walk obstacles.
      for (const x of [left + .34, right - .34]) for (const z of [back + .34, front - .34]) {
        addBox(group, .68, floorHeight, .68, materials.dark, x, floorHeight / 2, z);
        collision.push({ x, z, halfW: .42, halfD: .42, minY: 0, maxY: floorHeight, floorIndex });
      }
      const groundEntrance = floorIndex === 2;
      addFacadeBay(group, collision, floorIndex, cx, blockW, blockD, floorHeight, materials, groundEntrance);
      // Ground-floor doors are open passages, higher floors have protected curtain walls.
      if (groundEntrance) {
        addBox(group, .10, 2.62, .18, materials.steel, cx - 1.75, 1.31, front + .08);
        addBox(group, .10, 2.62, .18, materials.steel, cx + 1.75, 1.31, front + .08);
        addLabel(group, 'ACCESO', cx, 3.25, front + .22, '#1457a4');
      }
      // Internal walls and doors define actual classroom/workshop rooms, not just empty floors.
      buildClassroomPartitions(group, collision, floorIndex, cx, blockW, blockD, floorHeight, materials);
      if (floorIndex >= 2) buildClassroomFurniture(group, collision, floorIndex, cx, floorHeight, materials, blockW, blockD);
      // Stair core sits west of the lift bank. Its well is protected by virtual walls and geometry.
      const stairSpec = {
        id: `stair-${blockIndex}-${floorIndex}`, blockIndex, blockCenter: cx, baseFloorIndex: floorIndex,
        laneA: cx + layout.stairOffsets[0], laneB: cx + layout.stairOffsets[1],
        topZ: layout.stairTopZ, bottomZ: layout.stairBottomZ, width: layout.stairWidth,
        well: {
          minX: cx + Math.min(...layout.stairOffsets) - layout.stairWidth / 2 - .82,
          maxX: cx + Math.max(...layout.stairOffsets) + layout.stairWidth / 2 + .82,
          minZ: layout.stairTopZ - .82,
          maxZ: layout.stairBottomZ + .82
        },
        collision
      };
      if (hasUpper) {
        const rise = (Number(floors[floorIndex + 1].elevation) || 0) - (Number(floor.elevation) || 0);
        buildTowerStair(group, stairSpec, rise, materials, floorIndex);
        stairways.push(stairSpec);
      }
      // Enclosure walls are solid in geometry and in the walking collision map.
      addSolidWall(group, collision, floorIndex, stairSpec.well.minX + .09, floorHeight / 2, (layout.stairTopZ + layout.stairBottomZ) / 2, .18, floorHeight, layout.stairBottomZ - layout.stairTopZ + 1.6, materials.concrete);
      addSolidWall(group, collision, floorIndex, stairSpec.well.maxX - .09, floorHeight / 2, (layout.stairTopZ + layout.stairBottomZ) / 2, .18, floorHeight, layout.stairBottomZ - layout.stairTopZ + 1.6, materials.concrete);
      // An additional hall partition creates classroom doors, but keeps a continuous central passage.
      const partitions = [cx - 10.1];
      partitions.forEach((x, pIndex) => {
        addWallAlongZ(group, collision, floorIndex, x, -5.2, 12.8, floorHeight / 2, floorHeight - .15, materials.partition, [[1.4, 2.65], [7.7, 8.95]]);
      });
      if (!hasUpper) {
        addBox(group, blockW, .24, blockD, materials.dark, cx, floorHeight + .13, 0);
        addBox(group, blockW, .72, .20, materials.concrete, cx, floorHeight + .57, front - .10);
        addBox(group, blockW, .72, .20, materials.concrete, cx, floorHeight + .57, back + .10);
      }
      // Floor-level label signs.
      addLabel(group, blockIndex === 1 ? 'BLOQUE CENTRAL' : `BLOQUE ${blockIndex === 0 ? 'A' : 'C'}`, cx, floorHeight - .42, front + .16, '#0e4f96');
      addLabel(group, 'ESCALERA', cx - 6.2, 2.65, layout.stairBottomZ + 1.2, '#8a4c28');
    });

    // Bridges connect the three blocks on selected upper levels; at ground level users stay outdoors.
    if ([4, 7, 10].includes(floorIndex)) {
      for (const pair of [[-1, 0], [0, 1]]) {
        const a = blockCenters[pair[0] + 1], b = blockCenters[pair[1] + 1];
        const gapStart = a + blockW / 2, gapEnd = b - blockW / 2;
        addBox(group, gapEnd - gapStart, .24, 3.6, materials.slab, (gapStart + gapEnd) / 2, .02, 0);
        addBox(group, gapEnd - gapStart, 1.1, .12, materials.glass, (gapStart + gapEnd) / 2, .72, -1.74);
        addBox(group, gapEnd - gapStart, 1.1, .12, materials.glass, (gapStart + gapEnd) / 2, .72, 1.74);
        collision.push({ x: (gapStart + gapEnd) / 2, z: -1.82, halfW: (gapEnd - gapStart) / 2, halfD: .12, minY: 0, maxY: 1.1, floorIndex });
        collision.push({ x: (gapStart + gapEnd) / 2, z: 1.82, halfW: (gapEnd - gapStart) / 2, halfD: .12, minY: 0, maxY: 1.1, floorIndex });
      }
    }
  });

  // Six elevator shafts (two per block) with moving cabins, landing doors and guide rails.
  blockCenters.forEach((cx, blockIndex) => {
    layout.elevatorOffsets.forEach((offset, liftIndex) => {
      const maxFloorIndex = 2 + (blockIndex === 1 ? 10 : 9);
      const elevator = {
        id: `T${blockIndex + 1}-E${liftIndex + 1}`, blockIndex, liftIndex, x: cx + offset,
        z: layout.elevatorZ, maxFloorIndex, floorElevations: floors.map((f,i) => i <= maxFloorIndex ? (Number(f.elevation) || 0) : null),
        floorNames: floors.map(f => f.name), levelParents
      };
      buildElevator(root, collision, elevator, floors, materials);
      elevators.push(elevator);
    });
  });

  // Walkway/curb meshes are separate world structures so they stay visible in isolated floor editing.
  root.userData.globalGroups = true;
  return { collision, elevators, stairways, layout, floors, levelParents };
}

export function isTowerCollision(position, floorIndex, collision, radius = .32) {
  for (const solid of collision || []) {
    if (solid.floorIndex !== floorIndex) continue;
    // Las hojas de la puerta del ascensor dejan de bloquear el vano cuando están abiertas.
    if (solid.door && (solid.openAmount || 0) >= .72) continue;
    if (position.x + radius > solid.x - solid.halfW && position.x - radius < solid.x + solid.halfW &&
        position.z + radius > solid.z - solid.halfD && position.z - radius < solid.z + solid.halfD &&
        (solid.maxY ?? 3) > .08 && (solid.minY ?? 0) < 1.95) return true;
  }
  return false;
}

export function resolveTowerStairMove(oldPosition, candidatePosition, floorIndex, stairState, stairways, floors) {
  const radius = .78;
  const floorY = index => Number(floors[index]?.elevation) || 0;
  const free = index => ({ allowed: true, floorIndex: index, onStairs: false, stairState: null, floorY: floorY(index) });
  const blocked = (state = stairState) => ({ allowed: false, floorIndex, onStairs: Boolean(state), stairState: state, floorY: oldPosition.y - 1.65 });
  const candidates = (stairways || []).filter(s => s.baseFloorIndex === floorIndex || s.baseFloorIndex === floorIndex - 1 || stairState?.specId === s.id);
  let state = stairState ? { ...stairState } : null;
  if (!state) {
    for (const spec of candidates) {
      const nearBottom = Math.abs(candidatePosition.z - spec.bottomZ) <= .26;
      const inLaneA = Math.abs(candidatePosition.x - spec.laneA) <= spec.width / 2 + .22;
      const inLaneB = Math.abs(candidatePosition.x - spec.laneB) <= spec.width / 2 + .22;
      if (floorIndex === spec.baseFloorIndex && nearBottom && inLaneA) {
        state = { specId: spec.id, baseFloorIndex: spec.baseFloorIndex, direction: 'up', phase: 'flightA' };
        break;
      }
      if (floorIndex === spec.baseFloorIndex + 1 && nearBottom && inLaneB) {
        state = { specId: spec.id, baseFloorIndex: spec.baseFloorIndex, direction: 'down', phase: 'flightB' };
        break;
      }
    }
  }
  if (!state) {
    for (const spec of candidates) {
      const inWell = candidatePosition.x >= spec.well.minX && candidatePosition.x <= spec.well.maxX && candidatePosition.z >= spec.well.minZ && candidatePosition.z <= spec.well.maxZ;
      if (!inWell) continue;
      // La caja de escalera solo se puede cruzar por el acceso de planta correspondiente.
      const laneA = Math.abs(candidatePosition.x - spec.laneA) <= spec.width / 2 + .22;
      const laneB = Math.abs(candidatePosition.x - spec.laneB) <= spec.width / 2 + .22;
      const lowerEntry = floorIndex === spec.baseFloorIndex && laneA && Math.abs(candidatePosition.z - spec.bottomZ) <= radius;
      const upperEntry = floorIndex === spec.baseFloorIndex + 1 && laneB && Math.abs(candidatePosition.z - spec.bottomZ) <= radius;
      if (!(lowerEntry || upperEntry)) return blocked(null);
    }
    return free(floorIndex);
  }

  const spec = candidates.find(s => s.id === state.specId);
  if (!spec) return blocked(null);
  const base = floorY(spec.baseFloorIndex), upper = floorY(spec.baseFloorIndex + 1);
  const rise = upper - base, half = rise / 2, run = spec.bottomZ - spec.topZ;
  const tol = spec.width / 2 + .22;
  const inA = Math.abs(candidatePosition.x - spec.laneA) <= tol;
  const inB = Math.abs(candidatePosition.x - spec.laneB) <= tol;
  const inLandingX = candidatePosition.x >= Math.min(spec.laneA, spec.laneB) - tol && candidatePosition.x <= Math.max(spec.laneA, spec.laneB) + tol;
  const inRun = candidatePosition.z >= spec.topZ - .30 && candidatePosition.z <= spec.bottomZ + .30;
  const nearTop = Math.abs(candidatePosition.z - spec.topZ) <= .72;
  const pA = THREE.MathUtils.clamp((spec.bottomZ - candidatePosition.z) / run, 0, 1);
  const pB = THREE.MathUtils.clamp((candidatePosition.z - spec.topZ) / run, 0, 1);

  if (state.direction === 'up') {
    if (state.phase === 'flightA') {
      if (candidatePosition.z > spec.bottomZ + .22) return free(spec.baseFloorIndex);
      if (!inA || !inRun) return blocked(state);
      if (pA >= .96) {
        state.phase = 'landingUp';
        return { allowed: true, floorIndex: spec.baseFloorIndex, onStairs: true, stairState: state, floorY: base + half };
      }
      return { allowed: true, floorIndex: spec.baseFloorIndex, onStairs: true, stairState: state, floorY: base + pA * half };
    }
    if (state.phase === 'landingUp') {
      if (!inLandingX || !nearTop) return blocked(state);
      if (inB && candidatePosition.z > spec.topZ + .06) {
        state.phase = 'flightB';
        return { allowed: true, floorIndex: spec.baseFloorIndex, onStairs: true, stairState: state, floorY: base + half + pB * half };
      }
      return { allowed: true, floorIndex: spec.baseFloorIndex, onStairs: true, stairState: state, floorY: base + half };
    }
    if (state.phase === 'flightB') {
      if (!inB || !inRun) return blocked(state);
      if (pB >= .96) return free(spec.baseFloorIndex + 1);
      return { allowed: true, floorIndex: spec.baseFloorIndex, onStairs: true, stairState: state, floorY: base + half + pB * half };
    }
  } else {
    if (state.phase === 'flightB') {
      if (candidatePosition.z > spec.bottomZ + .22) return free(spec.baseFloorIndex + 1);
      if (!inB || !inRun) return blocked(state);
      const progress = THREE.MathUtils.clamp((spec.bottomZ - candidatePosition.z) / run, 0, 1);
      if (progress >= .96) {
        state.phase = 'landingDown';
        return { allowed: true, floorIndex: spec.baseFloorIndex + 1, onStairs: true, stairState: state, floorY: base + half };
      }
      return { allowed: true, floorIndex: spec.baseFloorIndex + 1, onStairs: true, stairState: state, floorY: upper - progress * half };
    }
    if (state.phase === 'landingDown') {
      if (!inLandingX || !nearTop) return blocked(state);
      if (inA && candidatePosition.z > spec.topZ + .06) {
        state.phase = 'flightA';
        const progress = THREE.MathUtils.clamp((candidatePosition.z - spec.topZ) / run, 0, 1);
        return { allowed: true, floorIndex: spec.baseFloorIndex + 1, onStairs: true, stairState: state, floorY: base + half - progress * half };
      }
      return { allowed: true, floorIndex: spec.baseFloorIndex + 1, onStairs: true, stairState: state, floorY: base + half };
    }
    if (state.phase === 'flightA') {
      if (!inA || !inRun) return blocked(state);
      const progress = THREE.MathUtils.clamp((candidatePosition.z - spec.topZ) / run, 0, 1);
      if (progress >= .96) return free(spec.baseFloorIndex);
      return { allowed: true, floorIndex: spec.baseFloorIndex + 1, onStairs: true, stairState: state, floorY: base + half - progress * half };
    }
  }
  return blocked(state);
}

export function findNearbyTowerElevator(position, floorIndex, elevators, maxDistance = 4.2) {
  let best = null, bestDistance = maxDistance;
  for (const elevator of elevators || []) {
    if (floorIndex < 0 || floorIndex > elevator.maxFloorIndex) continue;
    const floorHeight = elevator.floorElevations?.[floorIndex];
    if (!Number.isFinite(Number(floorHeight))) continue;
    const distance = Math.hypot(position.x - elevator.x, position.z - elevator.entryZ);
    if (distance < bestDistance) { best = elevator; bestDistance = distance; }
  }
  return best ? { elevator: best, distance: bestDistance } : null;
}
