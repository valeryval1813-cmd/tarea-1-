import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import thumbManSenati from './assets/library/student-senati-m.webp';
import thumbWomanSenati from './assets/library/student-senati-f.webp';
import thumbManCasual from './assets/library/student-casual-m.webp';
import thumbWomanCasual from './assets/library/student-casual-f.webp';
import thumbTeacher from './assets/library/teacher-m.webp';
import thumbTeacherFemale from './assets/library/teacher-f.webp';
import thumbDesk from './assets/library/desk.webp';
import thumbChair from './assets/library/chair.webp';
import thumbAio from './assets/library/aio.webp';
import thumbKeyboardMouse from './assets/library/keyboard-mouse.webp';
import thumbWindow from './assets/library/window.webp';
import thumbDoor from './assets/library/door.webp';
import thumbWhiteboard from './assets/library/whiteboard.webp';
import thumbFluorescent from './assets/library/fluorescent.webp';
import thumbFan from './assets/library/fan.webp';
import thumbProjector from './assets/library/projector.webp';
import './editor.css';
import { TOWER_LAYOUT, buildTowerWorld, isTowerCollision, resolveTowerStairMove, findNearbyTowerElevator } from './tower-world.js';

const $ = (id) => document.getElementById(id);
const viewport = $('viewport');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0xeaf0f7);

const camera = new THREE.PerspectiveCamera(45, 1, .1, 500);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.04;
renderer.physicallyCorrectLights = true;
viewport.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
const walkControls = new PointerLockControls(camera, renderer.domElement);
const walkClock = new THREE.Clock();
const walkKeys = { forward:false, backward:false, left:false, right:false };
let walkMode = false;
let walkPerspective = 'first';
let walkActorPosition = new THREE.Vector3();
let walkAvatar = null;
let walkMotionPhase = 0;
let loadingScenario = false;
controls.enableDamping = true;
controls.dampingFactor = .07;
controls.maxPolarAngle = Math.PI * .49;
controls.minDistance = 4;
controls.maxDistance = 320;

const hemi = new THREE.HemisphereLight(0xf2f7ff, 0x64748b, 1.45);scene.add(hemi);
const sun = new THREE.DirectionalLight(0xfff8ed, 2.0);
sun.position.set(-12, 22, 16); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
scene.add(sun);
const fill = new THREE.DirectionalLight(0xb6d6ff, .62);
fill.position.set(12, 10, -12); scene.add(fill);

const roomGroup = new THREE.Group(); roomGroup.name = 'Room'; scene.add(roomGroup);
const objectGroup = new THREE.Group(); objectGroup.name = 'PlacedObjects'; scene.add(objectGroup);
let room = { width: 20, depth: 12, height: 3.4 };
let appearance = {
  floorType: 'tile', floorColor: '#f2f4f7', wallColor: '#f1f3f6',
  deskColor: '#1559a8', chairColor: '#202a38'
};
let placed = [];
let selected = null;
let activeTool = 'select';
let activeCategory = 'all';
let activePlacementKey = null;
let currentScenarioId = null;
let gridVisible = true;
let roofVisible = false;
let floorMesh, gridHelper, roofMesh, roomEdges;
let activeFloorIndex=0;
let walkFloorIndex=0, walkOnStairs=false;
let towerWorldState = null, walkTowerStairState = null, walkElevatorNearby = null, walkElevatorPanelOpen = false, walkElevatorSelection = 0, activeElevatorRide = null;
let floorMeshes=[];
let selectionHelper = null;
let pointerDown = null;
let isDraggingObject = false;
let dragPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const floorY = .015;
const MAX_FLOORS = 13; // 2 sótanos + planta baja + 10 niveles superiores
// Dimensiones físicas únicas para todos los escritorios (metros): 158 x 72 cm.
const DESK_LENGTH = 1.58;
const DESK_DEPTH = .72;

function ensureFloorModel(){
  const wanted=Array.isArray(appearance.floors)&&appearance.floors.length?Math.max(1,Math.min(MAX_FLOORS,appearance.floors.length)):(appearance.buildingPlan==='two-floor'?2:1);
  const current=Array.isArray(appearance.floors)?appearance.floors:[];
  const floors=[];
  for(let i=0;i<wanted;i++){
    const saved=current[i]||{};
    floors.push({
      id:i+1,
      name:saved.name||`Piso ${i+1}`,
      elevation:Number.isFinite(Number(saved.elevation))?Number(saved.elevation):i*room.height,
      height:Number(saved.height)||room.height,
      floorType:saved.floorType||appearance.floorType||'tile',
      floorColor:saved.floorColor||appearance.floorColor||'#f2f4f7'
    });
  }
  appearance.floors=floors;
  activeFloorIndex=THREE.MathUtils.clamp(activeFloorIndex,0,wanted-1);
  return floors;
}
function getFloors(){return ensureFloorModel();}
function floorElevation(index=activeFloorIndex){return getFloors()[index]?.elevation??0;}
function floorStyle(index){
  const floor=getFloors()[index]||{};
  return {floorType:floor.floorType||appearance.floorType||'tile',floorColor:floor.floorColor||appearance.floorColor||'#f2f4f7'};
}
function getStairSpec(){
  const st=appearance.stairs||{};
  return {x:Number(st.x??5.25),topZ:Number(st.topZ??-2),bottomZ:Number(st.bottomZ??3.45),width:Number(st.width??2.55)};
}
function syncFloorControls(){
  const floors=getFloors();
  const active=$('construction-floor');
  const scope=$('floor-edit-scope');
  if(!active||!scope)return;
  const previous=active.value||'all';
  active.innerHTML='<option value="all">Vista global · todos los niveles</option>'+floors.map((f,i)=>`<option value="${i}">${f.name}</option>`).join('');
  active.value=[...active.options].some(o=>o.value===previous)?previous:'all';
  if(active.value!=='all')activeFloorIndex=Number(active.value)||0;
  scope.innerHTML='<option value="global">Global · todos los pisos</option>'+floors.map((f,i)=>`<option value="${i}">${f.name}</option>`).join('');
  if(![...scope.options].some(o=>o.value===scope.value))scope.value='global';
  $('remove-floor').disabled=floors.length<=1;
  $('add-floor').disabled=floors.length>=MAX_FLOORS;
  $('floor-manager-hint').textContent=appearance.buildingPlan==='senati-tower'?'Modelo conceptual: 2 sótanos y 11 pisos sobre rasante. Puedes aislar cada nivel; el plano interior no es oficial.':`Puedes crear hasta ${MAX_FLOORS} niveles. Selecciona un piso para editarlo de forma aislada o usa Vista global.`;
  const style=scope.value==='global'?{floorType:appearance.floorType,floorColor:appearance.floorColor}:floorStyle(Number(scope.value));
  $('floor-type').value=style.floorType;
  $('floor-color').value=style.floorColor;
}
function applyFloorVisibility(){
  const floors=getFloors();
  const all=$('construction-floor')?.value==='all';
  const index=activeFloorIndex;
  placed.forEach(obj=>{ const objectFloor=nearestFloorIndex(obj.position.y,floors); obj.visible=all||objectFloor===index; });
  // Aislar también la arquitectura: losas, barandas y tramos superiores no deben contaminar la vista del piso activo.
  roomGroup.children.forEach(child=>{
    if(child===gridHelper){child.visible=all||true;return;}
    const y=child.position?.y??0;
    const level=nearestFloorIndex(y,floors);
    child.visible=all||level===index||child.userData?.globalStructure===true;
  });
}
function nearestFloorIndex(y,floors=getFloors()){
  let best=0,bestDistance=Infinity;
  floors.forEach((f,i)=>{const distance=Math.abs(y-f.elevation);if(distance<bestDistance){best=i;bestDistance=distance;}});
  return best;
}
function selectConstructionFloor(index,{moveCamera=true}={}){
  const floors=getFloors();
  activeFloorIndex=THREE.MathUtils.clamp(Number(index)||0,0,floors.length-1);
  if($('construction-floor'))$('construction-floor').value=String(activeFloorIndex);
  applyFloorVisibility();
  if(gridHelper)gridHelper.position.y=floorElevation(activeFloorIndex)+.012;
  if(moveCamera){
    const delta=floorElevation(activeFloorIndex)-controls.target.y+1.05;
    camera.position.y+=delta;controls.target.y=floorElevation(activeFloorIndex)+1.05;controls.update();
  }
  $('viewport-status').textContent=`Edición: ${floors[activeFloorIndex].name}`;
}
function setFloorCount(count){
  count=THREE.MathUtils.clamp(Number(count)||1,1,MAX_FLOORS);
  const existing=getFloors();
  const previousPlan=appearance.buildingPlan;
  const next=[];
  for(let i=0;i<count;i++){
    const saved=existing[i]||{id:i+1,name:`Piso ${i+1}`,floorType:appearance.floorType,floorColor:appearance.floorColor};
    const fallbackElevation=previousPlan==='senati-tower'?(i?next[i-1].elevation+room.height:-6.7):i*room.height;
    next.push({...saved,id:i+1,name:saved.name||`Piso ${i+1}`,elevation:Number.isFinite(Number(saved.elevation))?Number(saved.elevation):fallbackElevation,height:Number(saved.height)||room.height});
  }
  appearance.buildingPlan=previousPlan==='senati-tower'?'senati-tower':(count>1?'two-floor':'single-floor');
  appearance.floorHeight=room.height;
  if(count>1&&!appearance.stairs&&appearance.buildingPlan!=='senati-tower')appearance.stairs={x:5.25,topZ:-2,bottomZ:3.45,width:2.55};
  appearance.floors=next;
  const removed=placed.filter(o=>nearestFloorIndex(o.position.y,existing)>=count);
  removed.forEach(o=>{objectGroup.remove(o);const idx=placed.indexOf(o);if(idx>=0)placed.splice(idx,1);});
  activeFloorIndex=Math.min(activeFloorIndex,count-1);
  syncFloorControls();makeRoom();applyFloorVisibility();renderObjectList();markDirty();
}

const catalog = [
  {key:'desk',label:'Escritorio informático estándar',category:'mobiliario',icon:'▰',description:'158 × 72 cm · frente marcado, zona de teclado y canal posterior para cables'},
  {key:'chair',label:'Silla giratoria',category:'mobiliario',icon:'◉',description:'Base de cinco radios'},
  {key:'aio',label:'PC All-in-One XL',category:'computacion',icon:'▣',description:'Pantalla ampliada y base grande · teclado y mouse automáticos'},
  {key:'keyboard',label:'Teclado',category:'computacion',icon:'⌨',description:'Teclado independiente'},
  {key:'mouse',label:'Mouse',category:'computacion',icon:'⌁',description:'Mouse óptico'},
  {key:'man',label:'Hombre · polo casual',category:'personas',icon:'👨',description:'Alumno con polo de color aleatorio'},
  {key:'woman',label:'Mujer · polo casual',category:'personas',icon:'👩',description:'Alumna con polo de color aleatorio'},
  {key:'man-senati',label:'Hombre · polo SENATI',category:'personas',icon:'👨‍🎓',description:'Alumno con polo institucional SENATI'},
  {key:'woman-senati',label:'Mujer · polo SENATI',category:'personas',icon:'👩‍🎓',description:'Alumna con polo institucional SENATI'},
  {key:'teacher',label:'Profesor · terno',category:'personas',icon:'🧑‍🏫',description:'Docente con terno formal'},
  {key:'teacher-f',label:'Profesora · terno',category:'personas',icon:'👩‍🏫',description:'Docente con traje formal'},
  {key:'wall',label:'Pared',category:'arquitectura',icon:'▤',description:'Tramo de pared'},
  {key:'road',label:'Pista asfaltada',category:'arquitectura',icon:'▰',description:'Tramo de calzada con asfalto y demarcación vial'},
  {key:'ground',label:'Piso exterior',category:'arquitectura',icon:'▦',description:'Módulo de pavimento de concreto para patios y plazas'},
  {key:'sidewalk',label:'Vereda peatonal',category:'arquitectura',icon:'▤',description:'Vereda modular de concreto con losetas y sardinel'},
  {key:'door',label:'Puerta transparente',category:'arquitectura',icon:'▯',description:'Puerta de vidrio con marco'},
  {key:'door-normal',label:'Puerta normal',category:'arquitectura',icon:'🚪',description:'Puerta opaca de acabado madera'},
  {key:'window',label:'Ventana',category:'arquitectura',icon:'▦',description:'Ventana de pared'},
  {key:'whiteboard',label:'Pizarra',category:'arquitectura',icon:'▱',description:'Pizarra blanca'},
  {key:'fluorescent',label:'Fluorescente',category:'equipamiento',icon:'━',description:'Luminaria rectangular'},
  {key:'fan',label:'Ventilador',category:'equipamiento',icon:'✥',description:'Ventilador de techo'},
  {key:'projector',label:'Proyector',category:'equipamiento',icon:'▰',description:'Proyector de techo'},
  {key:'plant',label:'Planta decorativa',category:'equipamiento',icon:'♧',description:'Maceta decorativa'},
  {key:'safety-exit',label:'Rótulo SALIDA',category:'seguridad',icon:'🟩',description:'Señal fotoluminiscente de salida'},
  {key:'safety-rules',label:'Reglas de seguridad',category:'seguridad',icon:'⚠️',description:'Panel de normas de seguridad del aula'},
  {key:'fire-extinguisher',label:'Extintor',category:'seguridad',icon:'🧯',description:'Extintor rojo con soporte y señal identificativa'},
  {key:'safety-first-aid',label:'Señal de botiquín',category:'seguridad',icon:'✚',description:'Señal verde de primeros auxilios'},
  {key:'safety-electrical',label:'Riesgo eléctrico',category:'seguridad',icon:'⚡',description:'Advertencia amarilla de riesgo eléctrico'},
  {key:'safety-safe-zone',label:'Zona segura',category:'seguridad',icon:'🟢',description:'Identificación de zona segura'},
  {key:'safety-evacuation',label:'Ruta de evacuación',category:'seguridad',icon:'➡️',description:'Señal direccional de evacuación'}
];
const categoryLabels = {mobiliario:'Mobiliario',computacion:'Computación',personas:'Personas',arquitectura:'Arquitectura',equipamiento:'Equipamiento',seguridad:'Seguridad'};
const libraryThumbs = {
  'man-senati':thumbManSenati,'woman-senati':thumbWomanSenati,
  man:thumbManCasual,woman:thumbWomanCasual,teacher:thumbTeacher,'teacher-f':thumbTeacherFemale,
  desk:thumbDesk,chair:thumbChair,aio:thumbAio,keyboard:thumbKeyboardMouse,mouse:thumbKeyboardMouse,
  window:thumbWindow,door:thumbDoor,'door-normal':thumbDoor,whiteboard:thumbWhiteboard,
  fluorescent:thumbFluorescent,fan:thumbFan,projector:thumbProjector
};
const mat = (color, roughness=.72, metalness=0) => new THREE.MeshStandardMaterial({color,roughness,metalness});
const mats = {
  desk:mat(0x164b82,.48),deskEdge:mat(0x0d3159,.55),black:mat(0x171c24,.75),
  metal:mat(0x77838e,.54,.36),blue:mat(0x07549b,.68),yellow:mat(0xf3c34b,.5),
  skin:mat(0xc88f6b,.85),white:mat(0xf6f7f8,.5),glass:new THREE.MeshPhysicalMaterial({color:0xbfe9f7,roughness:.06,metalness:0,transparent:true,opacity:.24,transmission:.72,thickness:.06,ior:1.46,depthWrite:false,side:THREE.DoubleSide}),
  wall:mat(0xe3e7eb,.9),green:mat(0x327f5a,.85),brown:mat(0x8a6245,.8)
};
function mesh(parent, geometry, material, x=0, y=0, z=0, cast=true) {
  const m = new THREE.Mesh(geometry, material);
  m.position.set(x,y,z); m.castShadow=cast; m.receiveShadow=true; parent.add(m); return m;
}
function box(parent,w,h,d,material,x,y,z) {
  const smallest=Math.min(Math.abs(w),Math.abs(h),Math.abs(d));
  const geometry=smallest>=.008
    ?new RoundedBoxGeometry(w,h,d,2,Math.min(.018,smallest*.22))
    :new THREE.BoxGeometry(w,h,d);
  return mesh(parent,geometry,material,x,y,z);
}
function cylinder(parent,rt,rb,h,material,x,y,z,segments=24) {
  return mesh(parent,new THREE.CylinderGeometry(rt,rb,h,segments),material,x,y,z);
}
function hexColor(hex){ return new THREE.Color(hex || '#ffffff'); }
function makeFloorTexture(type, colorHex) {
  const canvas=document.createElement('canvas');canvas.width=512;canvas.height=512;
  const ctx=canvas.getContext('2d');const color=colorHex||'#f3f4f6';
  ctx.fillStyle=color;ctx.fillRect(0,0,256,256);
  const c=hexColor(color);
  const lighter='#'+c.clone().lerp(new THREE.Color(0xffffff),.13).getHexString();
  const darker='#'+c.clone().lerp(new THREE.Color(0x000000),.10).getHexString();
  if(type==='tile'){
    ctx.fillStyle=lighter;ctx.fillRect(0,0,256,256);ctx.fillRect(256,256,256,256);
    ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(256,0,256,256);ctx.fillRect(0,256,256,256);
    ctx.strokeStyle='rgba(115,128,144,.22)';ctx.lineWidth=3;ctx.strokeRect(2,2,508,508);ctx.beginPath();ctx.moveTo(256,0);ctx.lineTo(256,512);ctx.moveTo(0,256);ctx.lineTo(512,256);ctx.stroke();
  } else if(type==='wood'){
    ctx.fillStyle=lighter;
    for(let y=0;y<256;y+=64){ctx.fillRect(0,y,256,62);ctx.fillStyle=darker;ctx.fillRect(0,y+62,256,2);ctx.fillStyle=lighter;
      const offset=(y/64%2)*64;ctx.strokeStyle='rgba(80,50,25,.20)';ctx.beginPath();ctx.moveTo(offset,y);ctx.lineTo(offset,y+64);ctx.moveTo(offset+128,y);ctx.lineTo(offset+128,y+64);ctx.stroke();}
    ctx.strokeStyle='rgba(90,65,40,.10)';for(let i=0;i<40;i++){const y=(i*37)%256;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(256,y+((i%3)-1)*3);ctx.stroke();}
  } else if(type==='carpet'){
    ctx.fillStyle=lighter;ctx.fillRect(0,0,256,256);
    for(let i=0;i<2400;i++){ctx.fillStyle=i%2?'rgba(255,255,255,.12)':'rgba(30,40,50,.08)';const x=(i*73)%256,y=(i*137)%256;ctx.fillRect(x,y,2,2);}
  } else {
    ctx.strokeStyle='rgba(110,120,130,.12)';ctx.lineWidth=1;
    for(let i=0;i<120;i++){const x=(i*61)%256,y=(i*97)%256;ctx.beginPath();ctx.arc(x,y,(i%4)+1,0,Math.PI*2);ctx.stroke();}
  }
  const texture=new THREE.CanvasTexture(canvas);
  texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=THREE.RepeatWrapping;texture.wrapT=THREE.RepeatWrapping;
  texture.repeat.set(room.width/1.35,room.depth/1.35);texture.anisotropy=8;
  return texture;
}
function addRoomBox(w,h,d,material,x,y,z){return box(roomGroup,w,h,d,material,x,y,z);}
function wallBandZ(a,b,z,y,h,material){
  if(b-a<.02||h<.02)return;
  addRoomBox(b-a,h,.18,material,(a+b)/2,y+h/2,z);
}
function wallBandX(x,a,b,y,h,material){
  if(b-a<.02||h<.02)return;
  addRoomBox(.18,h,b-a,material,x,y+h/2,(a+b)/2);
}
function buildWallZ(z, openings=[]){
  const W=room.width,H=room.height,white=mat(appearance.wallColor||0xf4f6f8,.88),blue=mat(0x1456a2,.72);
  const sill=1.12,head=2.58;let cursor=-W/2;
  const list=[...openings].filter(o=>o.center-o.width/2>-W/2+.05&&o.center+o.width/2<W/2-.05).sort((a,b)=>a.center-b.center);
  for(const o of list){
    const left=o.center-o.width/2,right=o.center+o.width/2;
    if(left>cursor){wallBandZ(cursor,left,z,0,Math.min(.98,H),blue);wallBandZ(cursor,left,z,.98,H-.98,white);}
    const bottom=o.type==='door'?0:sill,top=o.type==='door'?2.48:head;
    if(bottom>0)wallBandZ(left,right,z,0,bottom,blue);
    if(H>top)wallBandZ(left,right,z,top,H-top,white);
    cursor=right;
  }
  if(cursor<W/2){wallBandZ(cursor,W/2,z,0,Math.min(.98,H),blue);wallBandZ(cursor,W/2,z,.98,H-.98,white);}
}
function buildWallX(x, openings=[]){
  const D=room.depth,H=room.height,white=mat(appearance.wallColor||0xf4f6f8,.88),blue=mat(0x1456a2,.72);
  const sill=1.12,head=2.58;let cursor=-D/2;
  const list=[...openings].filter(o=>o.center-o.width/2>-D/2+.05&&o.center+o.width/2<D/2-.05).sort((a,b)=>a.center-b.center);
  for(const o of list){
    const a=o.center-o.width/2,b=o.center+o.width/2;
    if(a>cursor){wallBandX(x,cursor,a,0,Math.min(.98,H),blue);wallBandX(x,cursor,a,.98,H-.98,white);}
    const bottom=o.type==='door'?0:sill,top=o.type==='door'?2.48:head;
    if(bottom>0)wallBandX(x,a,b,0,bottom,blue);
    if(H>top)wallBandX(x,a,b,top,H-top,white);
    cursor=b;
  }
  if(cursor<D/2){wallBandX(x,cursor,D/2,0,Math.min(.98,H),blue);wallBandX(x,cursor,D/2,.98,H-.98,white);}
}
function addBranding(){
  const canvas=document.createElement('canvas');canvas.width=720;canvas.height=300;const c=canvas.getContext('2d');
  c.clearRect(0,0,720,300);c.fillStyle='#0e57b7';c.beginPath();
  const cx=360,cy=84,r=56;for(let i=0;i<6;i++){const a=-Math.PI/2+i*Math.PI/3;const x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r;i?c.lineTo(x,y):c.moveTo(x,y);}c.closePath();c.fill();
  c.fillStyle='#fff';c.font='900 72px Arial';c.textAlign='center';c.textBaseline='middle';c.fillText('S',cx,cy+2);
  c.fillStyle='#0b4f9e';c.font='900 72px Arial';c.fillText('SENATI',360,226);
  const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;
  const mark=mesh(roomGroup,new THREE.PlaneGeometry(2.05,.86),new THREE.MeshBasicMaterial({map:tex,transparent:true,side:THREE.DoubleSide}),-2.55,2.24,-room.depth/2+.105,false);
  mark.userData.roomBrand=true;
}
function buildExterior(){
  const outerX=-room.width/2-3.8;
  const groundMat=mat(0x9bb69b,.94);mesh(roomGroup,new THREE.PlaneGeometry(7,room.depth+7),groundMat,outerX,0.015,0,false).rotation.x=-Math.PI/2;
  const facade=mat(0xb9cbd8,.68);const frame=mat(0x73899d,.48,.25);const skyGlass=new THREE.MeshPhysicalMaterial({color:0xa9d8f0,roughness:.12,transparent:true,opacity:.42,transmission:.2,side:THREE.DoubleSide,depthWrite:false});
  const building=box(roomGroup,.24,4.4,room.depth+5,facade,-room.width/2-6.6,2.2,0);building.castShadow=false;
  for(let z=-room.depth/2-1.2;z<=room.depth/2+1.2;z+=2.25){
    box(roomGroup,.03,2.0,1.35,skyGlass,-room.width/2-6.43,2.65,z);
    box(roomGroup,.05,2.05,.045,frame,-room.width/2-6.39,2.65,z-.70);
    box(roomGroup,.05,2.05,.045,frame,-room.width/2-6.39,2.65,z+.70);
  }
  for(const z of [-4.5,-.2,4.2]){
    cylinder(roomGroup,.055,.075,1.35,mat(0x795b3e,.9),-room.width/2-2.3,.68,z,10);
    const foliage=mat(0x4f9461,.88);
    for(const [dx,dy,dz,scale] of [[0,1.65,0,.72],[-.30,1.35,.18,.52],[.25,1.42,-.12,.56]]){const crown=mesh(roomGroup,new THREE.SphereGeometry(scale,18,14),foliage,-room.width/2-2.3+dx,dy,z+dz);crown.scale.y=1.12;}
  }
}
let rainPoints=null;
function applyClimate(mode){
 appearance.climate=mode||'day';
 const night=appearance.climate==='night',rain=appearance.climate==='rain';
 scene.background=new THREE.Color(night?0x101a30:(rain?0x8998aa:0xb9d8f3));
 hemi.intensity=night?.42:(rain?.95:1.65);
 sun.intensity=night?.12:(rain?.72:2.25);
 fill.intensity=night?.22:(rain?.42:.8);
 sun.color.set(night?0x9bb8e8:(rain?0xcbd8e8:0xfff8ed));
 if(rain&&!rainPoints){
  const count=1100, margin=5, rainTop=Math.max(9,getFloors().length*room.height+5);
  const positions=new Float32Array(count*3);
  for(let i=0;i<count;i++){
   // Lluvia solo en una franja exterior alrededor del edificio; nunca sobre la huella interior.
   const side=Math.floor(Math.random()*4),t=Math.random();let x,z;
   if(side===0){x=-room.width/2-margin+t*(room.width+2*margin);z=-room.depth/2-margin-Math.random()*3;}
   else if(side===1){x=-room.width/2-margin+t*(room.width+2*margin);z=room.depth/2+margin+Math.random()*3;}
   else if(side===2){x=-room.width/2-margin-Math.random()*3;z=-room.depth/2-margin+t*(room.depth+2*margin);}
   else{x=room.width/2+margin+Math.random()*3;z=-room.depth/2-margin+t*(room.depth+2*margin);}
   positions[i*3]=x;positions[i*3+1]=Math.random()*rainTop;positions[i*3+2]=z;
  }
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
  rainPoints=new THREE.Points(geo,new THREE.PointsMaterial({color:0xd9eaff,size:.045,transparent:true,opacity:.7}));scene.add(rainPoints);rainPoints.userData.rainTop=rainTop;
 }
 if(rainPoints)rainPoints.visible=rain;
 const select=$('climate-mode');if(select)select.value=appearance.climate;
}

function buildTwoFloorArchitecture(baseY=0){
  const childStart=roomGroup.children.length;
  const upperY=room.height, stair=getStairSpec(), stairX=stair.x, topZ=stair.topZ, bottomZ=stair.bottomZ, run=bottomZ-topZ, steps=18;
  const upperStyle=floorStyle(Math.round(baseY/room.height)+1);
  const slab=mat(new THREE.Color(upperStyle.floorColor).getHex(),.82), stairMat=mat(0x98724f,.78), rail=mat(0x536477,.42,.35), corridor=mat(0xe3e8ee,.86);
  // Segundo nivel: cuatro paños que dejan libre el hueco de la escalera.
  const xL=-room.width/2, xR=room.width/2, holeL=stairX-stair.width/2-.3, holeR=stairX+stair.width/2+.3, holeBack=topZ, holeFront=bottomZ;
  addRoomBox(holeL-xL,.18,room.depth,slab,(xL+holeL)/2,upperY-.09,0);
  addRoomBox(xR-holeR,.18,room.depth,slab,(holeR+xR)/2,upperY-.09,0);
  addRoomBox(holeR-holeL,.18,holeBack+room.depth/2,slab,stairX,upperY-.09,(-room.depth/2+holeBack)/2);
  addRoomBox(holeR-holeL,.18,room.depth/2-holeFront,slab,stairX,upperY-.09,(holeFront+room.depth/2)/2);
  // Muros del segundo nivel y barandas abiertas al frente para que el corte 3D sea visible.
  const upperWallY=upperY+room.height/2;
  addRoomBox(room.width,.18,room.height,corridor,0,upperWallY,-room.depth/2);
  addRoomBox(.18,room.height,room.depth,corridor,-room.width/2,upperWallY,0);
  addRoomBox(.18,room.height,room.depth,corridor,room.width/2,upperWallY,0);
  addRoomBox(room.width,.12,.12,rail,0,upperY+1.0,room.depth/2-.1);
  // Escalera recta con huellas, contrahuellas y pasamanos a ambos lados.
  for(let i=0;i<steps;i++){
    const t=(i+.5)/steps, y=upperY-(i+.5)*upperY/steps, z=topZ+t*run;
    addRoomBox(stair.width,.17,run/steps+.025,stairMat,stairX,y,z);
    addRoomBox(stair.width,.19,.07,rail,stairX,y-.09,z-run/(2*steps));
  }
  const railAngle=-Math.atan2(upperY,run), railLength=Math.hypot(upperY,run);
  for(const side of [-1,1]){
    const x=stairX+side*(stair.width/2+.065);
    const hand=addRoomBox(.075,.075,railLength,rail,x,upperY/2+.92,(topZ+bottomZ)/2);
    hand.rotation.x=railAngle;
    for(let i=0;i<=steps;i+=3){const t=i/steps,z=topZ+t*run,y=upperY*(1-t)+.55;addRoomBox(.06,.95,.06,rail,x,y,z).rotation.x=railAngle;}
  }
  // Pasadizo despejado del pie de escalera hacia la puerta exterior del primer piso.
  const hallStart=6.35,hallEnd=room.width/2-.1;
  addRoomBox(hallEnd-hallStart,3.1,.14,corridor,(hallStart+hallEnd)/2,1.55,2.55);
  addRoomBox(hallEnd-hallStart,3.1,.14,corridor,(hallStart+hallEnd)/2,1.55,6.95);
  // Señal de circulación en el borde de la escalera y en el pasadizo.
  const signMat=mat(0x087a45,.55);
  addRoomBox(.9,.35,.06,signMat,stairX,2.0,3.0);
  // Plataforma exterior frente a la salida para identificar el punto seguro.
  addRoomBox(4.8,.06,7.2,mat(0x9bb69b,.94),room.width/2+2.35,.03,room.depth*.36);
  addRoomBox(3.2,.035,1.8,mat(0xd8e2cf,.9),room.width/2+1.65,.065,room.depth*.36);
  // Cada tramo conecta el nivel base con el inmediatamente superior.
  for(let i=childStart;i<roomGroup.children.length;i++)roomGroup.children[i].position.y+=baseY;
}

function addTowerBeam(parent,x1,y1,z,x2,y2,thickness,material){
  const dx=x2-x1,dy=y2-y1,len=Math.hypot(dx,dy);
  const beam=box(parent,len,thickness,thickness,material,(x1+x2)/2,(y1+y2)/2,z);
  beam.rotation.z=Math.atan2(dy,dx);
  return beam;
}
function addTowerSign(parent,x,y,z){
  const canvas=document.createElement('canvas');canvas.width=512;canvas.height=192;
  const ctx=canvas.getContext('2d');ctx.fillStyle='#0e55a3';ctx.fillRect(0,0,512,192);
  ctx.fillStyle='#ffffff';ctx.font='900 86px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('SENATI',256,98);
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
  mesh(parent,new THREE.PlaneGeometry(2.9,1.08),new THREE.MeshBasicMaterial({map:texture,side:THREE.DoubleSide}),x,y,z,false);
}
function buildTowerStairCore(parent,cx,levelHeight,materials){
  const {concrete,steel}=materials;
  // Core de circulación representativo: dos tramos, descanso y barandas.
  const steps=8,stepRise=(levelHeight*.88)/16,stepDepth=.27,stairWidth=1.05;
  const startZ=-7.25;
  for(let i=0;i<steps;i++){
    const h=(i+1)*stepRise;
    box(parent,stairWidth,.13,stepDepth,concrete,cx-0.72,h/2,startZ+i*stepDepth);
    box(parent,stairWidth,.13,stepDepth,concrete,cx+0.72,(levelHeight*.44)+(i+1)*stepRise/2,startZ+(steps-1-i)*stepDepth);
  }
  box(parent,3.0,.18,1.05,concrete,cx,levelHeight*.48,startZ+steps*stepDepth+.25);
  for(const side of [-1,1]){
    box(parent,.055,1.0,3.0,steel,cx+side*1.32,.72,startZ+1.05).rotation.x=-.35;
    box(parent,.055,1.0,3.0,steel,cx+side*1.32,levelHeight*.72,startZ+1.05).rotation.x=.35;
  }
}
function buildTowerLevel(parent,cx,blockWidth,blockDepth,levelHeight,materials,{top=false,ground=false,sign=false}={}){
  const {slab,concrete,darkConcrete,glass,steel,blue,door}=materials;
  // Losa de concreto y pavimento interior.
  box(parent,blockWidth,.24,blockDepth,slab,cx,-.13,0);
  const floorSurface=mesh(parent,new THREE.PlaneGeometry(blockWidth-.7,blockDepth-.7),mat(0xdfe5e9,.83),cx,.002,0,false);
  floorSurface.rotation.x=-Math.PI/2;
  // Pilares/machones laterales y núcleo rígido de concreto.
  for(const sx of [-1,1]){
    box(parent,.62,levelHeight-.22,blockDepth,darkConcrete,cx+sx*(blockWidth/2-.31),levelHeight/2,0);
  }
  const coreZ=-blockDepth*.28,coreW=5.0,coreD=6.2,wall=.24;
  box(parent,wall,levelHeight,coreD,concrete,cx-coreW/2+wall/2,levelHeight/2,coreZ);
  box(parent,wall,levelHeight,coreD,concrete,cx+coreW/2-wall/2,levelHeight/2,coreZ);
  box(parent,coreW,levelHeight,wall,concrete,cx,levelHeight/2,coreZ-coreD/2+wall/2);
  box(parent,1.0,levelHeight,wall,concrete,cx-coreW/2+.62,levelHeight/2,coreZ+coreD/2-wall/2);
  box(parent,1.0,levelHeight,wall,concrete,cx+coreW/2-.62,levelHeight/2,coreZ+coreD/2-wall/2);
  // Dos puertas de ascensor por bloque (seis en el conjunto, como referencia del proyecto).
  for(const dx of [-1.25,1.25]){
    box(parent,1.12,2.32,.09,darkConcrete,cx+dx,1.16,coreZ+coreD/2+.055);
    box(parent,.055,2.42,.13,steel,cx+dx-.60,1.21,coreZ+coreD/2+.12);
    box(parent,.055,2.42,.13,steel,cx+dx+.60,1.21,coreZ+coreD/2+.12);
    box(parent,1.25,.06,.13,steel,cx+dx,2.43,coreZ+coreD/2+.12);
  }
  buildTowerStairCore(parent,cx,levelHeight,materials);
  // Muro cortina sobre la fachada principal, con montantes verticales y bandas horizontales.
  const front=blockDepth/2+.025,glassY=levelHeight*.52,glassHeight=levelHeight-.62;
  box(parent,blockWidth-1.0,glassHeight,.09,glass,cx,glassY,front);
  for(let i=0;i<=6;i++){
    const x=cx-(blockWidth-1.0)/2+i*(blockWidth-1.0)/6;
    box(parent,.075,glassHeight+.12,.15,steel,x,glassY,front+.075);
  }
  box(parent,blockWidth,.28,.34,steel,cx,.20,front+.02);
  box(parent,blockWidth,.28,.34,steel,cx,levelHeight-.20,front+.02);
  // Cruces diagonales visibles desde el exterior (inspiradas en las fotografías aportadas).
  const bayCount=4,bayWidth=(blockWidth-1.5)/bayCount;
  for(let i=0;i<bayCount;i++){
    const x0=cx-(blockWidth-1.5)/2+i*bayWidth+.1,x1=x0+bayWidth-.2,xm=(x0+x1)/2;
    addTowerBeam(parent,x0,.42,front+.17,xm,levelHeight-.42,.18,steel);
    addTowerBeam(parent,xm,levelHeight-.42,front+.17,x1,.42,.18,steel);
  }
  // Fachadas laterales con paneles vidriados entre machones.
  for(const side of [-1,1]){
    const sx=cx+side*(blockWidth/2-.65);
    box(parent,.08,glassHeight,blockDepth-1.0,glass,sx,glassY,0);
    for(const z of [-blockDepth*.28,0,blockDepth*.28])box(parent,.13,glassHeight,.08,steel,sx+side*.07,glassY,z);
    box(parent,.34,.24,blockDepth,darkConcrete,cx+side*(blockWidth/2-.17),levelHeight-.12,0);
  }
  // Banda posterior y dinteles que dan continuidad al volumen.
  box(parent,blockWidth,.32,.42,darkConcrete,cx,levelHeight-.18,-blockDepth/2+.12);
  if(ground){
    // Acceso acristalado y lobby genérico: el plano interior real no está publicado.
    box(parent,blockWidth-1.3,2.65,.10,glass,cx,1.34,front+.11);
    for(const dx of [-2.8,-1.4,0,1.4,2.8])box(parent,.055,2.68,.14,steel,cx+dx,1.34,front+.18);
  }
  if(sign)addTowerSign(parent,cx,levelHeight*.82,front+.22);
  if(top){
    box(parent,blockWidth,.22,blockDepth,concrete,cx,levelHeight+.03,0);
    for(const x of [-1,1])box(parent,.28,.75,blockDepth,darkConcrete,cx+x*(blockWidth/2-.2),levelHeight+.46,0);
  }
}
function buildSenatiTowerArchitecture(){
  towerWorldState=buildTowerWorld(roomGroup,appearance,room);
  gridHelper=new THREE.GridHelper(Math.max(room.width,room.depth),Math.max(room.width,room.depth),0x90a8c4,0xb6c4d6);
  gridHelper.scale.set(room.width/Math.max(room.width,room.depth),1,room.depth/Math.max(room.width,room.depth));
  gridHelper.position.y=floorElevation(activeFloorIndex)+.012;
  gridHelper.material.transparent=true;gridHelper.material.opacity=.035;gridHelper.visible=gridVisible;roomGroup.add(gridHelper);
  floorMeshes=[];floorMesh=null;roofMesh=null;
}
function makeRoom(){
  roomGroup.clear();
  if(appearance.buildingPlan==='senati-tower'){
    buildSenatiTowerArchitecture();
    gridHelper.visible=gridVisible;
    syncFloorControls();
    positionCamera();
    $('stage-dimensions').textContent=`${room.width.toFixed(0)} × ${room.depth.toFixed(0)} m · conjunto SENATI Torre 1`;
    $('viewport-status').textContent=`${getFloors().length} niveles · 3 bloques conectados`;
    applyFloorVisibility();
    return;
  }
  const baseStyle=floorStyle(0);
  const floorMat=new THREE.MeshStandardMaterial({color:0xffffff,map:makeFloorTexture(baseStyle.floorType,baseStyle.floorColor),roughness:baseStyle.floorType==='wood'?.66:.72,metalness:0});
  floorMesh=mesh(roomGroup,new THREE.PlaneGeometry(room.width,room.depth),floorMat,0,floorElevation(0),0,false);floorMesh.rotation.x=-Math.PI/2;floorMesh.userData.isFloor=true;floorMeshes=[floorMesh];
  gridHelper=new THREE.GridHelper(Math.max(room.width,room.depth),Math.max(room.width,room.depth),0x90a8c4,0xb6c4d6);
  gridHelper.scale.set(room.width/Math.max(room.width,room.depth),1,room.depth/Math.max(room.width,room.depth));gridHelper.position.y=floorElevation(0)+.012;gridHelper.material.transparent=true;gridHelper.material.opacity=.075;roomGroup.add(gridHelper);
  // Aula: franja azul inferior y paredes claras superiores; ventanales en el lateral izquierdo y acceso acristalado a la derecha.
  const windowCenters=[-room.depth*.30,0,room.depth*.30].map(v=>({center:v,width:2.15,type:'window'}));
  const doorCenter=room.depth*.36;
  buildWallZ(-room.depth/2,[]);buildWallZ(room.depth/2,[]);
  buildWallX(-room.width/2,windowCenters);buildWallX(room.width/2,[{center:doorCenter,width:1.48,type:'door'}]);
  // Zócalo superior e inferior y líneas de encuentro.
  const trim=mat(0xd8e0e9,.7),base=mat(0x0c438f,.62);
  box(roomGroup,room.width,.045,.205,trim,0,room.height-.02,-room.depth/2);box(roomGroup,room.width,.045,.205,trim,0,room.height-.02,room.depth/2);
  box(roomGroup,.205,.045,room.depth,trim,-room.width/2,room.height-.02,0);box(roomGroup,.205,.045,room.depth,trim,room.width/2,room.height-.02,0);
  box(roomGroup,room.width,.055,.22,base,0,.96,-room.depth/2);box(roomGroup,room.width,.055,.22,base,0,.96,room.depth/2);
  box(roomGroup,.22,.055,room.depth,base,-room.width/2,.96,0);box(roomGroup,.22,.055,room.depth,base,room.width/2,.96,0);
  const edge=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(room.width,.025,room.depth)),new THREE.LineBasicMaterial({color:0xb9c6d6,transparent:true,opacity:.35}));edge.position.y=.012;roomGroup.add(edge);
  if(getFloors().length>1){for(let level=0;level<getFloors().length-1;level++)buildTwoFloorArchitecture(level*room.height);}
  const totalHeight=room.height*getFloors().length;
  roofMesh=mesh(roomGroup,new THREE.BoxGeometry(room.width,.12,room.depth),mat(0xf1f3f7,.82),0,totalHeight,0,false);roofMesh.visible=roofVisible;
  addBranding();buildExterior();
  gridHelper.visible=gridVisible;
  syncFloorControls();
  positionCamera();
  $('stage-dimensions').textContent=`${room.width.toFixed(2)} × ${room.depth.toFixed(2)} m`;
  $('viewport-status').textContent=`${room.width.toFixed(0)} × ${room.depth.toFixed(0)} m`;
}
function positionCamera(){
  camera.fov=50;camera.updateProjectionMatrix();
  const span=Math.max(room.width,room.depth);
  const floors=getFloors();
  const totalHeight=room.height*floors.length;
  const individualFloor=$('construction-floor')?.value!=='all';
  const baseY=individualFloor?floorElevation(activeFloorIndex):0;
  if(appearance.buildingPlan==='senati-tower'){
    const minY=Math.min(...floors.map(f=>f.elevation)),maxY=Math.max(...floors.map(f=>f.elevation));
    const centerY=individualFloor?baseY+2.1:(minY+maxY+room.height)/2;
    camera.position.set(0,individualFloor?centerY+Math.max(8,span*.18):centerY+span*.55,span*1.42);
    controls.target.set(0,centerY,0);
    controls.minDistance=5;controls.maxDistance=span*5.2;controls.update();return;
  }
  camera.position.set(0,baseY+Math.max(8.5,individualFloor?room.height+span*.30:totalHeight+span*.30),span*1.25);
  controls.target.set(0,individualFloor?baseY+1.05:(appearance.buildingPlan==='two-floor'?room.height*.92:1.05),0);
  controls.minDistance=3.2;controls.maxDistance=Math.max(55,span*4.2);controls.update();
}
function setPointer(event) {
  const rect=renderer.domElement.getBoundingClientRect();
  pointer.x=((event.clientX-rect.left)/rect.width)*2-1;
  pointer.y=-((event.clientY-rect.top)/rect.height)*2+1;
  raycaster.setFromCamera(pointer,camera);
}
function pointOnFloor(event) {
  setPointer(event);
  const plane=new THREE.Plane(new THREE.Vector3(0,1,0),-(floorElevation(activeFloorIndex)+floorY));
  const out=new THREE.Vector3();
  return raycaster.ray.intersectPlane(plane,out) ? out : null;
}
function clampToRoom(v) {
  return new THREE.Vector3(
    THREE.MathUtils.clamp(v.x,-room.width/2+.25,room.width/2-.25),
    floorElevation(activeFloorIndex),
    THREE.MathUtils.clamp(v.z,-room.depth/2+.25,room.depth/2-.25)
  );
}
function createPerson(key, seated=false, personConfig={}) {
  const g=new THREE.Group();
  const isTeacher=key==='teacher'||key==='teacher-f';
  const isWoman=key.startsWith('woman')||key==='teacher-f';
  const isSenati=key.endsWith('-senati');
  const casualColors=isWoman?[0x287f79,0x72578d,0xa85d72,0x376f9d]:[0x286da5,0x347b62,0x986344,0x596985];
  const shirtColor=personConfig.shirtColor ? Number(personConfig.shirtColor) : (isTeacher?0x24364b:(isSenati?0x123f72:casualColors[Math.floor(Math.random()*casualColors.length)]));
  const skin=mat(isWoman?0xd9a27e:0xc98e69,.9);
  const shirt=mat(shirtColor,.82);
  const pants=mat(isTeacher?0x202b39:(isWoman?0x263448:0x202b3b),.9);
  const hair=mat(isWoman?0x68402f:(isTeacher?0x292522:0x292724),.96);
  const shoe=mat(0x17202b,.78), eye=mat(0x202832,.72), eyeWhite=mat(0xf5f5f2,.62);
  const ellipsoid=(parent,scale,material,pos)=>{
    const m=mesh(parent,new THREE.SphereGeometry(1,24,18),material,...pos);
    m.scale.set(...scale);return m;
  };
  const capsuleBetween=(parent,r,material,a,b)=>{
    const va=new THREE.Vector3(...a),vb=new THREE.Vector3(...b),dir=vb.clone().sub(va);
    const m=mesh(parent,new THREE.CapsuleGeometry(r,Math.max(.005,dir.length()-2*r),8,14),material);
    m.position.copy(va.add(vb).multiplyScalar(.5));
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize());
    return m;
  };
  const topY=seated?.84:1.08;
  const headY=seated?1.48:1.72;
  // Torso with a subtle waist taper and separate shoulder volume.
  ellipsoid(g,[.218,seated?.285:.325,.145],shirt,[0,topY,0]);
  ellipsoid(g,[.205,.105,.142],shirt,[0,topY-.205,0]);
  ellipsoid(g,[.225,.105,.135],shirt,[0,topY+.205,0]);
  const neck=mesh(g,new THREE.CylinderGeometry(.067,.078,.15,24),skin,0,topY+.37,.008);neck.rotation.x=-.04;
  // Collar, placket and small garment details.
  const collarMat=mat(isTeacher?0xe7edf2:0xdce6ed,.82);
  capsuleBetween(g,.018,collarMat,[-.075,topY+.30,.12],[0,topY+.22,.15]);
  capsuleBetween(g,.018,collarMat,[.075,topY+.30,.12],[0,topY+.22,.15]);
  if(!isTeacher){
    for(let i=0;i<3;i++)ellipsoid(g,[.008,.008,.006],mat(0xd6e2ea,.8),[0,topY+.075-i*.065,.148]);
  }
  {
    const badgeCanvas=document.createElement('canvas');badgeCanvas.width=384;badgeCanvas.height=128;
    const bc=badgeCanvas.getContext('2d');bc.fillStyle='#123f72';bc.fillRect(0,0,384,128);bc.fillStyle='#fff';bc.font='bold 58px Arial';bc.textAlign='center';bc.textBaseline='middle';bc.fillText('SENATI',192,64);
    const badgeTex=new THREE.CanvasTexture(badgeCanvas);badgeTex.colorSpace=THREE.SRGBColorSpace;
    const badge=mesh(g,new THREE.PlaneGeometry(.17,.057),new THREE.MeshBasicMaterial({map:badgeTex}),.105,topY+.11,.148,false);badge.userData.personBadge=true;g.userData.personBadge=badge;badge.visible=(personConfig.shirtStyle|| (isSenati?'senati':'custom'))==='senati';
  }
  if(isTeacher){
    const jacket=mat(0x30465f,.84),shirtFront=mat(0xf0f2f3,.75),tie=mat(0x8b3d4a,.72);
    ellipsoid(g,[.102,.245,.018],shirtFront,[0,topY+.005,.145]);
    capsuleBetween(g,.025,jacket,[-.18,topY+.27,.06],[-.07,topY-.19,.12]);
    capsuleBetween(g,.025,jacket,[.18,topY+.27,.06],[.07,topY-.19,.12]);
    const tieMesh=mesh(g,new THREE.ConeGeometry(.035,.22,5),tie,0,topY-.055,.17);tieMesh.rotation.x=Math.PI;
  }
  // Face: ears, eyes with pupils/highlights, brows, nose and a discreet smile.
  ellipsoid(g,[.158,.184,.145],skin,[0,headY,.014]);
  for(const side of [-1,1])ellipsoid(g,[.032,.05,.027],skin,[side*.157,headY-.005,.002]);
  for(const side of [-1,1]){
    ellipsoid(g,[.026,.027,.014],eyeWhite,[side*.053,headY+.018,.145]);
    ellipsoid(g,[.012,.016,.008],eye,[side*.053,headY+.016,.158]);
    ellipsoid(g,[.004,.005,.003],eyeWhite,[side*.049,headY+.022,.164]);
    capsuleBetween(g,.008,hair,[side*.029,headY+.065,.145],[side*.079,headY+.064,.137]);
  }
  ellipsoid(g,[.016,.023,.018],skin,[0,headY-.035,.151]);
  const smilePts=[new THREE.Vector3(-.031,headY-.079,.142),new THREE.Vector3(0,headY-.087,.15),new THREE.Vector3(.031,headY-.079,.142)];
  mesh(g,new THREE.TubeGeometry(new THREE.CatmullRomCurve3(smilePts),10,.0045,5,false),eye,0,0,0,false);
  // Natural hair cap and hairline; ponytail is kept behind the shoulders.
  ellipsoid(g,[.164,.096,.151],hair,[0,headY+.115,-.012]);
  ellipsoid(g,[.16,.045,.055],hair,[0,headY+.065,.112]);
  if(isWoman){
    ellipsoid(g,[.052,.16,.06],hair,[.128,headY-.075,-.055]);
    ellipsoid(g,[.052,.16,.06],hair,[-.128,headY-.075,-.055]);
    ellipsoid(g,[.065,.12,.065],hair,[.015,headY-.16,-.17]);
  } else {
    ellipsoid(g,[.15,.045,.11],hair,[0,headY+.045,-.105]);
  }
  if(isTeacher){
    for(const side of [-1,1]){
      const lens=mesh(g,new THREE.TorusGeometry(.034,.0035,6,18),mat(0x344454,.42,.22),side*.053,headY+.018,.158);
      lens.scale.set(1,.74,1);
    }
    capsuleBetween(g,.009,mat(0x344454,.42,.2),[-.018,headY+.056,.16],[.018,headY+.056,.16]);
  }
  // Articulated arms. Seated hands reach toward the workstation; standing arms swing from shoulders.
  const armPivots={},legPivots={},kneePivots={};
  for(const side of [-1,1]){
    if(seated){
      const shoulder=[side*.205,topY+.16,.015],elbow=[side*.27,topY+.045,.27],wrist=[side*.30,topY-.065,.52];
      capsuleBetween(g,.069,shirt,shoulder,elbow);ellipsoid(g,[.069,.069,.069],shirt,elbow);
      capsuleBetween(g,.052,skin,[elbow[0],elbow[1],elbow[2]],[wrist[0],wrist[1],wrist[2]]);
      ellipsoid(g,[.056,.035,.07],skin,[wrist[0],wrist[1],wrist[2]+.025]);
      for(let f=0;f<4;f++)capsuleBetween(g,.009,skin,[wrist[0]+(f-1.5)*.022,wrist[1]-.008,wrist[2]+.045],[wrist[0]+(f-1.5)*.022,wrist[1]-.012,wrist[2]+.092]);
      ellipsoid(g,[.018,.027,.026],skin,[wrist[0]+side*.048,wrist[1],wrist[2]+.015]);
    }else{
      const arm=new THREE.Group();arm.position.set(side*.22,topY+.16,0);g.add(arm);
      capsuleBetween(arm,.071,shirt,[0,0,0],[side*.035,-.245,.012]);
      ellipsoid(arm,[.071,.071,.071],shirt,[side*.035,-.245,.012]);
      const elbow=new THREE.Group();elbow.position.set(side*.035,-.245,.012);arm.add(elbow);
      capsuleBetween(elbow,.052,shirt,[0,0,0],[side*.025,-.225,.045]);
      ellipsoid(elbow,[.054,.054,.054],skin,[side*.025,-.225,.045]);
      ellipsoid(elbow,[.052,.035,.068],skin,[side*.025,-.235,.095]);
      for(let f=0;f<4;f++)capsuleBetween(elbow,.009,skin,[side*.025+(f-1.5)*.021,-.238,.13],[side*.025+(f-1.5)*.021,-.245,.177]);
      ellipsoid(elbow,[.018,.026,.027],skin,[side*.075,-.222,.09]);
      armPivots[side<0?'left':'right']=arm;
    }
  }
  // Pelvis and legs. Female casual figures use tailored trousers; all silhouettes share the same scale.
  ellipsoid(g,[.178,seated?.12:.15,.135],pants,[0,seated?.59:.79,0]);
  if(isWoman&&!seated&&!isTeacher){
    // A clean, modest A-line skirt panel over the upper legs.
    const skirt=mesh(g,new THREE.CylinderGeometry(.155,.205,.27,32),pants,0,.68,0);skirt.scale.set(1,1,.82);
  }
  for(const side of [-1,1]){
    if(seated){
      const hip=[side*.105,.57,0],knee=[side*.11,.52,.30],ankle=[side*.11,.15,.33];
      capsuleBetween(g,.073,pants,hip,knee);ellipsoid(g,[.074,.072,.074],pants,knee);
      capsuleBetween(g,.06,pants,knee,ankle);
      ellipsoid(g,[.105,.052,.17],shoe,[side*.11,.075,.405]);
      // Sole gives the shoe a distinct, grounded silhouette.
      ellipsoid(g,[.108,.018,.171],mat(0x101820,.9),[side*.11,.043,.405]);
    }else{
      const leg=new THREE.Group();leg.position.set(side*.105,.79,0);g.add(leg);
      capsuleBetween(leg,.071,pants,[0,0,0],[0,-.35,.005]);
      ellipsoid(leg,[.073,.072,.074],pants,[0,-.35,.005]);
      const knee=new THREE.Group();knee.position.set(0,-.35,.005);leg.add(knee);
      capsuleBetween(knee,.057,pants,[0,0,0],[0,-.32,.015]);
      ellipsoid(knee,[.059,.058,.06],pants,[0,-.32,.015]);
      ellipsoid(knee,[.09,.047,.15],shoe,[0,-.685,.09]);
      ellipsoid(knee,[.092,.016,.152],mat(0x101820,.9),[0,-.718,.09]);
      legPivots[side<0?'left':'right']=leg;
      kneePivots[side<0?'left':'right']=knee;
    }
  }
  // Teacher lanyard and restrained tailoring details.
  if(isTeacher){
    capsuleBetween(g,.009,mat(0xd2b66a,.65),[.12,topY+.25,.145],[.12,topY+.04,.15]);
    box(g,.045,.065,.012,mat(0xced9e3,.58),.12,topY-.005,.16);
  }
  g.userData.kind=key;
  g.userData.seated=seated;
  g.userData.personConfig={shirtColor:`#${shirtColor.toString(16).padStart(6,'0')}`,shirtStyle:personConfig.shirtStyle|| (isSenati?'senati':'custom')};
  g.userData.shirtMaterial=shirt;
  g.userData.rig={animated:!seated,seated,leftArm:armPivots.left,rightArm:armPivots.right,leftLeg:legPivots.left,rightLeg:legPivots.right,leftKnee:kneePivots.left,rightKnee:kneePivots.right};
  return g;
}
function createModel(key, seated=false, config={}) {
  const g=new THREE.Group();
  const deskTopY=.78;
  switch(key){
    case 'desk': {
      const deskMat=mat(appearance.deskColor,.48);
      const deskEdgeMat=mat(appearance.deskColor,.58);
      g.userData.primaryColorMaterial=deskMat;
      g.userData.secondaryColorMaterial=deskEdgeMat;
      // Escritorio con orientación local inequívoca: frente = +Z, posterior = -Z.
      // La huella es idéntica en todas las instancias: 158 x 72 cm.
      mesh(g,new RoundedBoxGeometry(DESK_LENGTH,.10,DESK_DEPTH,4,.035),deskMat,0,deskTopY,0);
      box(g,DESK_LENGTH+.025,.025,DESK_DEPTH+.02,deskEdgeMat,0,deskTopY-.065,0);
      // Canal posterior para cableado: identifica el lado donde va el monitor.
      box(g,.92,.012,.045,mat(0x343b43,.8),0,.837,-.315);
      // Zona de teclado marcada sobre la superficie (sin relieve molesto).
      box(g,.72,.004,.245,mat(0xc7b99e,.9),-.055,.833,.105);
      // Línea frontal discreta y redondeada visualmente mediante una moldura fina.
      box(g,1.34,.012,.018,mat(0x9b805e,.72),0,.837,.345);
      // Patas y travesaños simétricos para mantener una geometría consistente.
      for(const x of [-.70,.70]) for(const z of [-.27,.27]) box(g,.055,.72,.055,mats.metal,x,.36,z);
      box(g,1.28,.045,.035,mats.metal,0,.39,-.27);
      g.userData.deskOrientation={front:'+Z',rear:'-Z',standardLength:DESK_LENGTH,standardDepth:DESK_DEPTH};
      break;
    }
    case 'chair': {
      const chairMat=mat(appearance.chairColor,.88);
      const upholstery=mat(new THREE.Color(appearance.chairColor).lerp(new THREE.Color(0xffffff),.10),.94);
      const seamMat=mat(0x111c29,.92), chrome=mat(0x84919d,.48,.42);
      g.userData.primaryColorMaterial=chairMat;
      // Ergonomic upholstered seat and a gently reclined backrest.
      box(g,.50,.105,.47,chairMat,0,.59,0);
      box(g,.46,.055,.43,upholstery,0,.665,.005);
      const back=box(g,.49,.58,.105,chairMat,0,1.00,-.18);back.rotation.x=-.09;
      const backPad=box(g,.445,.52,.055,upholstery,0,1.005,-.115);backPad.rotation.x=-.09;
      box(g,.40,.012,.012,seamMat,0,.78,-.082);
      // Twin supports, a metal gas lift and five-spoke wheeled base.
      for(const side of [-1,1]){
        const support=box(g,.035,.31,.045,chrome,side*.17,.77,-.17);support.rotation.x=-.10;
        const arm=box(g,.055,.035,.29,chrome,side*.25,.72,-.005);arm.rotation.x=-.08;
      }
      cylinder(g,.052,.052,.30,chrome,0,.36,0,24);
      cylinder(g,.092,.092,.055,mat(0x596674,.55,.34),0,.205,0,24);
      for(let i=0;i<5;i++){
        const a=i*Math.PI*2/5;
        const spoke=box(g,.40,.032,.045,chrome,Math.cos(a)*.18,.12,Math.sin(a)*.18);spoke.rotation.y=-a;
        const wheel=mesh(g,new THREE.SphereGeometry(1,20,14),mat(0x151b23,.76),Math.cos(a)*.39,.075,Math.sin(a)*.39);
        wheel.scale.set(.065,.045,.045);wheel.rotation.y=a;
      }
      break;
    }
    case 'aio': {
      // All-in-One XL: pantalla ampliada para que se lea claramente en aulas amplias.
      // Huella visual aproximada: 0.88 x 0.50 m; base y soporte proporcionales.
      box(g,.92,.535,.072,mats.black,0,1.185,0);
      box(g,.892,.507,.009,mat(0x080d16,.35),0,1.188,.039);
      const screen=box(g,.868,.488,.008,mat(0x0c3155,.25),0,1.188,.046);
      const stand=box(g,.095,.275,.082,mat(0x9aa6b2,.38,.35),0,.91,-.008);
      // Base ancha, con apoyo metálico visible y centrado sobre la mesa.
      const base=box(g,.405,.032,.245,mat(0x788694,.42,.28),0,.845,.045);base.rotation.x=-.035;
      box(g,.355,.014,.205,mat(0xc2cbd3,.36,.25),0,.868,.045);
      // Pantalla personalizable: Windows 11, SENATI o pantalla neutra.
      const c=document.createElement('canvas');c.width=768;c.height=432;
      const ctx=c.getContext('2d');
      const drawScreen=(mode='windows11')=>{
        ctx.clearRect(0,0,768,432);
        if(mode==='windows11'){
          const gr=ctx.createLinearGradient(0,0,768,432);gr.addColorStop(0,'#061a49');gr.addColorStop(.55,'#0876bd');gr.addColorStop(1,'#46c5dc');ctx.fillStyle=gr;ctx.fillRect(0,0,768,432);
          ctx.fillStyle='rgba(255,255,255,.16)';ctx.beginPath();ctx.ellipse(405,200,250,130,-.35,0,Math.PI*2);ctx.fill();
          ctx.fillStyle='#fff';ctx.font='500 25px Segoe UI,Arial';ctx.fillText('12:45',34,48);ctx.font='18px Segoe UI,Arial';ctx.fillText('Lunes, 2 de noviembre',34,78);
          ctx.fillStyle='rgba(18,34,63,.82)';ctx.beginPath();ctx.roundRect(180,374,408,42,18);ctx.fill();
          // Icono Windows de cuatro paneles y campo Buscar, dibujados sin depender de fuentes instaladas.
          ctx.fillStyle='#f5fbff';ctx.fillRect(300,386,11,11);ctx.fillRect(314,386,11,11);ctx.fillRect(300,400,11,11);ctx.fillRect(314,400,11,11);
          ctx.fillStyle='#fff';ctx.font='bold 19px Segoe UI,Arial';ctx.fillText('Buscar',345,403);ctx.font='20px Arial';ctx.fillText('···',520,403);
        } else if(mode==='senati'){
          const gr=ctx.createLinearGradient(0,0,768,432);gr.addColorStop(0,'#08264b');gr.addColorStop(1,'#1265a5');ctx.fillStyle=gr;ctx.fillRect(0,0,768,432);
          // Emblema institucional estilizado junto al nombre; se dibuja en canvas para verse en el monitor.
          ctx.beginPath();for(let i=0;i<6;i++){const a=-Math.PI/2+i*Math.PI/3,x=384+Math.cos(a)*70,y=132+Math.sin(a)*70;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.closePath();ctx.fillStyle='#ffffff';ctx.fill();
          ctx.fillStyle='#125b9b';ctx.font='900 92px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('S',384,132);
          ctx.fillStyle='#fff';ctx.font='bold 84px Arial';ctx.textBaseline='alphabetic';ctx.fillText('SENATI',384,286);ctx.fillStyle='#6bd2ed';ctx.fillRect(240,316,288,7);
          ctx.font='600 22px Arial';ctx.fillStyle='#d8efff';ctx.fillText('FORMACIÓN PROFESIONAL',384,357);ctx.textAlign='left';
        } else {ctx.fillStyle='#eef3f8';ctx.fillRect(0,0,768,432);ctx.fillStyle='#164b82';ctx.font='bold 48px Arial';ctx.textAlign='center';ctx.fillText('Pantalla de presentación',384,220);ctx.textAlign='left';}
      };
      drawScreen('windows11');
      const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
      const plane=mesh(g,new THREE.PlaneGeometry(.868,.488),new THREE.MeshBasicMaterial({map:tex}),0,1.188,.052);
      g.userData.screenCanvas=c;g.userData.screenTexture=tex;g.userData.drawScreen=drawScreen;g.userData.screenMode='windows11';
      break;
    }
    case 'keyboard': {
      box(g,.52,.026,.18,mats.black,0,.83,0);
      const keyMat=mat(0xd2d8df,.7);
      for(let r=0;r<4;r++)for(let i=0;i<14;i++)box(g,.023,.008,.019,keyMat,-.245+i*.036,.849,-.062+r*.041);
      break;
    }
    case 'mouse': {
      const shellMat=mat(0x252c35,.68),buttonMat=mat(0x343d49,.72),wheelMat=mat(0x9aa5b0,.62,.12);
      const shell=mesh(g,new THREE.SphereGeometry(1,24,18),shellMat,0,.84,0);shell.scale.set(.052,.029,.079);
      box(g,.002,.024,.072,buttonMat,0,.856,.004);
      const wheel=mesh(g,new THREE.CylinderGeometry(.009,.009,.009,16),wheelMat,0,.861,.014);wheel.rotation.z=Math.PI/2;
      box(g,.012,.008,.018,buttonMat,-.034,.85,-.005);box(g,.012,.008,.018,buttonMat,.034,.85,-.005);
      break;
    }
    case 'man': case 'woman': case 'man-senati': case 'woman-senati': case 'teacher': case 'teacher-f': {
      return createPerson(key, seated, config.personConfig||{});
    }
    case 'road': {
      const asphalt=mat(0x343b43,.98),paint=mat(0xf5f2e8,.72),curb=mat(0xc8cdd2,.9);
      box(g,20,.12,6.4,asphalt,0,.06,0);
      box(g,20,.025,.11,paint,0,.13,-2.8);box(g,20,.025,.11,paint,0,.13,2.8);
      for(let x=-8;x<=8;x+=2.4)box(g,1.18,.024,.10,paint,x,.135,0);
      box(g,20,.20,.18,curb,0,.10,-3.25);box(g,20,.20,.18,curb,0,.10,3.25);
      g.userData.worldSurface='road';break;
    }
    case 'ground': {
      const concrete=mat(0xc5ccd2,.94),joint=mat(0x9aa4ad,.96),edge=mat(0xe5e8eb,.9);
      box(g,10,.18,10,concrete,0,.09,0);
      for(let x=-4.5;x<=4.5;x+=1)box(g,.018,.012,9.92,joint,x,.186,0);
      for(let z=-4.5;z<=4.5;z+=1)box(g,9.92,.012,.018,joint,0,.186,z);
      box(g,10,.06,.08,edge,0,.20,-4.96);box(g,10,.06,.08,edge,0,.20,4.96);
      g.userData.worldSurface='ground';break;
    }
    case 'sidewalk': {
      const concrete=mat(0xb9c0c6,.92),joint=mat(0x929ba3,.96),curb=mat(0xe0e3e6,.9);
      box(g,12,.20,3.0,concrete,0,.10,0);
      for(let x=-5.5;x<=5.5;x+=1)box(g,.018,.012,2.92,joint,x,.207,0);
      for(let z=-1;z<=1;z+=1)box(g,11.95,.012,.018,joint,0,.208,z);
      box(g,12,.22,.16,curb,0,.11,-1.58);box(g,12,.22,.16,curb,0,.11,1.58);
      g.userData.worldSurface='sidewalk';break;
    }
    case 'wall': {
      const wallMat=mat(appearance.wallColor,.9);
      g.userData.primaryColorMaterial=wallMat;
      box(g,2.5,room.height,.16,wallMat,0,room.height/2,0);
      break;
    }
    case 'door': case 'door-normal': {
      const isNormal=key==='door-normal';
      const frame=mat(isNormal?0x59402f:0x485a6d,.36,.55),handle=mat(0xc2ccd6,.24,.82);
      box(g,1.42,2.48,.085,frame,0,1.24,0);
      const paneMat=isNormal?mat(0x986b45,.72):mats.glass;
      const pane=mesh(g,new THREE.BoxGeometry(1.28,2.34,.018),paneMat,0,1.24,.052);pane.renderOrder=3;
      box(g,.035,2.34,.055,frame,-.62,1.24,.065);box(g,.035,2.34,.055,frame,.62,1.24,.065);
      box(g,1.26,.035,.055,frame,0,2.40,.065);box(g,1.26,.035,.055,frame,0,.08,.065);
      box(g,.025,2.28,.045,frame,0,1.24,.075);
      box(g,.035,.74,.075,handle,.47,1.18,.12);cylinder(g,.025,.025,.035,handle,.45,1.18,.15,16);
      box(g,1.30,.045,.07,handle,0,.035,.08);
      break;
    }
    case 'window': {
      const frame=mat(0x485a6d,.34,.58),seal=mat(0xe8eef4,.58);
      const pane=mesh(g,new THREE.BoxGeometry(2.08,1.35,.018),mats.glass,0,1.84,.04);pane.renderOrder=3;
      box(g,2.18,.055,.09,frame,0,2.53,0);box(g,2.18,.055,.09,frame,0,1.15,0);
      box(g,.055,1.42,.09,frame,-1.06,1.84,0);box(g,.055,1.42,.09,frame,1.06,1.84,0);
      box(g,.035,1.32,.07,frame,0,1.84,.045);
      box(g,2.08,.025,.055,seal,0,1.84,.065);
      break;
    }
    case 'safety-exit': case 'safety-rules': case 'safety-first-aid': case 'safety-electrical': case 'safety-safe-zone': case 'safety-evacuation': {
      const isExit=key==='safety-exit', isRules=key==='safety-rules';
      const presets={
        'safety-exit':{w:.82,h:.42,bg:'#087a45',fg:'#ffffff',title:'SALIDA'},
        'safety-rules':{w:1.02,h:.72,bg:'#f7f9fb',fg:'#17324d',title:'REGLAS DE SEGURIDAD'},
        'safety-first-aid':{w:.62,h:.52,bg:'#087a45',fg:'#ffffff',title:'BOTIQUÍN',symbol:'✚'},
        'safety-electrical':{w:.66,h:.58,bg:'#ffd22e',fg:'#1e293b',title:'RIESGO ELÉCTRICO',symbol:'⚡'},
        'safety-safe-zone':{w:.76,h:.58,bg:'#087a45',fg:'#ffffff',title:'ZONA SEGURA',symbol:'✚'},
        'safety-evacuation':{w:.82,h:.42,bg:'#087a45',fg:'#ffffff',title:'RUTA DE EVACUACIÓN',symbol:'➜'}
      };
      const p=presets[key];
      box(g,p.w,p.h,.055,mat(p.bg,.55),0,1.72,0);
      const c=document.createElement('canvas');c.width=640;c.height=420;const ctx=c.getContext('2d');
      ctx.fillStyle=p.bg;ctx.fillRect(0,0,640,420);ctx.strokeStyle=p.fg;ctx.lineWidth=13;ctx.strokeRect(8,8,624,404);
      ctx.fillStyle=p.fg;ctx.textAlign='center';
      if(isRules){
        ctx.font='bold 39px Arial';ctx.fillText(p.title,320,65);ctx.textAlign='left';ctx.font='bold 29px Arial';
        ['Mantén libre la salida','No bloquees los pasillos','Cuida cables y equipos','Sigue las indicaciones'].forEach((t,i)=>ctx.fillText('• '+t,35,135+i*66));
      } else if(isExit){
        // Rótulo de texto limpio, sin flecha; se coloca centrado sobre la puerta.
        ctx.font='bold 112px Arial';ctx.textBaseline='middle';ctx.fillText('SALIDA',320,220);ctx.textBaseline='alphabetic';
      } else {
        ctx.font=`bold ${key==='safety-evacuation'?47:58}px Arial`;ctx.fillText(p.title,320,key==='safety-electrical'?82:90);
        ctx.font='bold 190px Arial';ctx.fillText(p.symbol||'',320,300);
      }
      const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
      const plane=mesh(g,new THREE.PlaneGeometry(p.w-.025,p.h-.025),new THREE.MeshBasicMaterial({map:tex}),0,1.72,.031);plane.renderOrder=4;
      g.userData.safetySign=true;
      break;
    }
    case 'fire-extinguisher': {
      const red=mat(0xc62828,.42),dark=mat(0x283443,.5),metal=mat(0xaeb8c2,.32,.65);
      cylinder(g,.105,.12,.62,red,0,.40,0,24);
      cylinder(g,.105,.105,.045,mat(0x9f1d1d,.45),0,.72,0,24);
      cylinder(g,.035,.035,.09,metal,0,.79,0,16);
      const handle=box(g,.19,.035,.045,dark,.055,.84,0);handle.rotation.z=-.12;
      const hose=mesh(g,new THREE.TorusGeometry(.105,.012,8,24,Math.PI*1.35),dark,-.11,.70,.025);hose.rotation.z=Math.PI/2;
      box(g,.27,.035,.035,metal,0,.06,0);
      const labelCanvas=document.createElement('canvas');labelCanvas.width=256;labelCanvas.height=128;const lc=labelCanvas.getContext('2d');
      lc.fillStyle='#fff';lc.fillRect(0,0,256,128);lc.fillStyle='#c62828';lc.font='bold 31px Arial';lc.textAlign='center';lc.fillText('EXTINTOR',128,49);lc.font='bold 23px Arial';lc.fillText('ABC',128,88);
      const labelTex=new THREE.CanvasTexture(labelCanvas);labelTex.colorSpace=THREE.SRGBColorSpace;
      mesh(g,new THREE.PlaneGeometry(.18,.09),new THREE.MeshBasicMaterial({map:labelTex}),0,.43,.122);
      g.userData.safetyEquipment=true;
      break;
    }
    case 'whiteboard': {
      box(g,2.4,1.25,.08,mats.metal,0,1.65,0);
      box(g,2.28,1.13,.035,mats.white,0,1.65,.05);
      break;
    }
    case 'fluorescent': {
      const frame=mat(0x64748b,.4,.45),emitter=new THREE.MeshStandardMaterial({color:0xffffff,emissive:0xffffff,emissiveIntensity:2.3,roughness:.25});
      box(g,1.48,.065,.30,frame,0,room.height-.15,0);
      box(g,1.32,.025,.20,emitter,0,room.height-.105,0);
      const light=new THREE.PointLight(0xfff9ed,3.8,6.8,1.7);light.position.set(0,room.height-.28,0);light.castShadow=false;g.add(light);
      break;
    }
    case 'fan': {
      // Mounting plate, downrod and motor are fixed; blades share one centered rotor.
      const ceilingY=room.height-.08;
      cylinder(g,.24,.24,.055,mats.metal,0,ceilingY,0,32);
      cylinder(g,.045,.045,.34,mats.metal,0,room.height-.27,0,20);
      cylinder(g,.19,.19,.20,mat(0x66717d,.42,.45),0,room.height-.49,0,32);
      cylinder(g,.105,.105,.08,mat(0x9da8b3,.35,.5),0,room.height-.63,0,24);
      const rotor=new THREE.Group();
      rotor.position.y=room.height-.64;
      const bladeShape=new THREE.Shape();
      bladeShape.moveTo(-.085,.10);
      bladeShape.quadraticCurveTo(-.17,.42,-.105,.91);
      bladeShape.quadraticCurveTo(-.02,1.10,.105,1.02);
      bladeShape.quadraticCurveTo(.15,.60,.085,.10);
      bladeShape.closePath();
      const bladeGeo=new THREE.ExtrudeGeometry(bladeShape,{depth:.035,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:.012,bevelThickness:.008});
      bladeGeo.rotateX(-Math.PI/2);
      const bladeMat=mat(0xe7ebef,.48,.18);
      for(let i=0;i<3;i++){
        const blade=mesh(rotor,bladeGeo,bladeMat,0,0,0);
        blade.rotation.y=i*Math.PI*2/3;
      }
      cylinder(rotor,.125,.125,.09,mat(0x7d8995,.35,.5),0,.035,0,24);
      g.add(rotor);
      g.userData.fanRotor=rotor;
      break;
    }
    case 'projector': {
      box(g,.48,.18,.42,mats.white,0,room.height-.22,0);
      cylinder(g,.08,.08,.07,mats.black,.23,room.height-.22,0,16).rotation.z=Math.PI/2;
      break;
    }
    case 'plant': {
      cylinder(g,.22,.27,.35,mat(0x9b6546,.85),0,.18,0);
      for(let i=0;i<7;i++){const leaf=mesh(g,new THREE.SphereGeometry(.13,12,8),mat(0x3d8158,.8),Math.cos(i)*.18,.55+Math.sin(i*1.3)*.18,Math.sin(i)*.18);leaf.scale.set(.65,1.5,.65);}
      break;
    }
  }
  return g;
}
function applyAppearance(){
  const savedCamera=camera.position.clone();
  const savedTarget=controls.target.clone();
  if(floorMesh?.material?.map)floorMesh.material.map.dispose();
  makeRoom();
  camera.position.copy(savedCamera);
  controls.target.copy(savedTarget);
  controls.update();
  placed.forEach(o=>{
    const key=o.userData.catalogKey;
    if(o.userData.primaryColorMaterial){
      if(key==='desk')o.userData.primaryColorMaterial.color.set(appearance.deskColor);
      if(key==='chair')o.userData.primaryColorMaterial.color.set(appearance.chairColor);
      if(key==='wall')o.userData.primaryColorMaterial.color.set(appearance.wallColor);
    }
    if(key==='desk'&&o.userData.secondaryColorMaterial){
      o.userData.secondaryColorMaterial.color.set(appearance.deskColor);
    }
  });
  markDirty();
}
function syncAppearanceInputs(){
  const scope=$('floor-edit-scope')?.value||'global';
  const floorStyleNow=scope==='global'?{floorType:appearance.floorType,floorColor:appearance.floorColor}:floorStyle(Number(scope));
  $('floor-type').value=floorStyleNow.floorType;
  $('floor-color').value=floorStyleNow.floorColor;
  $('wall-color').value=appearance.wallColor;
  $('desk-color').value=appearance.deskColor;
  $('chair-color').value=appearance.chairColor;
}
['floor-type','floor-color'].forEach(id=>{
  $(id).addEventListener('change',()=>{
    const scope=$('floor-edit-scope').value;
    const floors=getFloors();
    const targets=scope==='global'?floors:[floors[Number(scope)]].filter(Boolean);
    targets.forEach(f=>{f.floorType=$('floor-type').value;f.floorColor=$('floor-color').value;});
    if(scope==='global'){appearance.floorType=$('floor-type').value;appearance.floorColor=$('floor-color').value;}
    applyAppearance();showToast(scope==='global'?'Material del piso aplicado a todos los niveles.':'Material aplicado al piso seleccionado.');
  });
});
['wall-color','desk-color','chair-color'].forEach(id=>{
  $(id).addEventListener('change',()=>{
    appearance={...appearance,wallColor:$('wall-color').value,deskColor:$('desk-color').value,chairColor:$('chair-color').value};
    applyAppearance();showToast('Material global actualizado en el edificio.');
  });
});
$('floor-edit-scope').addEventListener('change',syncFloorControls);
$('construction-floor').addEventListener('change',e=>{if(e.target.value==='all'){applyFloorVisibility();$('viewport-status').textContent='Vista global: todos los niveles';}else selectConstructionFloor(Number(e.target.value));});
$('add-floor').addEventListener('click',()=>{
  const count=getFloors().length;
  if(count>=MAX_FLOORS){showToast(`El límite actual es de ${MAX_FLOORS} niveles por escenario.`);return;}
  setFloorCount(count+1);selectConstructionFloor(count);showToast(`${getFloors()[count].name} agregado. Ya puedes construir en ese nivel.`);
});
$('remove-floor').addEventListener('click',()=>{
  if(getFloors().length<=1)return;
  const floors=getFloors(),last=floors.length-1;
  const count=placed.filter(o=>nearestFloorIndex(o.position.y,floors)===last).length;
  if(count&&!confirm(`El piso ${last+1} contiene ${count} objetos. Se eliminarán al quitar el nivel. ¿Continuar?`))return;
  setFloorCount(last);selectConstructionFloor(Math.min(activeFloorIndex,last-1));showToast(`Piso ${last+1} eliminado.`);
});
$('reset-appearance').addEventListener('click',()=>{
  appearance={...appearance,floorType:'tile',floorColor:'#f2f4f7',wallColor:'#f1f3f6',deskColor:'#1559a8',chairColor:'#202a38'};
  getFloors().forEach(f=>{f.floorType='tile';f.floorColor='#f2f4f7';});
  syncAppearanceInputs();applyAppearance();showToast('Materiales restablecidos en todos los pisos.');
});

function addObject(key, position, opts={}) {
  const item=catalog.find(o=>o.key===key);
  if(!item)return null;
  const model=createModel(key,Boolean(opts.seated),opts);
  if(['man','woman','man-senati','woman-senati','teacher','teacher-f'].includes(key)) model.userData.seated=Boolean(opts.seated);
  model.position.copy(position || new THREE.Vector3(0,0,0));
  model.rotation.y=opts.rotationY ?? 0;
  // Los escritorios siempre conservan la misma huella física, incluso al cargar escenarios antiguos.
  if(key==='desk') model.scale.set(1,1,1);
  else model.scale.set(opts.scaleX??1,opts.scaleY??1,opts.scaleZ??1);
  const id=opts.id || `obj-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
  model.userData.editorObject=true;
  model.userData.objectId=id;
  model.userData.catalogKey=key;
  model.userData.label=opts.label || item.label;
  model.userData.category=item.category;
  model.userData.floorIndex=nearestFloorIndex(model.position.y);
  model.userData.floorId=model.userData.floorIndex+1;
  if(opts.accessoryOf)model.userData.accessoryOf=opts.accessoryOf;
  if(opts.personConfig)model.userData.personConfig={...opts.personConfig};
  if(opts.screenMode&&model.userData.drawScreen){model.userData.drawScreen(opts.screenMode);model.userData.screenTexture.needsUpdate=true;model.userData.screenMode=opts.screenMode;}
  objectGroup.add(model);
  placed.push(model);
  if(key==='desk' && $('auto-station')?.checked && !opts.skipStation){ equipDesk(model,{silent:true}); }
  if(key==='chair' && $('auto-seat')?.checked && !opts.skipSeat){ seatPerson(model,placed.filter(o=>['man','woman','man-senati','woman-senati'].includes(o.userData.catalogKey)).length%2?'woman-senati':'man-senati'); }
  if(key==='aio'&&!opts.skipAccessories){
    // Keyboard and mouse are spawned as separate editable objects, aligned to the PC.
    const angle=model.rotation.y;
    const offset=(x,z)=>new THREE.Vector3(
      model.position.x + x*Math.cos(angle) + z*Math.sin(angle),
      model.position.y,
      model.position.z - x*Math.sin(angle) + z*Math.cos(angle)
    );
    addObject('keyboard',offset(0,.48),{rotationY:angle,silent:true,accessoryOf:id});
    addObject('mouse',offset(.30,.48),{rotationY:angle,silent:true,accessoryOf:id});
  }
  if(!opts.silent){
    selectObject(model);
    renderObjectList();
    markDirty();
  }
  return model;
}
function deskLocalPoint(desk,x,z){
  const a=desk.rotation.y;
  return new THREE.Vector3(desk.position.x+x*Math.cos(a)+z*Math.sin(a),desk.position.y,desk.position.z-x*Math.sin(a)+z*Math.cos(a));
}
function detectDeskSeatDirection(desk){
  // La orientación del mueble es la autoridad; no inferimos el frente por la silla.
  // Convención local fija: frente +Z (alumno), posterior -Z (monitor/canal de cables).
  return new THREE.Vector3(0,0,1);
}
function equipDesk(desk,opts={}){
  if(!desk||desk.userData.stationEquipped)return null;
  const angle=desk.rotation.y;
  // Monitor atrás, con la pantalla mirando al frente (+Z).
  const pcPos=deskLocalPoint(desk,0,-.235);
  // Teclado en la zona marcada y mouse a su derecha, ambos orientados al alumno.
  const keyboardPos=deskLocalPoint(desk,-.045,.115);
  const mousePos=deskLocalPoint(desk,.32,.115);
  const pc=addObject('aio',pcPos,{rotationY:angle,silent:true,skipAccessories:true,accessoryOf:desk.userData.objectId});
  addObject('keyboard',keyboardPos,{rotationY:angle,silent:true,accessoryOf:desk.userData.objectId});
  addObject('mouse',mousePos,{rotationY:angle,silent:true,accessoryOf:desk.userData.objectId});
  desk.userData.stationEquipped=true;
  desk.userData.stationLayout='fixed-front-rear-v1';
  if(!opts.silent){renderObjectList();markDirty();}
  return pc;
}
function unequipDesk(desk){
  if(!desk)return;
  const descendants=linkedDescendants(desk);
  descendants.forEach(o=>{objectGroup.remove(o);const i=placed.indexOf(o);if(i>=0)placed.splice(i,1);});
  desk.userData.stationEquipped=false;
}
function setAllDeskStations(enabled){
  const desks=placed.filter(o=>o.userData.catalogKey==='desk');
  desks.forEach(d=>enabled?equipDesk(d,{silent:true}):unequipDesk(d));
  renderObjectList();markDirty();
  showToast(enabled?`Estaciones activadas en ${desks.length} escritorios.`:`Se retiraron los equipos de ${desks.length} escritorios.`);
}
function seatPerson(chair,key='man',opts={}){
  if(!chair||chair.userData.occupied)return null;
  const angle=chair.rotation.y;
  const occupant=addObject(key,chair.position.clone(),{rotationY:angle,seated:true,silent:true,accessoryOf:chair.userData.objectId});
  chair.userData.occupied=true;
  return occupant;
}
function unseatPerson(chair){
  if(!chair)return;
  const id=chair.userData.objectId;
  const people=placed.filter(o=>o.userData.accessoryOf===id&&(['man','woman','man-senati','woman-senati'].includes(o.userData.catalogKey)));
  people.forEach(o=>{objectGroup.remove(o);const i=placed.indexOf(o);if(i>=0)placed.splice(i,1);});
  chair.userData.occupied=false;
}
function setAllSeats(enabled){
  const chairs=placed.filter(o=>o.userData.catalogKey==='chair');
  const variants=['man-senati','woman-senati'];
  chairs.forEach((c,i)=>enabled?seatPerson(c,variants[i%variants.length]):unseatPerson(c));
  renderObjectList();markDirty();
  showToast(enabled?`Se ocuparon ${chairs.length} asientos.`:`Se dejaron vacíos ${chairs.length} asientos.`);
}
function linkedDescendants(root){
  const result=[];const ids=new Set([root.userData.objectId]);let changed=true;
  while(changed){changed=false;placed.forEach(o=>{if(o!==root&&o.userData.accessoryOf&&ids.has(o.userData.accessoryOf)&&!ids.has(o.userData.objectId)){ids.add(o.userData.objectId);result.push(o);changed=true;}});}
  return result;
}
function moveLinkedObjects(root,delta){linkedDescendants(root).forEach(o=>o.position.add(delta));}
function rotateLinkedObjects(root,angle){
  const descendants=linkedDescendants(root),origin=root.position;
  descendants.forEach(o=>{const offset=o.position.clone().sub(origin).applyAxisAngle(new THREE.Vector3(0,1,0),angle);o.position.copy(origin).add(offset);o.rotation.y+=angle;});
}
function removeSelectionHelper(){
  if(selected)selected.traverse(node=>{if(node.isMesh&&node.userData._selectionOriginal){const current=node.material; if(Array.isArray(current))current.forEach(m=>m.dispose());else current.dispose();node.material=node.userData._selectionOriginal;delete node.userData._selectionOriginal;}});
  if(selectionHelper){scene.remove(selectionHelper);selectionHelper.geometry?.dispose();selectionHelper.material?.dispose();selectionHelper=null;}
}
function selectObject(obj) {
  removeSelectionHelper();
  selected=obj;
  if(selected){
    selectionHelper=new THREE.BoxHelper(selected,0xff7a00);
    selectionHelper.material.color.setHex(0xff7a00);selectionHelper.material.depthTest=false;selectionHelper.material.transparent=true;selectionHelper.material.opacity=1;selectionHelper.renderOrder=999;
    scene.add(selectionHelper);
    selected.traverse(node=>{if(node.isMesh){node.userData._selectionOriginal=node.material;const mats=Array.isArray(node.material)?node.material:[node.material];node.material=mats.map(m=>{const clone=m.clone();if(clone.emissive)clone.emissive.setHex(0x392000);return clone;});if(!Array.isArray(node.userData._selectionOriginal))node.material=node.material[0];}});
    $('empty-inspector').classList.add('hidden');
    $('object-inspector').classList.remove('hidden');
    document.querySelector('[data-left-tab="properties"]')?.click();
    syncInspector();
  } else {
    $('empty-inspector').classList.remove('hidden');
    $('object-inspector').classList.add('hidden');
  }
  renderObjectList();
}

// The screen selector must redraw the active All-in-One texture and persist the selected mode.
function applyPersonConfig(){
 if(!selected||!selected.userData.shirtMaterial)return;
 const style=$('prop-person-style').value,color=$('prop-person-color').value;
 selected.userData.shirtMaterial.color.set(color);
 selected.userData.personConfig={shirtStyle:style,shirtColor:color};
 if(selected.userData.personBadge)selected.userData.personBadge.visible=style==='senati';
 markDirty();
}
$('prop-person-style')?.addEventListener('change',applyPersonConfig);
$('prop-person-color')?.addEventListener('input',applyPersonConfig);

$('prop-screen')?.addEventListener('change',e=>{
  if(!selected || selected.userData.catalogKey!=='aio' || !selected.userData.drawScreen)return;
  const mode=['windows11','senati','blank'].includes(e.target.value)?e.target.value:'windows11';
  selected.userData.drawScreen(mode);
  if(selected.userData.screenTexture)selected.userData.screenTexture.needsUpdate=true;
  selected.userData.screenMode=mode;
  markDirty();
  showToast(mode==='windows11'?'Pantalla Windows 11 aplicada.':mode==='senati'?'Pantalla SENATI aplicada.':'Pantalla neutra aplicada.');
});

function syncInspector() {
  if(!selected)return;
  $('prop-label').value=selected.userData.label;
  $('prop-x').value=selected.position.x.toFixed(2);
  $('prop-y').value=selected.position.y.toFixed(2);
  $('prop-z').value=selected.position.z.toFixed(2);
  const isDesk=selected.userData.catalogKey==='desk';
  const screenControl=$('prop-screen-wrap');if(screenControl)screenControl.classList.toggle('hidden',selected.userData.catalogKey!=='aio');
  const isPerson=['man','woman','man-senati','woman-senati','teacher','teacher-f'].includes(selected.userData.catalogKey);
  $('prop-person-wrap')?.classList.toggle('hidden',!isPerson);
  if(isPerson){const pc=selected.userData.personConfig||{};$('prop-person-color').value=pc.shirtColor||'#123f72';$('prop-person-style').value=pc.shirtStyle|| (selected.userData.catalogKey.endsWith('senati')?'senati':'custom');}
  if(selected.userData.catalogKey==='aio'&&$('prop-screen'))$('prop-screen').value=selected.userData.screenMode||'windows11';
  $('prop-sx').value=isDesk?'1.00':selected.scale.x.toFixed(2);
  $('prop-sy').value=isDesk?'1.00':selected.scale.y.toFixed(2);
  $('prop-sz').value=isDesk?'1.00':selected.scale.z.toFixed(2);
  ['prop-sx','prop-sy','prop-sz'].forEach(id=>$(id).disabled=isDesk);
}
function updateSceneBadges(){
  const people=placed.filter(o=>['man','woman','man-senati','woman-senati','teacher','teacher-f'].includes(o.userData.catalogKey)).length;
  const badge=$('scene-person-count');if(badge)badge.textContent=String(people);
  const title=$('scene-template-tag');if(title)title.textContent=$('scenario-name')?.value||'Aula SENATI (Default)';
  const dimension=$('stage-dimensions');if(dimension)dimension.textContent=`${room.width.toFixed(2)} × ${room.depth.toFixed(2)} m`;
}
function renderObjectList(){
  $('object-count').textContent=String(placed.length);
  const holder=$('placed-objects');holder.innerHTML='';
  if(!placed.length){holder.innerHTML='<span class="muted">Todavía no hay objetos.</span>';updateSceneBadges();return;}
  [...placed].reverse().forEach(obj=>{
    const item=catalog.find(c=>c.key===obj.userData.catalogKey);
    const row=document.createElement('button');row.className='placed-row'+(obj===selected?' active':'');
    row.innerHTML=`<span class="row-icon">${catalogArt(obj.userData.catalogKey)}</span><span class="row-label">${escapeHtml(obj.userData.label)}</span><span class="row-type">${item?.category||''}</span>`;
    row.addEventListener('click',()=>selectObject(obj));holder.appendChild(row);
  });
  updateSceneBadges();
}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function markDirty(){ $('save-status').textContent='Cambios sin guardar'; $('save-status').previousElementSibling.style.background='#e6b44c'; }
function showToast(message){const t=$('toast');t.textContent=message;t.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove('show'),2400);}
function setPlacement(key){activePlacementKey=key;activeTool='place';$('tool-select').classList.remove('active');$('tool-move').classList.remove('active');$('viewport-status').textContent=`Colocando: ${catalog.find(x=>x.key===key)?.label}.`;renderer.domElement.style.cursor='crosshair';}
function catalogArt(key){
  const people=['man','woman','man-senati','woman-senati','teacher','teacher-f'].includes(key);
  if(people){
    const female=key.startsWith('woman')||key==='teacher-f',teacher=key==='teacher'||key==='teacher-f',shirt=teacher?'#263b59':(key.endsWith('senati')?'#1555a0':(female?'#d76b89':'#379b8b'));
    const hair=female?'#5a342b':(teacher?'#282a30':'#252b32');
    return `<svg viewBox="0 0 100 78" aria-hidden="true"><defs><linearGradient id="p${key}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${shirt}"/><stop offset="1" stop-color="#102c50"/></linearGradient><linearGradient id="s${key}" x1="0" y1="0" x2="0.8" y2="1"><stop stop-color="#e8b995"/><stop offset="1" stop-color="#b97859"/></linearGradient></defs><ellipse cx="50" cy="72" rx="25" ry="4" fill="#7f91a8" opacity=".25"/><path d="M34 52 L42 52 L40 73 L31 73 Z M52 52 L61 52 L68 73 L58 73 Z" fill="#263449"/><path d="M29 42 Q30 32 41 31 L58 31 Q71 34 72 45 L69 58 Q50 64 30 57 Z" fill="url(#p${key})"/><path d="M31 42 Q25 42 23 55 L29 58 L37 48 M68 42 Q77 43 78 54 L71 58 L64 48" fill="${shirt}" stroke="#163b65" stroke-width="2"/><path d="M42 27 L58 27 L58 36 Q50 42 42 36 Z" fill="#d8a27f"/><ellipse cx="50" cy="22" rx="15" ry="17" fill="url(#s${key})"/><path d="M35 22 Q33 3 51 4 Q69 4 65 23 Q61 15 54 14 Q44 18 35 22Z" fill="${hair}"/>${female?`<path d="M37 18 Q31 30 36 42 L30 49 Q24 27 35 11 M63 18 Q70 30 65 42 L71 49 Q77 27 65 11" fill="${hair}"/>`:''}<circle cx="44" cy="23" r="1.4" fill="#263447"/><circle cx="56" cy="23" r="1.4" fill="#263447"/><path d="M46 31 Q50 34 54 31" fill="none" stroke="#965c50" stroke-width="1.2"/>${key.endsWith('senati')?`<text x="50" y="49" fill="#fff" font-size="5.5" font-weight="800" text-anchor="middle">SENATI</text>`:''}${teacher?`<path d="M43 33 L50 42 L57 33" fill="#fff"/>${female?'':`<path d="M49 38 L52 38 L53 54 L50 57 L47 54Z" fill="#c8464d"/>`}`:''}</svg>`;
  }
  const common=`<defs><linearGradient id="a${key}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#80b9fa"/><stop offset="1" stop-color="#1555a0"/></linearGradient><linearGradient id="g${key}" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#dff5ff"/><stop offset="1" stop-color="#6bb6e6"/></linearGradient></defs>`;
  const arts={
    desk:`<path d="M13 31 L52 15 L91 31 L50 47Z" fill="#2e80d8" stroke="#174b87" stroke-width="2"/><path d="M13 31 L50 47 L50 53 L13 37Z" fill="#174b87"/><path d="M50 47 L91 31 L91 37 L50 53Z" fill="#0d3d78"/><path d="M23 38 L23 70 M42 45 L42 72 M81 35 L81 67 M62 42 L62 69" stroke="#6a7a8d" stroke-width="3"/><rect x="40" y="28" width="20" height="8" rx="1" fill="#c7d2df"/>`,
    chair:`<path d="M32 18 Q32 12 39 12 H59 Q66 12 66 19 V45 H32Z" fill="#303d50"/><path d="M30 39 Q50 34 70 40 L69 49 Q50 55 31 48Z" fill="#1f2e43"/><path d="M50 49 V65 M50 65 L24 72 M50 65 L76 72 M50 65 L50 74" stroke="#718196" stroke-width="4" stroke-linecap="round"/><circle cx="24" cy="72" r="3" fill="#26364c"/><circle cx="76" cy="72" r="3" fill="#26364c"/>`,
    aio:`<rect x="23" y="7" width="54" height="42" rx="4" fill="#34475d"/><rect x="27" y="11" width="46" height="34" rx="2" fill="url(#a${key})"/><path d="M43 49 L57 49 L60 62 L40 62Z" fill="#8996a6"/><path d="M32 64 H68 Q72 64 72 67 V70 H28 V67 Q28 64 32 64Z" fill="#64748b"/><text x="50" y="30" font-size="7" fill="#fff" font-weight="800" text-anchor="middle">SENATI</text>`,
    keyboard:`<path d="M11 29 Q11 25 16 25 H84 Q89 25 89 29 V57 H11Z" fill="#35465b"/><path d="M17 31 H83 V52 H17Z" fill="#d7e0eb"/>${Array.from({length:4},(_,r)=>Array.from({length:12},(_,i)=>`<rect x="${20+i*5.1}" y="${34+r*4.2}" width="3.5" height="2.8" rx=".5" fill="#65778e"/>`).join('')).join('')}`,
    mouse:`<path d="M39 13 Q50 6 61 13 Q71 23 66 50 Q62 67 50 69 Q38 67 34 50 Q29 23 39 13Z" fill="#29394e"/><path d="M50 11 V34" stroke="#91a4ba" stroke-width="2"/><path d="M50 33 V42" stroke="#91a4ba" stroke-width="1.5"/>`,
    wall:`<path d="M12 12 H88 V67 H12Z" fill="#e8edf4" stroke="#96a7ba" stroke-width="3"/><path d="M12 49 H88 V67 H12Z" fill="#1556a7"/><path d="M12 44 H88" stroke="#fff" stroke-width="2"/>`,
    door:`<rect x="26" y="6" width="48" height="66" rx="2" fill="#52677f"/><rect x="31" y="11" width="38" height="56" fill="url(#g${key})" opacity=".8"/><path d="M50 11 V67" stroke="#fff" stroke-width="2" opacity=".7"/><circle cx="63" cy="40" r="2" fill="#e5edf4"/>`,
    window:`<rect x="8" y="16" width="84" height="49" rx="2" fill="#52677f"/><rect x="13" y="21" width="74" height="39" fill="url(#g${key})"/><path d="M50 21 V60 M13 40 H87" stroke="#fff" stroke-width="3" opacity=".9"/><path d="M13 60 L87 21" stroke="#a8d8f1" stroke-width="1.2"/>`,
    whiteboard:`<rect x="9" y="14" width="82" height="47" rx="2" fill="#5e6e82"/><rect x="14" y="18" width="72" height="39" fill="#fff"/><path d="M17 66 H83" stroke="#71839a" stroke-width="4"/><path d="M24 30 H72 M24 37 H62" stroke="#9caec0" stroke-width="1.5"/>`,
    fluorescent:`<rect x="10" y="23" width="80" height="32" rx="7" fill="#65778d"/><rect x="16" y="28" width="68" height="22" rx="5" fill="#fff6d8"/><path d="M20 34 H80" stroke="#fff" stroke-width="3"/>`,
    fan:`<circle cx="50" cy="40" r="8" fill="#56697f"/>${[0,120,240].map(a=>`<path d="M50 40 Q${50+Math.cos(a*Math.PI/180)*14} ${40+Math.sin(a*Math.PI/180)*14} ${50+Math.cos(a*Math.PI/180)*33} ${40+Math.sin(a*Math.PI/180)*33} Q${50+Math.cos((a+30)*Math.PI/180)*12} ${40+Math.sin((a+30)*Math.PI/180)*12} 50 40Z" fill="#c9d5e2" stroke="#697c91"/>`).join('')}`,
    projector:`<rect x="19" y="22" width="62" height="36" rx="7" fill="#e8edf4" stroke="#7e8fa4" stroke-width="2"/><circle cx="73" cy="40" r="8" fill="#4d627d"/><circle cx="73" cy="40" r="4" fill="#8ccbed"/>`,
    plant:`<path d="M50 38 Q20 20 24 7 Q44 10 50 36 Q53 11 76 6 Q79 27 53 40 Q77 33 87 48 Q67 60 51 43 Q34 64 13 50 Q27 32 50 38Z" fill="#459a67"/><path d="M33 49 H67 L62 72 H38Z" fill="#a86f4d"/>`,
    'safety-exit':`<rect x="9" y="17" width="82" height="44" rx="4" fill="#087a45" stroke="#fff" stroke-width="3"/><text x="50" y="45" fill="#fff" font-size="20" font-weight="900" text-anchor="middle">SALIDA</text>`,
    'safety-rules':`<rect x="13" y="8" width="74" height="62" rx="3" fill="#fff" stroke="#c62828" stroke-width="3"/><path d="M24 27 H76 M24 39 H76 M24 51 H68" stroke="#52677f" stroke-width="3"/><text x="50" y="20" fill="#17324d" font-size="8" font-weight="800" text-anchor="middle">REGLAS</text>`,
    'fire-extinguisher':`<rect x="35" y="16" width="30" height="49" rx="8" fill="#c62828"/><path d="M48 16 V9 H62 M61 9 Q75 13 68 25" stroke="#334155" stroke-width="4" fill="none"/><rect x="39" y="34" width="22" height="13" fill="#fff"/><text x="50" y="43" fill="#c62828" font-size="6" font-weight="800" text-anchor="middle">ABC</text>`,
    'safety-first-aid':`<rect x="12" y="12" width="76" height="54" rx="4" fill="#087a45" stroke="#fff" stroke-width="3"/><path d="M50 22 V56 M33 39 H67" stroke="#fff" stroke-width="8"/>`,
    'safety-electrical':`<path d="M50 6 L94 68 H6Z" fill="#ffd22e" stroke="#283443" stroke-width="3"/><path d="M55 22 L38 43 H51 L45 58 L65 35 H52Z" fill="#283443"/>`,
    'safety-safe-zone':`<rect x="12" y="12" width="76" height="54" rx="4" fill="#087a45" stroke="#fff" stroke-width="3"/><circle cx="50" cy="31" r="8" fill="#fff"/><path d="M50 40 V57 M36 48 H64" stroke="#fff" stroke-width="5"/>`,
    'safety-evacuation':`<rect x="8" y="17" width="84" height="44" rx="4" fill="#087a45" stroke="#fff" stroke-width="3"/><path d="M20 39 H76 M62 25 L76 39 L62 53" stroke="#fff" stroke-width="7" fill="none"/>`
  };
  return `<svg viewBox="0 0 100 78" aria-hidden="true">${common}<ellipse cx="50" cy="72" rx="35" ry="3.5" fill="#8092a8" opacity=".2"/>${arts[key]||arts.wall}</svg>`;
}
function interfaceIcon(name){
  const paths={
    people:'<circle cx="9" cy="8" r="3"/><path d="M3 20v-1.2A4.8 4.8 0 0 1 7.8 14h2.4a4.8 4.8 0 0 1 4.8 4.8V20M16 5.5a3 3 0 0 1 0 5.8M18 14.5a4.5 4.5 0 0 1 3 4.3V20"',
    furniture:'<rect x="4" y="9" width="16" height="5" rx="1.4"/><path d="M6 14v6m12-6v6M4 9V6h16v3"',
    devices:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"',
    building:'<path d="M3 21h18M5 21V5l7-3 7 3v16M9 9h2m2 0h2m-6 4h2m2 0h2m-5 8v-4h4v4"',
    'shield-check':'<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>',
    front:'<rect x="4" y="5" width="16" height="14" rx="2"/><path d="M8 9h8M8 13h8"',
    back:'<rect x="4" y="5" width="16" height="14" rx="2"/><path d="M8 15h8M8 11h8"',
    left:'<path d="M5 4h14v16H5zM5 12h14"',
    right:'<path d="M5 4h14v16H5zM5 12h14"',
    top:'<path d="M4 8l8-4 8 4-8 4-8-4zM4 8v8l8 4 8-4V8M12 12v8"',
    perspective:'<path d="M3 8l9-5 9 5-9 5-9-5zM3 8v8l9 5 9-5V8M12 13v8"'
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${paths[name]||paths.devices}</svg>`;
}
function renderLibrary(){
  const q=$('object-search').value.trim().toLowerCase();const holder=$('object-library');holder.innerHTML='';
  const groups=[
    {id:'personas',title:'Personas',icon:'people',keys:['man-senati','woman-senati','man','woman','teacher','teacher-f']},
    {id:'mobiliario',title:'Mobiliario',icon:'furniture',keys:['desk','chair']},
    {id:'computacion',title:'Equipos',icon:'devices',keys:['aio','keyboard','mouse']},
    {id:'entorno',title:'Mundo exterior',icon:'building',keys:['road','ground','sidewalk']},
    {id:'infraestructura',title:'Infraestructura',icon:'building',keys:['window','door','door-normal','wall','whiteboard','fluorescent','fan','projector','plant']},
    {id:'seguridad',title:'Seguridad',icon:'shield-check',keys:['safety-exit','safety-rules','fire-extinguisher','safety-first-aid','safety-electrical','safety-safe-zone','safety-evacuation']}
  ];
  groups.forEach((group,index)=>{
    const items=group.keys.map(k=>catalog.find(c=>c.key===k)).filter(Boolean).filter(item=>
      (!q||`${item.label} ${item.description}`.toLowerCase().includes(q)) &&
      (activeCategory==='all'||item.category===activeCategory)
    );
    if(!items.length)return;
    const section=document.createElement('section');section.className='library-group'+((index===0||group.id==='entorno'||q)?' expanded':'');
    const head=document.createElement('button');head.className='library-group-head';
    head.innerHTML=`<span class="group-emoji">${interfaceIcon(group.icon)}</span><span class="group-title">${group.title}</span><span class="group-count">${items.length}</span><span class="group-chevron">⌄</span>`;
    head.addEventListener('click',()=>section.classList.toggle('expanded'));
    const body=document.createElement('div');body.className='library-group-body';
    items.forEach(item=>{
      const button=document.createElement('button');button.className='library-item';button.draggable=true;
      const thumb=libraryThumbs[item.key];
      button.innerHTML=`<span class="item-preview">${thumb?`<img src="${thumb}" alt="" loading="lazy">`:catalogArt(item.key)}</span><span class="item-name">${item.label}</span>`;
      button.title=`${item.label} — ${item.description}`;
      button.addEventListener('click',()=>setPlacement(item.key));
      button.addEventListener('dragstart',e=>{e.dataTransfer.setData('text/object-key',item.key);e.dataTransfer.effectAllowed='copy';setPlacement(item.key);});
      body.appendChild(button);
    });
    section.append(head,body);holder.appendChild(section);
  });
}
function getRootObject(intersection) {
 let o=intersection.object;
 while(o && o!==objectGroup && !o.userData.editorObject)o=o.parent;
 return o?.userData.editorObject?o:null;
}
renderer.domElement.addEventListener('dragover',e=>{e.preventDefault();e.dataTransfer.dropEffect='copy';});
renderer.domElement.addEventListener('drop',e=>{
 e.preventDefault();
 if(walkMode)return;
 const key=e.dataTransfer.getData('text/object-key')||activePlacementKey;
 if(!key)return;
 const p=pointOnFloor(e);if(!p)return;
 addObject(key,clampToRoom(p));
 activePlacementKey=null;activeTool='select';renderer.domElement.style.cursor='grab';
});
renderer.domElement.addEventListener('pointerdown',e=>{
 if(e.button!==0)return;
 const p=pointOnFloor(e);setPointer(e);
 if(activePlacementKey){
   if(p){addObject(activePlacementKey,clampToRoom(p));activePlacementKey=null;activeTool='select';renderer.domElement.style.cursor='grab';}
   return;
 }
 const hits=raycaster.intersectObjects(placed,true);
 const root=hits.length?getRootObject(hits[0]):null;
 if(walkMode)return; // Durante el recorrido no se seleccionan ni arrastran objetos.
 if(root){
   selectObject(root);
   pointerDown={x:e.clientX,y:e.clientY};
   isDraggingObject=true;
   controls.enabled=false;
   renderer.domElement.setPointerCapture(e.pointerId);
 }else{
   selectObject(null);
 }
});
renderer.domElement.addEventListener('pointermove',e=>{
 if(walkMode||!isDraggingObject||!selected)return;
 const p=pointOnFloor(e);if(!p)return;
 const previous=selected.position.clone();selected.position.copy(clampToRoom(p));moveLinkedObjects(selected,selected.position.clone().sub(previous));
 if(selectionHelper)selectionHelper.update();
 syncInspector();markDirty();
});
function endDrag(){if(isDraggingObject){isDraggingObject=false;controls.enabled=true;}}
renderer.domElement.addEventListener('pointerup',endDrag);
renderer.domElement.addEventListener('pointercancel',endDrag);
function deleteSelected(){
 if(!selected)return;
 const deleting=[selected];
 const ids=new Set([selected.userData.objectId]);
 let changed=true;
 while(changed){changed=false;placed.forEach(o=>{if(o.userData.accessoryOf&&ids.has(o.userData.accessoryOf)&&!ids.has(o.userData.objectId)){ids.add(o.userData.objectId);deleting.push(o);changed=true;}});}
 deleting.forEach(obj=>{
   const idx=placed.indexOf(obj);if(idx>=0)placed.splice(idx,1);
   objectGroup.remove(obj);
 });
 selectObject(null);renderObjectList();markDirty();
}
function duplicateSelected(){
 if(!selected)return;
 const key=selected.userData.catalogKey;
 const copy=addObject(key,selected.position.clone().add(new THREE.Vector3(.5,0,.5)),{
  rotationY:selected.rotation.y,scaleX:selected.scale.x,scaleY:selected.scale.y,scaleZ:selected.scale.z,
  label:`${selected.userData.label} copia`
 });
 return copy;
}
function applyInspector(){
 if(!selected)return;
 selected.userData.label=$('prop-label').value.trim()||'Objeto';
 const previousPosition=selected.position.clone();
 selected.position.set(
  Number($('prop-x').value)||0,Number($('prop-y').value)||0,Number($('prop-z').value)||0
 );
 moveLinkedObjects(selected,selected.position.clone().sub(previousPosition));
 if(selected.userData.catalogKey==='desk'){
  selected.scale.set(1,1,1);
  $('prop-sx').value='1.00';$('prop-sy').value='1.00';$('prop-sz').value='1.00';
 }else{
  selected.scale.set(
   Math.max(.1,Number($('prop-sx').value)||1),Math.max(.1,Number($('prop-sy').value)||1),Math.max(.1,Number($('prop-sz').value)||1)
  );
 }
 if(selectionHelper)selectionHelper.update();
 syncInspector();renderObjectList();markDirty();
}
['prop-label','prop-x','prop-y','prop-z','prop-sx','prop-sy','prop-sz'].forEach(id=>{
 $(id).addEventListener('change',applyInspector);
});
$('duplicate-object').addEventListener('click',duplicateSelected);
$('delete-object').addEventListener('click',deleteSelected);
document.querySelectorAll('[data-rotate]').forEach(btn=>btn.addEventListener('click',()=>{
 if(!selected)return;
 const angle=THREE.MathUtils.degToRad(Number(btn.dataset.rotate));
 selected.rotation.y+=angle;rotateLinkedObjects(selected,angle);
 if(selectionHelper)selectionHelper.update();markDirty();
}));
$('object-search').addEventListener('input',renderLibrary);
document.querySelectorAll('.category-tab').forEach(btn=>btn.addEventListener('click',()=>{
 document.querySelectorAll('.category-tab').forEach(b=>b.classList.remove('active'));
 btn.classList.add('active');activeCategory=btn.dataset.category;renderLibrary();
}));
$('tool-select').addEventListener('click',()=>{activePlacementKey=null;activeTool='select';renderer.domElement.style.cursor='grab';$('viewport-status').textContent='Selecciona y arrastra los objetos para moverlos.';});
$('tool-move').addEventListener('click',()=>{activePlacementKey=null;activeTool='move';renderer.domElement.style.cursor='move';$('viewport-status').textContent='Selecciona un objeto y arrástralo para moverlo.';});
$('tool-grid').addEventListener('click',()=>{gridVisible=!gridVisible;gridHelper.visible=gridVisible;$('tool-grid').classList.toggle('active',gridVisible);$('opt-grid').checked=gridVisible;});
$('tool-roof').addEventListener('click',()=>{roofVisible=!roofVisible;roofMesh.visible=roofVisible;$('tool-roof').classList.toggle('active',roofVisible);$('opt-roof').checked=roofVisible;});
$('tool-top').addEventListener('click',()=>setQuickView('perspective'));
function setQuickView(view){
  const w=room.width,d=room.depth,h=room.height,span=Math.max(w,d),target=new THREE.Vector3(0,1.25,0);let pos;
  if(view==='front') {pos=new THREE.Vector3(0,Math.max(7,h+span*.34),span*1.25);target.set(0,1.1,0);}
  else if(view==='back') {pos=new THREE.Vector3(0,Math.max(7,h+span*.34),-span*1.25);target.set(0,1.1,0);}
  else if(view==='left') {pos=new THREE.Vector3(-span*1.30,Math.max(7,h+span*.34),0);target.set(0,1.1,0);}
  else if(view==='right') {pos=new THREE.Vector3(span*1.30,Math.max(7,h+span*.34),0);target.set(0,1.1,0);}
  else if(view==='top') {pos=new THREE.Vector3(0,span*1.35,.01);target.set(0,0,0);}
  else {positionCamera();pos=null;}
  if(pos){camera.position.copy(pos);controls.target.copy(target);controls.update();}
  document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
}
document.querySelectorAll('[data-view]').forEach(btn=>btn.addEventListener('click',()=>setQuickView(btn.dataset.view)));
document.querySelectorAll('[data-left-tab]').forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelectorAll('[data-left-tab]').forEach(b=>b.classList.toggle('active',b===btn));
  document.querySelectorAll('.left-tab-content').forEach(p=>p.classList.toggle('active',p.id===`left-tab-${btn.dataset.leftTab}`));
}));
$('tool-rotate').addEventListener('click',()=>{if(!selected){showToast('Selecciona un objeto primero.');return;}const angle=Math.PI/4;selected.rotation.y+=angle;rotateLinkedObjects(selected,angle);if(selectionHelper)selectionHelper.update();markDirty();});
$('tool-duplicate').addEventListener('click',()=>selected?duplicateSelected():showToast('Selecciona un objeto primero.'));
$('tool-delete').addEventListener('click',()=>selected?deleteSelected():showToast('Selecciona un objeto primero.'));
$('opt-grid').addEventListener('change',e=>{gridVisible=e.target.checked;if(gridHelper)gridHelper.visible=gridVisible;$('tool-grid').classList.toggle('active',gridVisible);});
$('opt-roof').addEventListener('change',e=>{roofVisible=e.target.checked;if(roofMesh)roofMesh.visible=roofVisible;$('tool-roof').classList.toggle('active',roofVisible);});
$('climate-mode').addEventListener('change',e=>{applyClimate(e.target.value);markDirty();});
$('opt-shadows').addEventListener('change',e=>{renderer.shadowMap.enabled=e.target.checked;sun.castShadow=e.target.checked;markDirty();});
$('opt-realistic').addEventListener('change',e=>{renderer.toneMapping=e.target.checked?THREE.ACESFilmicToneMapping:THREE.LinearToneMapping;renderer.toneMappingExposure=e.target.checked?1.04:1.0;markDirty();});
$('scenario-name').addEventListener('input',updateSceneBadges);

$('apply-dimensions').addEventListener('click',()=>{
 const w=Number($('room-width').value),d=Number($('room-depth').value),h=Number($('room-height').value);
 if(!Number.isFinite(w)||!Number.isFinite(d)||!Number.isFinite(h)||w<3||d<3||h<2.2||w>100||d>100||h>20){showToast('Revisa las dimensiones ingresadas.');return;}
 const oldHeight=room.height;
 if(['two-floor','senati-tower'].includes(appearance.buildingPlan)&&Math.abs(h-oldHeight)>.0001){placed.forEach(o=>{if(o.position.y>=oldHeight*.5)o.position.y+=h-oldHeight;});}
 room={width:w,depth:d,height:h};getFloors();makeRoom();
 // Keep objects on their level while clamping the horizontal footprint.
 placed.forEach(o=>{const idx=nearestFloorIndex(o.position.y);o.position.x=THREE.MathUtils.clamp(o.position.x,-room.width/2+.25,room.width/2-.25);o.position.z=THREE.MathUtils.clamp(o.position.z,-room.depth/2+.25,room.depth/2-.25);o.position.y=floorElevation(idx);});applyFloorVisibility();
 showToast(`Escenario actualizado: ${w} × ${d} m`);markDirty();
});
$('new-scene').addEventListener('click',()=>{
 if(placed.length&&!confirm('¿Crear un escenario nuevo? Se perderán los cambios no guardados.'))return;
 placed.forEach(o=>objectGroup.remove(o));placed=[];selectObject(null);currentScenarioId=null;
 $('scenario-name').value='Escenario nuevo';room={width:20,depth:12,height:3.35};
 appearance={floorType:'tile',floorColor:'#f2f4f7',wallColor:'#f1f3f6',deskColor:'#1559a8',chairColor:'#202a38',climate:'day',buildingPlan:'single-floor'};
 activeFloorIndex=0;syncFloorControls();$('construction-floor').value='all';syncAppearanceInputs();
 $('room-width').value=20;$('room-depth').value=12;$('room-height').value=3.35;makeRoom();renderObjectList();markDirty();
});
$('classroom-template').addEventListener('click',()=>{
 document.querySelectorAll('.scenario-card').forEach(card=>card.classList.toggle('selected',card.id==='classroom-template'));
 if(placed.length&&!confirm('La plantilla reemplazará los objetos actuales. ¿Continuar?'))return;
 placed.forEach(o=>objectGroup.remove(o));placed=[];selectObject(null);
 // Aula amplia 20 x 12 m: recupera la distribución anterior de cuatro columnas y seis filas.
 room={width:20,depth:12,height:3.35};appearance={floorType:'tile',floorColor:'#f2f4f7',wallColor:'#f1f3f6',deskColor:'#1559a8',chairColor:'#202a38',climate:'day',buildingPlan:'single-floor'};activeFloorIndex=0;
 roofVisible=false;gridVisible=true;$('opt-roof').checked=false;$('opt-grid').checked=true;
 $('scenario-name').value='Aula SENATI (Default)';$('room-width').value=20;$('room-depth').value=12;$('room-height').value=3.35;
 $('auto-station').checked=true;$('auto-seat').checked=true;syncAppearanceInputs();makeRoom();
 // Ventanales con vidrio transparente en el lateral izquierdo y puerta de vidrio en el lateral derecho.
 [-3.6,0,3.6].forEach(z=>addObject('window',new THREE.Vector3(-room.width/2+.055,0,z),{rotationY:Math.PI/2,silent:true}));
 const doorZ=room.depth*.36;addObject('door',new THREE.Vector3(room.width/2-.055,0,doorZ),{rotationY:Math.PI/2,silent:true});
 // Señal de salida sobre la puerta y panel de reglas junto al acceso, orientados hacia el interior.
 addObject('safety-exit',new THREE.Vector3(room.width/2-.10,.88,doorZ-.08),{rotationY:-Math.PI/2,silent:true});
 addObject('safety-rules',new THREE.Vector3(room.width/2-.10,0,doorZ-1.25),{rotationY:-Math.PI/2,silent:true});
 // Equipo y señalización complementaria de emergencia, sin invadir el ancho libre de la puerta.
 addObject('fire-extinguisher',new THREE.Vector3(room.width/2-1.05,0,doorZ-2.05),{rotationY:-Math.PI/2,silent:true});
 addObject('safety-electrical',new THREE.Vector3(room.width/2-.10,0,-1.65),{rotationY:-Math.PI/2,silent:true});
 addObject('safety-safe-zone',new THREE.Vector3(-room.width/2+.10,0,room.depth/2-1.0),{rotationY:Math.PI/2,silent:true});
 // Pizarra y profesor al frente; los alumnos quedan orientados hacia ellos.
 addObject('teacher',new THREE.Vector3(0,0,-4.95),{rotationY:0,silent:true});
 addObject('whiteboard',new THREE.Vector3(0,0,-5.78),{rotationY:0,scaleX:1.45,scaleY:1.05,silent:true});
 // 24 estaciones: cuatro columnas simétricas por seis filas. Escritorios de 158 x 72 cm.
 const deskXs=[-6.6,-2.2,2.2,6.6];
 const deskRows=[-3.9,-2.2,-.5,1.2,2.9,4.6];
 deskRows.forEach((z,row)=>deskXs.forEach((x,col)=>{
   addObject('desk',new THREE.Vector3(x,0,z),{rotationY:0,silent:true});
   // La silla está al frente (+Z) y gira para que el alumno mire hacia el monitor (-Z).
   addObject('chair',new THREE.Vector3(x,0,z+.94),{rotationY:Math.PI,silent:true});
 }));
 // Luminarias paralelas al eje ancho del aula, distribuidas sobre las filas de escritorios.
 for(const x of [-6,-2,2,6])for(const z of [-3.2,0,3.2])addObject('fluorescent',new THREE.Vector3(x,0,z),{rotationY:0,silent:true});
 for(const x of [-7,-2,2,7])addObject('fan',new THREE.Vector3(x,0,-.1),{silent:true});
 addObject('projector',new THREE.Vector3(0,0,-1.2),{silent:true});
 selectObject(null);renderLibrary();renderObjectList();applyFloorVisibility();markDirty();
 $('scene-template-tag').textContent='Aula SENATI (Default)';$('viewport-status').textContent='20 × 12 m';
 showToast('Aula SENATI creada: 24 puestos, 24 estudiantes, profesor y 24 estaciones informáticas.');
});

$('building-template').addEventListener('click',()=>{
 document.querySelectorAll('.scenario-card').forEach(card=>card.classList.toggle('selected',card.id==='building-template'));
 if(placed.length&&!confirm('La plantilla reemplazará los objetos actuales. ¿Continuar?'))return;
 placed.forEach(o=>objectGroup.remove(o));placed=[];selectObject(null);currentScenarioId=null;
 room={width:22,depth:16,height:3.4};
 appearance={floorType:'tile',floorColor:'#e7ebf0',wallColor:'#e9edf2',deskColor:'#1559a8',chairColor:'#202a38',climate:'day',buildingPlan:'two-floor',floorHeight:3.4,stairs:{x:5.25,topZ:-2.0,bottomZ:3.45,width:2.55},floors:[{id:1,name:'Piso 1',elevation:0,height:3.4,floorType:'tile',floorColor:'#e7ebf0'},{id:2,name:'Piso 2',elevation:3.4,height:3.4,floorType:'tile',floorColor:'#e7ebf0'}]};activeFloorIndex=0;
 roofVisible=false;gridVisible=false;$('opt-roof').checked=false;$('opt-grid').checked=false;
 $('scenario-name').value='Edificio de 2 pisos (Default 2)';$('room-width').value=22;$('room-depth').value=16;$('room-height').value=3.4;
 $('auto-station').checked=false;$('auto-seat').checked=false;syncFloorControls();$('construction-floor').value='all';syncAppearanceInputs();makeRoom();
 const doorZ=room.depth*.36;
 addObject('door',new THREE.Vector3(room.width/2-.055,0,doorZ),{rotationY:Math.PI/2,silent:true});
 addObject('safety-exit',new THREE.Vector3(room.width/2-.10,.88,doorZ-.05),{rotationY:-Math.PI/2,silent:true});
 addObject('fire-extinguisher',new THREE.Vector3(room.width/2-1.15,0,doorZ-1.45),{rotationY:-Math.PI/2,silent:true});
 addObject('safety-evacuation',new THREE.Vector3(7.6,1.9,4.7),{rotationY:Math.PI/2,silent:true});
 // Ocho participantes y estaciones en el segundo nivel, fuera del hueco de escalera.
 const upperY=room.height;
 const xs=[-7.4,-4.2,-1.0,2.0];
 xs.forEach((x,i)=>{
   addObject('desk',new THREE.Vector3(x,upperY,-6.15),{silent:true});
   addObject(i%2?'woman-senati':'man-senati',new THREE.Vector3(x,upperY,-4.95),{silent:true});
   addObject('desk',new THREE.Vector3(x,upperY,-3.65),{silent:true});
   addObject(i%2?'man-senati':'woman-senati',new THREE.Vector3(x,upperY,-2.95),{silent:true});
 });
 // Señales de orientación en la llegada a escalera y la salida del primer nivel.
 addObject('safety-exit',new THREE.Vector3(5.25,upperY+1.0,-2.55),{rotationY:Math.PI,silent:true});
 selectObject(null);renderLibrary();renderObjectList();applyFloorVisibility();markDirty();
 $('scene-template-tag').textContent='Edificio 2 pisos (Default 2)';$('viewport-status').textContent='22 × 16 m · 2 niveles';
 showToast('Default 2 creado: 2 pisos, escalera, pasadizo y 8 participantes en el segundo nivel. Guarda el escenario para simularlo.');
});

$('senati-tower-template').addEventListener('click',()=>{
 document.querySelectorAll('.scenario-card').forEach(card=>card.classList.toggle('selected',card.id==='senati-tower-template'));
 if(placed.length&&!confirm('La plantilla SENATI Torre reemplazará los objetos actuales. ¿Continuar?'))return;
 placed.forEach(o=>objectGroup.remove(o));placed=[];selectObject(null);currentScenarioId=null;
 room={width:TOWER_LAYOUT.width,depth:TOWER_LAYOUT.depth,height:4.45};
 const names=['Sótano 2','Sótano 1','Primer piso',...Array.from({length:10},(_,i)=>`Piso ${i+2}`)];
 const elevations=[-6.7,-3.35,0,...Array.from({length:10},(_,i)=>(i+1)*4.45)];
 appearance={floorType:'concrete',floorColor:'#dfe5e9',wallColor:'#d3d9df',deskColor:'#1559a8',chairColor:'#202a38',climate:'day',buildingPlan:'senati-tower',floorHeight:4.45,towerModel:{blocks:3,stories:[10,11,10],bridges:[3,6,9],basements:2,structuralSystem:'reinforced-concrete-shear-walls',curtainWall:true,elevators:6,layout:{...TOWER_LAYOUT}},floors:names.map((name,i)=>({id:i+1,name,elevation:elevations[i],height:i<2?3.35:4.45,floorType:'concrete',floorColor:'#dfe5e9'}))};
 activeFloorIndex=2;roofVisible=false;gridVisible=true;$('opt-roof').checked=false;$('opt-grid').checked=true;
 $('scenario-name').value='SENATI Torre 1 · Modelo conceptual';
 $('room-width').value=TOWER_LAYOUT.width;$('room-depth').value=TOWER_LAYOUT.depth;$('room-height').value=4.45;
 $('auto-station').checked=false;$('auto-seat').checked=false;
 syncFloorControls();$('construction-floor').value='all';$('floor-edit-scope').value='global';syncAppearanceInputs();makeRoom();
 $('construction-floor').value='all';applyFloorVisibility();
 selectObject(null);renderLibrary();renderObjectList();markDirty();
 $('scene-template-tag').textContent='SENATI Torre 1 · Modelo conceptual';$('viewport-status').textContent=`Campus ${TOWER_LAYOUT.width} × ${TOWER_LAYOUT.depth} m · 3 bloques · 2 sótanos · 11 pisos`;
 showToast('SENATI Torre creada. Modelo exterior basado en referencias públicas; distribuciones interiores editables y aproximadas.');
});

$('blank-template').addEventListener('click',()=>$('new-scene').click());

let savedOrbitView=null;
let walkVisibilitySnapshot=null,walkArchitectureVisibilitySnapshot=null;
function ensureWalkAvatar(){
 if(walkAvatar)return walkAvatar;
 // Reutiliza el mismo modelo humano de alta calidad que usa la biblioteca.
 walkAvatar=createModel('man-senati',false);
 walkAvatar.name='WalkAvatar';
 scene.add(walkAvatar);walkAvatar.visible=false;return walkAvatar;
}
function animateHumanoid(model,phase,moving=true){
 const rig=model?.userData?.rig;
 if(!rig||rig.seated)return;
 const swing=moving?Math.sin(phase):0;
 if(rig.leftArm)rig.leftArm.rotation.x=-swing*.48;
 if(rig.rightArm)rig.rightArm.rotation.x=swing*.48;
 if(rig.leftLeg)rig.leftLeg.rotation.x=swing*.52;
 if(rig.rightLeg)rig.rightLeg.rotation.x=-swing*.52;
 if(rig.leftKnee)rig.leftKnee.rotation.x=moving?Math.max(0,Math.sin(phase+Math.PI))*.52:0;
 if(rig.rightKnee)rig.rightKnee.rotation.x=moving?Math.max(0,Math.sin(phase))*.52:0;
}
function exitWalkMode(){
 if(walkControls.isLocked){walkControls.unlock();return;}
 finishWalkMode();
}
function finishWalkMode(){
 if(!walkMode)return;
 document.body.classList.remove('walk-mode');
 $('walk-exit-button')?.classList.add('hidden');
 walkMode=false;controls.enabled=true;walkElevatorPanelOpen=false;walkElevatorNearby=null;activeElevatorRide=null;walkTowerStairState=null;$('walk-elevator-panel')?.classList.add('hidden');$('walk-elevator-prompt')?.classList.add('hidden');
 $('tool-walk').classList.remove('active');$('tool-walk-third').classList.remove('active');
 $('walk-hud').classList.add('hidden');$('walk-crosshair').classList.add('hidden');
 $('viewport-help').classList.remove('hidden');$('viewport-status').textContent='Modo construcción';
 if(walkAvatar)walkAvatar.visible=false;
 if(savedOrbitView){camera.position.copy(savedOrbitView.position);controls.target.copy(savedOrbitView.target);controls.update();savedOrbitView=null;}
 if(walkVisibilitySnapshot){placed.forEach((o,i)=>o.visible=walkVisibilitySnapshot[i]??true);walkVisibilitySnapshot=null;}
 if(walkArchitectureVisibilitySnapshot){walkArchitectureVisibilitySnapshot.forEach(({child,visible})=>{if(child.parent===roomGroup)child.visible=visible;});walkArchitectureVisibilitySnapshot=null;}
 Object.keys(walkKeys).forEach(k=>walkKeys[k]=false);
}
function enterWalkMode(perspective='first'){
 if(walkMode){exitWalkMode();return;}
 savedOrbitView={position:camera.position.clone(),target:controls.target.clone()};
 walkMode=true;walkPerspective=perspective;controls.enabled=false;walkFloorIndex=appearance.buildingPlan==='senati-tower'?2:0;walkOnStairs=false;walkTowerStairState=null;activeElevatorRide=null;walkElevatorPanelOpen=false;walkMotionPhase=0;
 walkVisibilitySnapshot=placed.map(o=>o.visible);placed.forEach(o=>o.visible=true);
 walkArchitectureVisibilitySnapshot=roomGroup.children.map(child=>({child,visible:child.visible}));
 roomGroup.children.forEach(child=>{child.visible=child!==gridHelper;});
 if(appearance.buildingPlan==='two-floor'&&getFloors().length>1){
   const stair=getStairSpec();
   camera.position.set(stair.x,1.65,Math.min(room.depth/2-.6,stair.bottomZ+2.2));
   camera.rotation.set(0,0,0); // Mirar hacia el arranque de la escalera (-Z).
 }else if(appearance.buildingPlan==='senati-tower'){
   camera.position.set(0,1.65,10.0);
   camera.rotation.set(0,0,0);
 }else{
   camera.position.set(room.width/2-1.2,1.65,-room.depth/2+1.0);
   camera.rotation.set(0,Math.PI,0);
 }
 walkActorPosition.copy(camera.position);
 if(perspective==='third'){
   ensureWalkAvatar().visible=true;
   const yaw=camera.rotation.y;
   const introOffset=appearance.buildingPlan==='two-floor'&&getFloors().length>1?1.4:2.8;
   walkActorPosition.x=THREE.MathUtils.clamp(walkActorPosition.x-Math.sin(yaw)*introOffset,-room.width/2+.8,room.width/2-.8);
   walkActorPosition.z=THREE.MathUtils.clamp(walkActorPosition.z-Math.cos(yaw)*introOffset,-room.depth/2+.8,room.depth/2-.8);
   camera.rotation.set(-.25,yaw,0,'YXZ');
   camera.position.set(walkActorPosition.x+Math.sin(yaw)*3.8,walkActorPosition.y+.85,walkActorPosition.z+Math.cos(yaw)*3.8);
   walkAvatar.position.set(walkActorPosition.x,walkActorPosition.y-1.65,walkActorPosition.z);
   walkAvatar.rotation.y=yaw+Math.PI;
 }
 $('tool-walk').classList.toggle('active',perspective==='first');
 $('tool-walk-third').classList.toggle('active',perspective==='third');
 $('walk-hud').querySelector('b').textContent=perspective==='first'?'RECORRIDO EN PRIMERA PERSONA':'RECORRIDO EN TERCERA PERSONA';
 $('walk-hud').querySelector('span').textContent=appearance.buildingPlan==='senati-tower'?'W A S D · Mouse para mirar · E usar ascensor · ESC salir':'W A S D o flechas para caminar · Mouse para mirar · ESC para salir';
 $('walk-hud').classList.remove('hidden');$('walk-crosshair').classList.toggle('hidden',perspective==='third');$('viewport-help').classList.add('hidden');
 $('viewport-status').textContent=perspective==='third'?'Modo recorrido: tercera persona · ESC para volver':'Modo recorrido: primera persona · ESC para volver';
 walkControls.lock();
}
walkControls.addEventListener('lock',()=>{
 document.body.classList.add('walk-mode');
 $('walk-exit-button')?.classList.remove('hidden');
 $('tool-walk').innerHTML='♙ 1.ª persona';$('tool-walk-third').innerHTML='◉ 3.ª persona';
});
walkControls.addEventListener('unlock',()=>{if(walkMode&&walkElevatorPanelOpen){document.body.classList.add('walk-mode');$('walk-exit-button')?.classList.remove('hidden');return;}finishWalkMode();});
document.addEventListener('pointerlockerror',()=>{if(walkMode){finishWalkMode();showToast('El navegador no permitió activar el control del recorrido. Haz clic nuevamente para intentarlo.');}});
$('walk-exit-button')?.addEventListener('click',exitWalkMode);
$('tool-walk').addEventListener('click',()=>enterWalkMode('first'));
$('tool-walk-third').addEventListener('click',()=>enterWalkMode('third'));
function updateWalkElevatorPanel(message='↑ / ↓ elegir piso · ENTER viajar · E cerrar'){
 const panel=$('walk-elevator-panel');if(!panel)return;
 const floors=getFloors();const elevator=walkElevatorNearby?.elevator;
 walkElevatorSelection=THREE.MathUtils.clamp(walkElevatorSelection,0,elevator?.maxFloorIndex??floors.length-1);
 panel.classList.toggle('hidden',!walkElevatorPanelOpen);
 if(!walkElevatorPanelOpen)return;
 $('walk-elevator-name').textContent=elevator?`ASCENSOR ${elevator.id}`:'ASCENSOR';
 if($('walk-elevator-current'))$('walk-elevator-current').textContent=getFloors()[walkFloorIndex]?.name||`Nivel ${walkFloorIndex+1}`;
 $('walk-elevator-destination').textContent=floors[walkElevatorSelection]?.name||`Nivel ${walkElevatorSelection+1}`;
 $('walk-elevator-status').textContent=message;
 const floorSelect=$('walk-elevator-floor');
 if(floorSelect){const max=elevator?.maxFloorIndex??floors.length-1;floorSelect.innerHTML='';for(let i=0;i<=max;i++){const option=document.createElement('option');option.value=String(i);option.textContent=floors[i]?.name||`Nivel ${i+1}`;floorSelect.appendChild(option);}floorSelect.value=String(walkElevatorSelection);}
}
function setElevatorDoors(elevator,floorIndex,amount){
 const door=elevator?.landingDoors?.find(d=>d.floorIndex===floorIndex);
 if(door){door.left.position.x=door.closedLeft-amount*.52;door.right.position.x=door.closedRight+amount*.52;if(door.collision)door.collision.openAmount=amount;}
 if(elevator?.cabinDoors){elevator.cabinDoors.left.position.x=elevator.cabinDoors.closedLeft-amount*.42;elevator.cabinDoors.right.position.x=elevator.cabinDoors.closedRight+amount*.42;}
}
$('walk-elevator-floor')?.addEventListener('change',e=>{walkElevatorSelection=Number(e.target.value)||0;updateWalkElevatorPanel();});
$('walk-elevator-go')?.addEventListener('click',startWalkElevatorRide);
$('walk-elevator-close')?.addEventListener('click',()=>{if(activeElevatorRide)return;walkElevatorPanelOpen=false;$('walk-elevator-panel')?.classList.add('hidden');walkControls.lock();});
function startWalkElevatorRide(){
 if(!walkElevatorNearby||!towerWorldState||activeElevatorRide)return;
 if(!walkControls.isLocked)walkControls.lock();
 const elevator=walkElevatorNearby.elevator,target=walkElevatorSelection,from=walkFloorIndex;
 if(target===from){walkElevatorPanelOpen=false;$('walk-elevator-panel')?.classList.add('hidden');if(!walkControls.isLocked)walkControls.lock();return;}
 const actor=walkPerspective==='third'?walkActorPosition:camera.position;
 actor.x=elevator.x;actor.z=elevator.entryZ;actor.y=floorElevation(from)+1.65;
 if(walkPerspective==='first')camera.position.copy(actor);
 const current=elevator.currentFloor??2;
 activeElevatorRide={elevator,from,to:target,phase:'call',phaseTime:0,startY:elevator.floorElevations[current],targetY:elevator.floorElevations[from],actorStartZ:elevator.z+.15,entryZ:elevator.entryZ};
 walkElevatorPanelOpen=true;updateWalkElevatorPanel('Llamando ascensor…');
}
function updateWalkElevatorRide(dt){
 if(!activeElevatorRide)return;
 const ride=activeElevatorRide;ride.phaseTime+=dt;
 const actor=walkPerspective==='third'?walkActorPosition:camera.position;
 const setCabinY=y=>{ride.elevator.cabin.position.y=y;};
 const setActor=(x,y,z)=>{
   actor.set(x,y+1.65,z);
   if(walkPerspective==='third'&&walkAvatar){walkAvatar.position.set(x,y,z);walkAvatar.rotation.y=camera.rotation.y+Math.PI;const yaw=camera.rotation.y;camera.position.set(x+Math.sin(yaw)*3.8,y+2.5,z+Math.cos(yaw)*3.8);camera.lookAt(x,y+1.0,z);}
   else camera.position.y=y+1.65;
 };
 const doors=(floor,amount)=>setElevatorDoors(ride.elevator,floor,amount);
 const ease=t=>t*t*(3-2*t);
 if(ride.phase==='call'){
   const duration=Math.max(.75,Math.abs(ride.targetY-ride.startY)/3.6);
   const t=THREE.MathUtils.clamp(ride.phaseTime/duration,0,1);setCabinY(THREE.MathUtils.lerp(ride.startY,ride.targetY,ease(t)));
   if(t>=1){ride.elevator.currentFloor=ride.from;ride.phase='open';ride.phaseTime=0;doors(ride.from,1);setActor(ride.elevator.x,ride.targetY,ride.entryZ);updateWalkElevatorPanel('Puertas abiertas. Ingresando a la cabina…');}
 }else if(ride.phase==='open'){
   setCabinY(ride.targetY);doors(ride.from,1);
   const t=THREE.MathUtils.clamp(ride.phaseTime/.65,0,1);setActor(ride.elevator.x,ride.targetY,THREE.MathUtils.lerp(ride.entryZ,ride.actorStartZ,ease(t)));
   if(t>=1){ride.phase='travel';ride.phaseTime=0;doors(ride.from,0);ride.startY=ride.targetY;ride.targetY=ride.elevator.floorElevations[ride.to];updateWalkElevatorPanel(`Viajando a ${getFloors()[ride.to]?.name||'destino'}…`);}
 }else if(ride.phase==='travel'){
   const duration=Math.max(1.4,Math.abs(ride.targetY-ride.startY)/3.7);
   const t=THREE.MathUtils.clamp(ride.phaseTime/duration,0,1);const y=THREE.MathUtils.lerp(ride.startY,ride.targetY,ease(t));setCabinY(y);setActor(ride.elevator.x,y,ride.actorStartZ);
   if(t>=1){walkFloorIndex=ride.to;walkOnStairs=false;walkTowerStairState=null;ride.elevator.currentFloor=ride.to;ride.phase='exit';ride.phaseTime=0;doors(ride.to,1);updateWalkElevatorPanel(`Llegaste a ${getFloors()[ride.to]?.name||'destino'}. Saliendo…`);}
 }else if(ride.phase==='exit'){
   setCabinY(ride.targetY);doors(ride.to,1);
   const t=THREE.MathUtils.clamp(ride.phaseTime/.7,0,1);setActor(ride.elevator.x,ride.targetY,THREE.MathUtils.lerp(ride.actorStartZ,ride.entryZ,ease(t)));
   if(t>=1){doors(ride.to,0);activeElevatorRide=null;walkElevatorPanelOpen=false;$('walk-elevator-panel')?.classList.add('hidden');walkElevatorNearby=findNearbyTowerElevator(actor,walkFloorIndex,towerWorldState?.elevators||[],4.2);}
 }
}


document.addEventListener('keydown',e=>{
 if(!walkMode)return;
 const k=e.key.toLowerCase();
 if(walkElevatorPanelOpen&&!walkControls.isLocked){
   if(k==='escape'||k==='e'){
     e.preventDefault();walkElevatorPanelOpen=false;$('walk-elevator-panel')?.classList.add('hidden');walkControls.lock();return;
   }
   if(k==='arrowup'||k==='w'){walkElevatorSelection=Math.min(walkElevatorNearby?.elevator?.maxFloorIndex??getFloors().length-1,walkElevatorSelection+1);updateWalkElevatorPanel();e.preventDefault();return;}
   if(k==='arrowdown'||k==='s'){walkElevatorSelection=Math.max(0,walkElevatorSelection-1);updateWalkElevatorPanel();e.preventDefault();return;}
   if(k==='enter'){startWalkElevatorRide();e.preventDefault();return;}
 }
 if(!walkControls.isLocked)return;
 if(k==='escape'){e.preventDefault();if(walkElevatorPanelOpen){walkElevatorPanelOpen=false;$('walk-elevator-panel')?.classList.add('hidden');walkControls.lock();}else exitWalkMode();return;}
 if(appearance.buildingPlan==='senati-tower'&&!activeElevatorRide){
   if(k==='e'){
     if(walkElevatorPanelOpen){walkElevatorPanelOpen=false;$('walk-elevator-panel')?.classList.add('hidden');return;}
     const actor=walkPerspective==='third'?walkActorPosition:camera.position;
     walkElevatorNearby=findNearbyTowerElevator(actor,walkFloorIndex,towerWorldState?.elevators||[],4.2);
     if(walkElevatorNearby){walkElevatorSelection=walkFloorIndex;walkElevatorPanelOpen=true;updateWalkElevatorPanel('Selecciona tu destino. Pulsa Viajar o usa ↑ / ↓ y ENTER. Durante el viaje no puedes salir de la cabina.');walkControls.unlock();e.preventDefault();return;}
   }
   if(walkElevatorPanelOpen){
     if(k==='arrowup'||k==='w'){walkElevatorSelection=Math.min(walkElevatorNearby?.elevator?.maxFloorIndex??getFloors().length-1,walkElevatorSelection+1);updateWalkElevatorPanel();e.preventDefault();return;}
     if(k==='arrowdown'||k==='s'){walkElevatorSelection=Math.max(0,walkElevatorSelection-1);updateWalkElevatorPanel();e.preventDefault();return;}
     if(k==='enter'){startWalkElevatorRide();e.preventDefault();return;}
   }
 }
 if(activeElevatorRide)return;
 if(k==='w'||k==='arrowup'){walkKeys.forward=true;e.preventDefault();}
 if(k==='s'||k==='arrowdown'){walkKeys.backward=true;e.preventDefault();}
 if(k==='a'||k==='arrowleft'){walkKeys.left=true;e.preventDefault();}
 if(k==='d'||k==='arrowright'){walkKeys.right=true;e.preventDefault();}
});
document.addEventListener('keyup',e=>{
 const k=e.key.toLowerCase();
 if(k==='w'||k==='arrowup')walkKeys.forward=false;
 if(k==='s'||k==='arrowdown')walkKeys.backward=false;
 if(k==='a'||k==='arrowleft')walkKeys.left=false;
 if(k==='d'||k==='arrowright')walkKeys.right=false;
});
document.addEventListener('keydown',e=>{
 if(walkMode){
  if(e.key==='Escape'){
   e.preventDefault();
   if(walkElevatorPanelOpen&&!activeElevatorRide){walkElevatorPanelOpen=false;$('walk-elevator-panel')?.classList.add('hidden');if(!walkControls.isLocked)walkControls.lock();}
   else exitWalkMode();
  }
  return;
 }
 if(['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName))return;
 if(e.key==='Delete'||e.key==='Backspace'){deleteSelected();}
 if(e.key.toLowerCase()==='r'&&selected){selected.rotation.y+=Math.PI/4;if(selectionHelper)selectionHelper.update();markDirty();}
});
// Save/load API integration: PHP PDO + MySQL.
async function api(action, data=null, query=''){
 const csrf=document.querySelector('meta[name="csrf-token"]')?.content||'';
 const options=data?{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(data)}:{};
 const response=await fetch(`./api/scenarios.php?action=${action}${query}`,options);
 const payload=await response.json();
 if(!response.ok||!payload.success)throw new Error(payload.message||'No se pudo completar la operación.');
 return payload;
}
function serializeScene(){
 return {
  name:$('scenario-name').value.trim()||'Escenario sin título',
  dimensions:room,
  appearance:{...appearance,roofVisible,gridVisible,shadowsEnabled:renderer.shadowMap.enabled,realisticLighting:$('opt-realistic').checked},
  objects:placed.map(o=>({
   id:o.userData.objectId,catalogKey:o.userData.catalogKey,label:o.userData.label,
   position:{x:o.position.x,y:o.position.y,z:o.position.z},
   rotation:{x:o.rotation.x,y:o.rotation.y,z:o.rotation.z},
   scale:{x:o.scale.x,y:o.scale.y,z:o.scale.z},
   config:{accessoryOf:o.userData.accessoryOf||null,seated:Boolean(o.userData.seated),screenMode:o.userData.screenMode||null,personConfig:o.userData.personConfig||null,floorId:o.userData.floorId||nearestFloorIndex(o.position.y)+1}
  }))
 };
}
async function refreshScenarioList(){
 try{
  const result=await api('list');
  const select=$('saved-scenes');select.innerHTML='<option value="">Selecciona para abrir automáticamente</option>';
  result.scenarios.forEach(s=>{const opt=document.createElement('option');opt.value=s.id;opt.textContent=`${s.name} · ${s.width_m}×${s.depth_m} m`;select.appendChild(opt);});
 }catch(e){console.warn(e);$('save-status').textContent='BD pendiente de configurar';}
}
$('save-scene').addEventListener('click',async()=>{
 try{
  const payload=serializeScene();payload.id=currentScenarioId;
  const result=await api('save',payload);
  currentScenarioId=result.id;$('save-status').textContent='Guardado en MySQL';$('save-status').previousElementSibling.style.background='#49c58c';
  await refreshScenarioList();$('saved-scenes').value=String(currentScenarioId);showToast('Escenario guardado correctamente.');
 }catch(e){showToast(e.message);}
});
async function loadSavedScenario(id){
 if(!id||loadingScenario)return;
 const overlay=$('scene-loading-overlay');
 const previousId=currentScenarioId;
 loadingScenario=true;document.body.classList.add('scene-loading');
 $('scene-loading-name').textContent=$('saved-scenes').selectedOptions[0]?.textContent||'Preparando el espacio 3D…';
 overlay.classList.add('visible');overlay.setAttribute('aria-hidden','false');
 document.querySelector('.app-shell').inert=true;
 overlay.focus();
 try{
  const result=await api('load',null,`&id=${encodeURIComponent(id)}`);
  const data=result.scenario;
  room={width:Number(data.width_m),depth:Number(data.depth_m),height:Number(data.height_m)};
  let savedVisualOptions={};
  if(data.appearance_json){
    try{savedVisualOptions=JSON.parse(data.appearance_json)||{};appearance={...appearance,...savedVisualOptions};}catch(e){console.warn('Apariencia guardada no válida',e);}
  } else if(data.appearance && typeof data.appearance==='object') {
    savedVisualOptions=data.appearance;appearance={...appearance,...savedVisualOptions};
  }
  if(appearance.buildingPlan==='senati-tower'){
    const savedLayout=appearance.towerModel?.layout||{};
    const legacyLayout=Number(savedLayout.width||112)<TOWER_LAYOUT.width||Number(savedLayout.blockWidth||23.5)<TOWER_LAYOUT.blockWidth;
    appearance.towerModel={...(appearance.towerModel||{}),layout:legacyLayout?{...TOWER_LAYOUT}:{...TOWER_LAYOUT,...savedLayout}};
    room.width=Number(appearance.towerModel.layout.width)||TOWER_LAYOUT.width;
    room.depth=Number(appearance.towerModel.layout.depth)||TOWER_LAYOUT.depth;
  }
  if(typeof savedVisualOptions.roofVisible==='boolean')roofVisible=savedVisualOptions.roofVisible;
  if(typeof savedVisualOptions.gridVisible==='boolean')gridVisible=savedVisualOptions.gridVisible;
  applyClimate(savedVisualOptions.climate||'day');
  $('opt-roof').checked=roofVisible;$('opt-grid').checked=gridVisible;
  if(typeof savedVisualOptions.shadowsEnabled==='boolean'){renderer.shadowMap.enabled=savedVisualOptions.shadowsEnabled;sun.castShadow=savedVisualOptions.shadowsEnabled;$('opt-shadows').checked=savedVisualOptions.shadowsEnabled;}
  if(typeof savedVisualOptions.realisticLighting==='boolean'){$('opt-realistic').checked=savedVisualOptions.realisticLighting;renderer.toneMapping=savedVisualOptions.realisticLighting?THREE.ACESFilmicToneMapping:THREE.LinearToneMapping;renderer.toneMappingExposure=savedVisualOptions.realisticLighting?1.04:1.0;}
  syncAppearanceInputs();
  activeFloorIndex=0;syncFloorControls();$('construction-floor').value='all';$('room-width').value=room.width;$('room-depth').value=room.depth;$('room-height').value=room.height;
  $('scenario-name').value=data.name;currentScenarioId=Number(data.id);
  makeRoom();placed.forEach(o=>objectGroup.remove(o));placed=[];selectObject(null);
  data.objects.forEach(o=>{
   let config={};try{config=JSON.parse(o.config_json||'{}')||{};}catch(e){config={};}
   const obj=addObject(o.catalog_key,new THREE.Vector3(Number(o.pos_x),Number(o.pos_y),Number(o.pos_z)),{
    id:o.object_uuid,label:o.label,rotationY:Number(o.rot_y),scaleX:Number(o.scale_x),scaleY:Number(o.scale_y),scaleZ:Number(o.scale_z),skipAccessories:true,
    accessoryOf:config.accessoryOf||null,seated:Boolean(config.seated),screenMode:config.screenMode||'windows11',personConfig:config.personConfig||{}
   });
   obj.userData.floorId=Number(config.floorId)||nearestFloorIndex(obj.position.y)+1;obj.userData.floorIndex=obj.userData.floorId-1;
   obj.rotation.x=Number(o.rot_x);obj.rotation.z=Number(o.rot_z);
  });
  const hasStations=placed.some(o=>o.userData.catalogKey==='aio'&&o.userData.accessoryOf);$('auto-station').checked=hasStations;
  const hasSeated=placed.some(o=>o.userData.seated);$('auto-seat').checked=hasSeated;
  placed.filter(o=>o.userData.catalogKey==='desk').forEach(d=>d.userData.stationEquipped=placed.some(o=>o.userData.catalogKey==='aio'&&o.userData.accessoryOf===d.userData.objectId));
  placed.filter(o=>o.userData.catalogKey==='chair').forEach(c=>c.userData.occupied=placed.some(o=>o.userData.accessoryOf===c.userData.objectId&&o.userData.seated));
  selectObject(null);renderObjectList();applyFloorVisibility();$('save-status').textContent='Escenario cargado';showToast('Escenario cargado.');
 }catch(e){
  $('saved-scenes').value=previousId?String(previousId):'';
  showToast(e.message);
 }finally{
  loadingScenario=false;document.body.classList.remove('scene-loading');document.querySelector('.app-shell').inert=false;
  overlay.classList.remove('visible');overlay.setAttribute('aria-hidden','true');
 }
}
$('saved-scenes').addEventListener('change',e=>loadSavedScenario(e.target.value));
$('scenario-name').addEventListener('input',markDirty);

// Equipamiento masivo de estaciones: un único control para todos los escritorios.
$('auto-station').addEventListener('change',e=>setAllDeskStations(e.target.checked));
$('apply-station').addEventListener('click',()=>setAllDeskStations($('auto-station').checked));
$('auto-seat').addEventListener('change',e=>setAllSeats(e.target.checked));
$('apply-seats').addEventListener('click',()=>setAllSeats($('auto-seat').checked));

// Navegación por categorías del panel de configuración para reducir ruido visual.
document.querySelectorAll('[data-settings-tab]').forEach(button=>button.addEventListener('click',()=>{
 const key=button.dataset.settingsTab;
 document.querySelectorAll('[data-settings-tab]').forEach(tab=>{const active=tab===button;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));});
 document.querySelectorAll('[data-settings-panel]').forEach(panel=>{const active=panel.dataset.settingsPanel===key;panel.classList.toggle('active',active);panel.hidden=!active;});
}));

// Paneles laterales: un único estado de rejilla, sin alternar display ni clases ocultas incompatibles.
let panelDrag=null;
const workspace=$('workspace');
const panelState={left:false,right:false};
function setPanelWidth(which,width){
 const other=which==='left'?'right':'left';
 const otherOpen=!panelState[other];
 const otherWidth=otherOpen?(parseFloat(getComputedStyle(document.documentElement).getPropertyValue(which==='left'?'--right-panel-width':'--left-panel-width'))||270):0;
 const max=Math.max(220,window.innerWidth-otherWidth-420);
 const value=Math.max(210,Math.min(Math.min(which==='left'?460:440,window.innerWidth*.34,max),width));
 document.documentElement.style.setProperty(which==='left'?'--left-panel-width':'--right-panel-width',`${value}px`);
}
function applyPanelState(){
 workspace.classList.toggle('left-collapsed',panelState.left);
 workspace.classList.toggle('right-collapsed',panelState.right);
 for(const which of ['left','right']){
  const collapsed=panelState[which];
  const btn=$(which==='left'?'collapse-left':'collapse-right');
  const quick=$(which==='left'?'show-left-panel':'show-right-panel');
  btn.textContent=collapsed?(which==='left'?'›':'‹'):(which==='left'?'‹':'›');
  btn.title=collapsed?'Expandir panel':'Contraer panel';
  btn.setAttribute('aria-expanded',String(!collapsed));
  quick.setAttribute('aria-expanded',String(!collapsed));
  quick.title=collapsed?'Mostrar panel':'Ocultar panel';
 }
 requestAnimationFrame(()=>requestAnimationFrame(resize));
}
function togglePanel(which){panelState[which]=!panelState[which];applyPanelState();}
function startPanelResize(e,which){
 if(panelState[which])return;
 e.preventDefault();
 const prop=which==='left'?'--left-panel-width':'--right-panel-width';
 panelDrag={which,startX:e.clientX,startWidth:parseFloat(getComputedStyle(document.documentElement).getPropertyValue(prop))||(which==='left'?292:270),pointerId:e.pointerId};
 e.currentTarget.setPointerCapture?.(e.pointerId);
 document.body.classList.add('resizing-panels');
}
$('resize-left').addEventListener('pointerdown',e=>startPanelResize(e,'left'));
$('resize-right').addEventListener('pointerdown',e=>startPanelResize(e,'right'));
window.addEventListener('pointermove',e=>{if(!panelDrag)return;const delta=e.clientX-panelDrag.startX;setPanelWidth(panelDrag.which,panelDrag.startWidth+(panelDrag.which==='left'?delta:-delta));});
function stopPanelResize(){if(!panelDrag)return;panelDrag=null;document.body.classList.remove('resizing-panels');requestAnimationFrame(resize);}
window.addEventListener('pointerup',stopPanelResize);
window.addEventListener('pointercancel',stopPanelResize);
$('collapse-left').addEventListener('click',()=>togglePanel('left'));
$('collapse-right').addEventListener('click',()=>togglePanel('right'));
$('show-left-panel').addEventListener('click',()=>togglePanel('left'));
$('show-right-panel').addEventListener('click',()=>togglePanel('right'));
$('tool-fullscreen').addEventListener('click',async()=>{
 try{if(document.fullscreenElement)await document.exitFullscreen();else await $('stage-area').requestFullscreen();}
 catch(e){showToast('El navegador no permitió pantalla completa.');}
});
document.addEventListener('fullscreenchange',()=>{
 const button=$('tool-fullscreen');
 button.innerHTML='<svg viewBox="0 0 24 24"><path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/></svg>';
 button.title=document.fullscreenElement?'Salir de pantalla completa':'Pantalla completa';
 button.setAttribute('aria-label',button.title);
 requestAnimationFrame(resize);
});
// Inicio con una escena SENATI lista para editar, en lugar de un lienzo vacío.
makeRoom();applyClimate(appearance.climate||'day');syncAppearanceInputs();renderLibrary();renderObjectList();refreshScenarioList();
$('classroom-template').click();
function resize(){
 const w=Math.floor(viewport.getBoundingClientRect().width);
 const h=Math.floor(viewport.getBoundingClientRect().height);
 if(w<2||h<2)return;
 camera.aspect=w/h;camera.updateProjectionMatrix();
 renderer.setSize(w,h,false);
}
const viewportObserver=new ResizeObserver(()=>requestAnimationFrame(resize));
viewportObserver.observe(viewport);
window.addEventListener('resize',()=>requestAnimationFrame(resize));
requestAnimationFrame(resize);
renderer.setAnimationLoop(()=>{
 const dt=Math.min(walkClock.getDelta(),.05);
 if(walkMode&&walkControls.isLocked){
   if(activeElevatorRide){updateWalkElevatorRide(dt);renderer.render(scene,camera);return;}
   const speed=3.2*dt;
   const actorPosition=walkPerspective==='third'?walkActorPosition:camera.position;
   const previousWalkPosition=actorPosition.clone();
   const previousOnStairs=walkOnStairs;
   const previousWalkFloorIndex=walkFloorIndex;
   const previousTowerStairState=walkTowerStairState;
   if(walkPerspective==='first'){
     if(walkKeys.forward)walkControls.moveForward(speed);
     if(walkKeys.backward)walkControls.moveForward(-speed);
     if(walkKeys.left)walkControls.moveRight(-speed);
     if(walkKeys.right)walkControls.moveRight(speed);
   }else{
     const yaw=camera.rotation.y;
     const forwardX=-Math.sin(yaw),forwardZ=-Math.cos(yaw);
     const rightX=Math.cos(yaw),rightZ=-Math.sin(yaw);
     let dx=0,dz=0;
     if(walkKeys.forward){dx+=forwardX;dz+=forwardZ;}
     if(walkKeys.backward){dx-=forwardX;dz-=forwardZ;}
     if(walkKeys.left){dx-=rightX;dz-=rightZ;}
     if(walkKeys.right){dx+=rightX;dz+=rightZ;}
     const length=Math.hypot(dx,dz)||1;
     actorPosition.x+=dx/length*speed;actorPosition.z+=dz/length*speed;
   }
   actorPosition.x=THREE.MathUtils.clamp(actorPosition.x,-room.width/2+.45,room.width/2-.45);
   actorPosition.z=THREE.MathUtils.clamp(actorPosition.z,-room.depth/2+.45,room.depth/2-.45);

   const isTower=appearance.buildingPlan==='senati-tower';
   const hasUpper=appearance.buildingPlan==='two-floor'&&getFloors().length>1;
   let floorBase=isTower?floorElevation(walkFloorIndex):(hasUpper?floorElevation(walkFloorIndex):0);
   if(isTower){
     const stairResult=resolveTowerStairMove(previousWalkPosition,actorPosition,walkFloorIndex,walkTowerStairState,towerWorldState?.stairways||[],getFloors());
     if(!stairResult.allowed){actorPosition.copy(previousWalkPosition);walkOnStairs=Boolean(walkTowerStairState);floorBase=previousWalkPosition.y-1.65;}
     else{walkFloorIndex=stairResult.floorIndex;walkOnStairs=stairResult.onStairs;walkTowerStairState=stairResult.stairState;floorBase=stairResult.floorY;}
     if(!stairResult.onStairs&&isTowerCollision({x:actorPosition.x,z:actorPosition.z},walkFloorIndex,towerWorldState?.collision||[],.34)){actorPosition.copy(previousWalkPosition);walkFloorIndex=previousWalkFloorIndex;walkOnStairs=previousOnStairs;walkTowerStairState=previousTowerStairState;floorBase=previousWalkPosition.y-1.65;}
   }
   if(hasUpper){
     const stair=getStairSpec();
     const minZ=Math.min(stair.topZ,stair.bottomZ),maxZ=Math.max(stair.topZ,stair.bottomZ);
     const stairHalf=stair.width/2-.18;
     const onRamp=actorPosition.z>=minZ&&actorPosition.z<=maxZ&&Math.abs(actorPosition.x-stair.x)<=stairHalf;
     const insideShaft=actorPosition.z>=minZ&&actorPosition.z<=maxZ&&Math.abs(actorPosition.x-stair.x)<=stair.width/2+.30;
     if((insideShaft&&!onRamp)||(previousOnStairs&&actorPosition.z>=minZ&&actorPosition.z<=maxZ&&!onRamp)){
       actorPosition.copy(previousWalkPosition);walkOnStairs=previousOnStairs;floorBase=previousWalkPosition.y-1.65;
     }else if(onRamp){
       const progress=THREE.MathUtils.clamp((stair.bottomZ-actorPosition.z)/(stair.bottomZ-stair.topZ),0,1);
       floorBase=floorElevation(0)+(floorElevation(1)-floorElevation(0))*progress;
       walkOnStairs=true;
       if(progress>=.995)walkFloorIndex=1;
       else if(progress<=.005)walkFloorIndex=0;
     }else{
       if(previousOnStairs){
         if(actorPosition.z<stair.topZ)walkFloorIndex=1;
         else if(actorPosition.z>stair.bottomZ)walkFloorIndex=0;
       }
       floorBase=floorElevation(walkFloorIndex);walkOnStairs=false;
     }
   }
   actorPosition.y=floorBase+1.65;

   let blocked=false;
   for(const obj of placed){
     if(!obj.visible||['road','ground','sidewalk','door','window','whiteboard','fluorescent','fan','projector','wall','safety-exit','safety-rules','safety-first-aid','safety-electrical','safety-safe-zone','safety-evacuation'].includes(obj.userData.catalogKey))continue;
     if((hasUpper||isTower)&&!walkOnStairs&&nearestFloorIndex(obj.position.y)!==walkFloorIndex)continue;
     const bounds=new THREE.Box3().setFromObject(obj);
     const feetY=actorPosition.y-1.65,headY=actorPosition.y;
     if(actorPosition.x>bounds.min.x-.22&&actorPosition.x<bounds.max.x+.22&&
        actorPosition.z>bounds.min.z-.22&&actorPosition.z<bounds.max.z+.22&&
        bounds.max.y>feetY+.08&&bounds.min.y<headY){blocked=true;break;}
   }
   if(blocked){actorPosition.copy(previousWalkPosition);walkFloorIndex=isTower?previousWalkFloorIndex:(hasUpper?Math.round((previousWalkPosition.y-1.65)/Math.max(.01,room.height)):0);walkOnStairs=previousOnStairs;walkTowerStairState=previousTowerStairState;}
   if(isTower&&!activeElevatorRide&&!walkElevatorPanelOpen){walkElevatorNearby=findNearbyTowerElevator(actorPosition,walkFloorIndex,towerWorldState?.elevators||[],4.2);$('walk-elevator-prompt')?.classList.toggle('hidden',!walkElevatorNearby);}
   if(walkPerspective==='third'){
     const yaw=camera.rotation.y;
     if(walkAvatar){
       walkAvatar.position.set(actorPosition.x,actorPosition.y-1.65,actorPosition.z);
       walkAvatar.rotation.y=yaw+Math.PI;
       const moved=actorPosition.distanceTo(previousWalkPosition)>.002;
       walkMotionPhase+=dt*(moved?9:2);
       animateHumanoid(walkAvatar,walkMotionPhase,moved);
     }
     const followDistance=3.8;
     camera.position.set(THREE.MathUtils.clamp(actorPosition.x+Math.sin(yaw)*followDistance,-room.width/2+.35,room.width/2-.35),actorPosition.y+.85,THREE.MathUtils.clamp(actorPosition.z+Math.cos(yaw)*followDistance,-room.depth/2+.35,room.depth/2-.35));
   }
 }
 placed.forEach(o=>{if(o.userData.fanRotor)o.userData.fanRotor.rotation.y+=dt*1.15;});
 if(rainPoints?.visible){const a=rainPoints.geometry.attributes.position,top=rainPoints.userData.rainTop||9;for(let i=0;i<a.count;i++){a.array[i*3+1]-=dt*8;if(a.array[i*3+1]<0)a.array[i*3+1]=top;}a.needsUpdate=true;}
 if(selectionHelper&&selected)selectionHelper.update();
 if(!walkMode)controls.update();
 renderer.render(scene,camera);
});
