import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
export function createSceneModel(key, options = {}) {
  const seated=Boolean(options.seated);
  const room={width:Number(options.width)||20,depth:Number(options.depth)||12,height:Number(options.height)||3.35};
  const appearance={floorType:'tile',floorColor:'#f2f4f7',wallColor:'#f1f3f6',deskColor:'#1559a8',chairColor:'#202a38',...(options.appearance||{})};
  const DESK_LENGTH=1.58,DESK_DEPTH=.72;
  const mat=(color,roughness=.72,metalness=0)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
  const mats={desk:mat(0x164b82,.48),deskEdge:mat(0x0d3159,.55),black:mat(0x171c24,.75),metal:mat(0x77838e,.54,.36),blue:mat(0x07549b,.68),yellow:mat(0xf3c34b,.5),skin:mat(0xc88f6b,.85),white:mat(0xf6f7f8,.5),glass:new THREE.MeshPhysicalMaterial({color:0xbfe9f7,roughness:.06,metalness:0,transparent:true,opacity:.24,transmission:.72,thickness:.06,ior:1.46,depthWrite:false,side:THREE.DoubleSide}),wall:mat(0xe3e7eb,.9),green:mat(0x327f5a,.85),brown:mat(0x8a6245,.8)};
  function mesh(parent,geometry,material,x=0,y=0,z=0,cast=true){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=cast;m.receiveShadow=true;parent.add(m);return m;}
  function box(parent,w,h,d,material,x,y,z){
    const smallest=Math.min(Math.abs(w),Math.abs(h),Math.abs(d));
    const geometry=smallest>=.008?new RoundedBoxGeometry(w,h,d,2,Math.min(.018,smallest*.22)):new THREE.BoxGeometry(w,h,d);
    return mesh(parent,geometry,material,x,y,z);
  }
  function cylinder(parent,rt,rb,h,material,x,y,z,segments=24){return mesh(parent,new THREE.CylinderGeometry(rt,rb,h,segments),material,x,y,z);}
function createPerson(key, seated=false, personConfig={}) {
  const g=new THREE.Group();
  const isTeacher=key==='teacher'||key==='teacher-f';
  const isWoman=key.startsWith('woman')||key==='teacher-f';
  const isSenati=key.endsWith('-senati');
  const casualColors=isWoman?[0x287f79,0x72578d,0xa85d72,0x376f9d]:[0x286da5,0x347b62,0x986344,0x596985];
  const customColor=String(personConfig.shirtColor||'').replace('#','');
  const parsedColor=/^[0-9a-fA-F]{6}$/.test(customColor)?parseInt(customColor,16):null;
  const shirtColor=parsedColor??(isTeacher?0x24364b:(isSenati?0x123f72:casualColors[Math.floor(Math.random()*casualColors.length)]));
  const skin=mat(isWoman?0xd9a27e:0xc98e69,.9);
  const shirt=mat(shirtColor,.82);
  const pants=mat(isTeacher?0x202b39:(isWoman?0x263448:0x202b3b),.9);
  const hair=mat(isWoman?0x68402f:(isTeacher?0x292522:0x292724),.96);
  const shoe=mat(0x17202b,.78), eye=mat(0x202832,.72), eyeWhite=mat(0xf5f5f2,.62);
  const ellipsoid=(parent,scale,material,pos)=>{
    const m=mesh(parent,new THREE.SphereGeometry(1,24,18),material,...pos);
    m.scale.set(...scale);return m;
  };
  const capsuleBetween=(parent,r,material,a,b)=>{
    const va=new THREE.Vector3(...a),vb=new THREE.Vector3(...b),dir=vb.clone().sub(va);
    const m=mesh(parent,new THREE.CapsuleGeometry(r,Math.max(.005,dir.length()-2*r),8,14),material);
    m.position.copy(va.add(vb).multiplyScalar(.5));
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize());
    return m;
  };
  const topY=seated?.84:1.08;
  const headY=seated?1.48:1.72;
  // Torso with a subtle waist taper and separate shoulder volume.
  ellipsoid(g,[.218,seated?.285:.325,.145],shirt,[0,topY,0]);
  ellipsoid(g,[.205,.105,.142],shirt,[0,topY-.205,0]);
  ellipsoid(g,[.225,.105,.135],shirt,[0,topY+.205,0]);
  const neck=mesh(g,new THREE.CylinderGeometry(.067,.078,.15,24),skin,0,topY+.37,.008);neck.rotation.x=-.04;
  // Collar, placket and small garment details.
  const collarMat=mat(isTeacher?0xe7edf2:0xdce6ed,.82);
  capsuleBetween(g,.018,collarMat,[-.075,topY+.30,.12],[0,topY+.22,.15]);
  capsuleBetween(g,.018,collarMat,[.075,topY+.30,.12],[0,topY+.22,.15]);
  if(!isTeacher){
    for(let i=0;i<3;i++)ellipsoid(g,[.008,.008,.006],mat(0xd6e2ea,.8),[0,topY+.075-i*.065,.148]);
  }
  if(isSenati && (personConfig.shirtStyle||'senati')==='senati'){
    const badgeCanvas=document.createElement('canvas');badgeCanvas.width=384;badgeCanvas.height=128;
    const bc=badgeCanvas.getContext('2d');bc.fillStyle='#123f72';bc.fillRect(0,0,384,128);bc.fillStyle='#fff';bc.font='bold 58px Arial';bc.textAlign='center';bc.textBaseline='middle';bc.fillText('SENATI',192,64);
    const badgeTex=new THREE.CanvasTexture(badgeCanvas);badgeTex.colorSpace=THREE.SRGBColorSpace;
    mesh(g,new THREE.PlaneGeometry(.17,.057),new THREE.MeshBasicMaterial({map:badgeTex}),.105,topY+.11,.148,false);
  }
  if(isTeacher){
    const jacket=mat(0x30465f,.84),shirtFront=mat(0xf0f2f3,.75),tie=mat(0x8b3d4a,.72);
    ellipsoid(g,[.102,.245,.018],shirtFront,[0,topY+.005,.145]);
    capsuleBetween(g,.025,jacket,[-.18,topY+.27,.06],[-.07,topY-.19,.12]);
    capsuleBetween(g,.025,jacket,[.18,topY+.27,.06],[.07,topY-.19,.12]);
    const tieMesh=mesh(g,new THREE.ConeGeometry(.035,.22,5),tie,0,topY-.055,.17);tieMesh.rotation.x=Math.PI;
  }
  // Face: ears, eyes with pupils/highlights, brows, nose and a discreet smile.
  ellipsoid(g,[.158,.184,.145],skin,[0,headY,.014]);
  for(const side of [-1,1])ellipsoid(g,[.032,.05,.027],skin,[side*.157,headY-.005,.002]);
  for(const side of [-1,1]){
    ellipsoid(g,[.026,.027,.014],eyeWhite,[side*.053,headY+.018,.145]);
    ellipsoid(g,[.012,.016,.008],eye,[side*.053,headY+.016,.158]);
    ellipsoid(g,[.004,.005,.003],eyeWhite,[side*.049,headY+.022,.164]);
    capsuleBetween(g,.008,hair,[side*.029,headY+.065,.145],[side*.079,headY+.064,.137]);
  }
  ellipsoid(g,[.016,.023,.018],skin,[0,headY-.035,.151]);
  const smilePts=[new THREE.Vector3(-.031,headY-.079,.142),new THREE.Vector3(0,headY-.087,.15),new THREE.Vector3(.031,headY-.079,.142)];
  mesh(g,new THREE.TubeGeometry(new THREE.CatmullRomCurve3(smilePts),10,.0045,5,false),eye,0,0,0,false);
  // Natural hair cap and hairline; ponytail is kept behind the shoulders.
  ellipsoid(g,[.164,.096,.151],hair,[0,headY+.115,-.012]);
  ellipsoid(g,[.16,.045,.055],hair,[0,headY+.065,.112]);
  if(isWoman){
    ellipsoid(g,[.052,.16,.06],hair,[.128,headY-.075,-.055]);
    ellipsoid(g,[.052,.16,.06],hair,[-.128,headY-.075,-.055]);
    ellipsoid(g,[.065,.12,.065],hair,[.015,headY-.16,-.17]);
  } else {
    ellipsoid(g,[.15,.045,.11],hair,[0,headY+.045,-.105]);
  }
  if(isTeacher){
    for(const side of [-1,1]){
      const lens=mesh(g,new THREE.TorusGeometry(.034,.0035,6,18),mat(0x344454,.42,.22),side*.053,headY+.018,.158);
      lens.scale.set(1,.74,1);
    }
    capsuleBetween(g,.009,mat(0x344454,.42,.2),[-.018,headY+.056,.16],[.018,headY+.056,.16]);
  }
  // Articulated arms. Seated hands reach toward the workstation; standing arms swing from shoulders.
  const armPivots={},legPivots={},kneePivots={};
  for(const side of [-1,1]){
    if(seated){
      const shoulder=[side*.205,topY+.16,.015],elbow=[side*.27,topY+.045,.27],wrist=[side*.30,topY-.065,.52];
      capsuleBetween(g,.069,shirt,shoulder,elbow);ellipsoid(g,[.069,.069,.069],shirt,elbow);
      capsuleBetween(g,.052,skin,[elbow[0],elbow[1],elbow[2]],[wrist[0],wrist[1],wrist[2]]);
      ellipsoid(g,[.056,.035,.07],skin,[wrist[0],wrist[1],wrist[2]+.025]);
      for(let f=0;f<4;f++)capsuleBetween(g,.009,skin,[wrist[0]+(f-1.5)*.022,wrist[1]-.008,wrist[2]+.045],[wrist[0]+(f-1.5)*.022,wrist[1]-.012,wrist[2]+.092]);
      ellipsoid(g,[.018,.027,.026],skin,[wrist[0]+side*.048,wrist[1],wrist[2]+.015]);
    }else{
      const arm=new THREE.Group();arm.position.set(side*.22,topY+.16,0);g.add(arm);
      capsuleBetween(arm,.071,shirt,[0,0,0],[side*.035,-.245,.012]);
      ellipsoid(arm,[.071,.071,.071],shirt,[side*.035,-.245,.012]);
      const elbow=new THREE.Group();elbow.position.set(side*.035,-.245,.012);arm.add(elbow);
      capsuleBetween(elbow,.052,shirt,[0,0,0],[side*.025,-.225,.045]);
      ellipsoid(elbow,[.054,.054,.054],skin,[side*.025,-.225,.045]);
      ellipsoid(elbow,[.052,.035,.068],skin,[side*.025,-.235,.095]);
      for(let f=0;f<4;f++)capsuleBetween(elbow,.009,skin,[side*.025+(f-1.5)*.021,-.238,.13],[side*.025+(f-1.5)*.021,-.245,.177]);
      ellipsoid(elbow,[.018,.026,.027],skin,[side*.075,-.222,.09]);
      armPivots[side<0?'left':'right']=arm;
    }
  }
  // Pelvis and legs. Female casual figures use tailored trousers; all silhouettes share the same scale.
  ellipsoid(g,[.178,seated?.12:.15,.135],pants,[0,seated?.59:.79,0]);
  if(isWoman&&!seated&&!isTeacher){
    // A clean, modest A-line skirt panel over the upper legs.
    const skirt=mesh(g,new THREE.CylinderGeometry(.155,.205,.27,32),pants,0,.68,0);skirt.scale.set(1,1,.82);
  }
  for(const side of [-1,1]){
    if(seated){
      const hip=[side*.105,.57,0],knee=[side*.11,.52,.30],ankle=[side*.11,.15,.33];
      capsuleBetween(g,.073,pants,hip,knee);ellipsoid(g,[.074,.072,.074],pants,knee);
      capsuleBetween(g,.06,pants,knee,ankle);
      ellipsoid(g,[.105,.052,.17],shoe,[side*.11,.075,.405]);
      // Sole gives the shoe a distinct, grounded silhouette.
      ellipsoid(g,[.108,.018,.171],mat(0x101820,.9),[side*.11,.043,.405]);
    }else{
      const leg=new THREE.Group();leg.position.set(side*.105,.79,0);g.add(leg);
      capsuleBetween(leg,.071,pants,[0,0,0],[0,-.35,.005]);
      ellipsoid(leg,[.073,.072,.074],pants,[0,-.35,.005]);
      const knee=new THREE.Group();knee.position.set(0,-.35,.005);leg.add(knee);
      capsuleBetween(knee,.057,pants,[0,0,0],[0,-.32,.015]);
      ellipsoid(knee,[.059,.058,.06],pants,[0,-.32,.015]);
      ellipsoid(knee,[.09,.047,.15],shoe,[0,-.685,.09]);
      ellipsoid(knee,[.092,.016,.152],mat(0x101820,.9),[0,-.718,.09]);
      legPivots[side<0?'left':'right']=leg;
      kneePivots[side<0?'left':'right']=knee;
    }
  }
  // Teacher lanyard and restrained tailoring details.
  if(isTeacher){
    capsuleBetween(g,.009,mat(0xd2b66a,.65),[.12,topY+.25,.145],[.12,topY+.04,.15]);
    box(g,.045,.065,.012,mat(0xced9e3,.58),.12,topY-.005,.16);
  }
  g.userData.kind=key;
  g.userData.seated=seated;
  g.userData.rig={animated:!seated,seated,leftArm:armPivots.left,rightArm:armPivots.right,leftLeg:legPivots.left,rightLeg:legPivots.right,leftKnee:kneePivots.left,rightKnee:kneePivots.right};
  return g;
}
function createModel(key, seated=false, personConfig={}) {
  const g=new THREE.Group();
  const deskTopY=.78;
  switch(key){
    case 'desk': {
      const deskMat=mat(appearance.deskColor,.48);
      const deskEdgeMat=mat(appearance.deskColor,.58);
      g.userData.primaryColorMaterial=deskMat;
      g.userData.secondaryColorMaterial=deskEdgeMat;
      // Escritorio con orientación local inequívoca: frente = +Z, posterior = -Z.
      // La huella es idéntica en todas las instancias: 158 x 72 cm.
      mesh(g,new RoundedBoxGeometry(DESK_LENGTH,.10,DESK_DEPTH,4,.035),deskMat,0,deskTopY,0);
      box(g,DESK_LENGTH+.025,.025,DESK_DEPTH+.02,deskEdgeMat,0,deskTopY-.065,0);
      // Canal posterior para cableado: identifica el lado donde va el monitor.
      box(g,.92,.012,.045,mat(0x343b43,.8),0,.837,-.315);
      // Zona de teclado marcada sobre la superficie (sin relieve molesto).
      box(g,.72,.004,.245,mat(0xc7b99e,.9),-.055,.833,.105);
      // Línea frontal discreta y redondeada visualmente mediante una moldura fina.
      box(g,1.34,.012,.018,mat(0x9b805e,.72),0,.837,.345);
      // Patas y travesaños simétricos para mantener una geometría consistente.
      for(const x of [-.70,.70]) for(const z of [-.27,.27]) box(g,.055,.72,.055,mats.metal,x,.36,z);
      box(g,1.28,.045,.035,mats.metal,0,.39,-.27);
      g.userData.deskOrientation={front:'+Z',rear:'-Z',standardLength:DESK_LENGTH,standardDepth:DESK_DEPTH};
      break;
    }
    case 'chair': {
      const chairMat=mat(appearance.chairColor,.88);
      const upholstery=mat(new THREE.Color(appearance.chairColor).lerp(new THREE.Color(0xffffff),.10),.94);
      const seamMat=mat(0x111c29,.92), chrome=mat(0x84919d,.48,.42);
      g.userData.primaryColorMaterial=chairMat;
      // Ergonomic upholstered seat and a gently reclined backrest.
      box(g,.50,.105,.47,chairMat,0,.59,0);
      box(g,.46,.055,.43,upholstery,0,.665,.005);
      const back=box(g,.49,.58,.105,chairMat,0,1.00,-.18);back.rotation.x=-.09;
      const backPad=box(g,.445,.52,.055,upholstery,0,1.005,-.115);backPad.rotation.x=-.09;
      box(g,.40,.012,.012,seamMat,0,.78,-.082);
      // Twin supports, a metal gas lift and five-spoke wheeled base.
      for(const side of [-1,1]){
        const support=box(g,.035,.31,.045,chrome,side*.17,.77,-.17);support.rotation.x=-.10;
        const arm=box(g,.055,.035,.29,chrome,side*.25,.72,-.005);arm.rotation.x=-.08;
      }
      cylinder(g,.052,.052,.30,chrome,0,.36,0,24);
      cylinder(g,.092,.092,.055,mat(0x596674,.55,.34),0,.205,0,24);
      for(let i=0;i<5;i++){
        const a=i*Math.PI*2/5;
        const spoke=box(g,.40,.032,.045,chrome,Math.cos(a)*.18,.12,Math.sin(a)*.18);spoke.rotation.y=-a;
        const wheel=mesh(g,new THREE.SphereGeometry(1,20,14),mat(0x151b23,.76),Math.cos(a)*.39,.075,Math.sin(a)*.39);
        wheel.scale.set(.065,.045,.045);wheel.rotation.y=a;
      }
      break;
    }
    case 'aio': {
      // All-in-One XL: pantalla ampliada para que se lea claramente en aulas amplias.
      // Huella visual aproximada: 0.88 x 0.50 m; base y soporte proporcionales.
      box(g,.92,.535,.072,mats.black,0,1.185,0);
      box(g,.892,.507,.009,mat(0x080d16,.35),0,1.188,.039);
      const screen=box(g,.868,.488,.008,mat(0x0c3155,.25),0,1.188,.046);
      const stand=box(g,.095,.275,.082,mat(0x9aa6b2,.38,.35),0,.91,-.008);
      // Base ancha, con apoyo metálico visible y centrado sobre la mesa.
      const base=box(g,.405,.032,.245,mat(0x788694,.42,.28),0,.845,.045);base.rotation.x=-.035;
      box(g,.355,.014,.205,mat(0xc2cbd3,.36,.25),0,.868,.045);
      // Pantalla personalizable: Windows 11, SENATI o pantalla neutra.
      const c=document.createElement('canvas');c.width=768;c.height=432;
      const ctx=c.getContext('2d');
      const drawScreen=(mode='windows11')=>{
        ctx.clearRect(0,0,768,432);
        if(mode==='windows11'){
          const gr=ctx.createLinearGradient(0,0,768,432);gr.addColorStop(0,'#061a49');gr.addColorStop(.55,'#0876bd');gr.addColorStop(1,'#46c5dc');ctx.fillStyle=gr;ctx.fillRect(0,0,768,432);
          ctx.fillStyle='rgba(255,255,255,.16)';ctx.beginPath();ctx.ellipse(405,200,250,130,-.35,0,Math.PI*2);ctx.fill();
          ctx.fillStyle='#fff';ctx.font='500 25px Segoe UI,Arial';ctx.fillText('12:45',34,48);ctx.font='18px Segoe UI,Arial';ctx.fillText('Lunes, 2 de noviembre',34,78);
          ctx.fillStyle='rgba(18,34,63,.82)';ctx.beginPath();ctx.roundRect(180,374,408,42,18);ctx.fill();
          // Icono Windows de cuatro paneles y campo Buscar, dibujados sin depender de fuentes instaladas.
          ctx.fillStyle='#f5fbff';ctx.fillRect(300,386,11,11);ctx.fillRect(314,386,11,11);ctx.fillRect(300,400,11,11);ctx.fillRect(314,400,11,11);
          ctx.fillStyle='#fff';ctx.font='bold 19px Segoe UI,Arial';ctx.fillText('Buscar',345,403);ctx.font='20px Arial';ctx.fillText('···',520,403);
        } else if(mode==='senati'){
          const gr=ctx.createLinearGradient(0,0,768,432);gr.addColorStop(0,'#08264b');gr.addColorStop(1,'#1265a5');ctx.fillStyle=gr;ctx.fillRect(0,0,768,432);
          // Emblema institucional estilizado junto al nombre; se dibuja en canvas para verse en el monitor.
          ctx.beginPath();for(let i=0;i<6;i++){const a=-Math.PI/2+i*Math.PI/3,x=384+Math.cos(a)*70,y=132+Math.sin(a)*70;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.closePath();ctx.fillStyle='#ffffff';ctx.fill();
          ctx.fillStyle='#125b9b';ctx.font='900 92px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('S',384,132);
          ctx.fillStyle='#fff';ctx.font='bold 84px Arial';ctx.textBaseline='alphabetic';ctx.fillText('SENATI',384,286);ctx.fillStyle='#6bd2ed';ctx.fillRect(240,316,288,7);
          ctx.font='600 22px Arial';ctx.fillStyle='#d8efff';ctx.fillText('FORMACIÓN PROFESIONAL',384,357);ctx.textAlign='left';
        } else {ctx.fillStyle='#eef3f8';ctx.fillRect(0,0,768,432);ctx.fillStyle='#164b82';ctx.font='bold 48px Arial';ctx.textAlign='center';ctx.fillText('Pantalla de presentación',384,220);ctx.textAlign='left';}
      };
      drawScreen('windows11');
      const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
      const plane=mesh(g,new THREE.PlaneGeometry(.868,.488),new THREE.MeshBasicMaterial({map:tex}),0,1.188,.052);
      g.userData.screenCanvas=c;g.userData.screenTexture=tex;g.userData.drawScreen=drawScreen;g.userData.screenMode='windows11';
      break;
    }
    case 'keyboard': {
      box(g,.52,.026,.18,mats.black,0,.83,0);
      const keyMat=mat(0xd2d8df,.7);
      for(let r=0;r<4;r++)for(let i=0;i<14;i++)box(g,.023,.008,.019,keyMat,-.245+i*.036,.849,-.062+r*.041);
      break;
    }
    case 'mouse': {
      const shellMat=mat(0x252c35,.68),buttonMat=mat(0x343d49,.72),wheelMat=mat(0x9aa5b0,.62,.12);
      const shell=mesh(g,new THREE.SphereGeometry(1,24,18),shellMat,0,.84,0);shell.scale.set(.052,.029,.079);
      box(g,.002,.024,.072,buttonMat,0,.856,.004);
      const wheel=mesh(g,new THREE.CylinderGeometry(.009,.009,.009,16),wheelMat,0,.861,.014);wheel.rotation.z=Math.PI/2;
      box(g,.012,.008,.018,buttonMat,-.034,.85,-.005);box(g,.012,.008,.018,buttonMat,.034,.85,-.005);
      break;
    }
    case 'man': case 'woman': case 'man-senati': case 'woman-senati': case 'teacher': case 'teacher-f': {
      return createPerson(key, seated, personConfig);
    }
    case 'road': {
      const asphalt=mat(0x343b43,.98),paint=mat(0xf5f2e8,.72),curb=mat(0xc8cdd2,.9);
      box(g,20,.12,6.4,asphalt,0,.06,0);
      box(g,20,.025,.11,paint,0,.13,-2.8);box(g,20,.025,.11,paint,0,.13,2.8);
      for(let x=-8;x<=8;x+=2.4)box(g,1.18,.024,.10,paint,x,.135,0);
      box(g,20,.20,.18,curb,0,.10,-3.25);box(g,20,.20,.18,curb,0,.10,3.25);
      g.userData.worldSurface='road';break;
    }
    case 'ground': {
      const concrete=mat(0xc5ccd2,.94),joint=mat(0x9aa4ad,.96),edge=mat(0xe5e8eb,.9);
      box(g,10,.18,10,concrete,0,.09,0);
      for(let x=-4.5;x<=4.5;x+=1)box(g,.018,.012,9.92,joint,x,.186,0);
      for(let z=-4.5;z<=4.5;z+=1)box(g,9.92,.012,.018,joint,0,.186,z);
      box(g,10,.06,.08,edge,0,.20,-4.96);box(g,10,.06,.08,edge,0,.20,4.96);
      g.userData.worldSurface='ground';break;
    }
    case 'sidewalk': {
      const concrete=mat(0xb9c0c6,.92),joint=mat(0x929ba3,.96),curb=mat(0xe0e3e6,.9);
      box(g,12,.20,3.0,concrete,0,.10,0);
      for(let x=-5.5;x<=5.5;x+=1)box(g,.018,.012,2.92,joint,x,.207,0);
      for(let z=-1;z<=1;z+=1)box(g,11.95,.012,.018,joint,0,.208,z);
      box(g,12,.22,.16,curb,0,.11,-1.58);box(g,12,.22,.16,curb,0,.11,1.58);
      g.userData.worldSurface='sidewalk';break;
    }
    case 'wall': {
      const wallMat=mat(appearance.wallColor,.9);
      g.userData.primaryColorMaterial=wallMat;
      box(g,2.5,room.height,.16,wallMat,0,room.height/2,0);
      break;
    }
    case 'door': case 'door-normal': {
      const isNormal=key==='door-normal';
      const frame=mat(isNormal?0x59402f:0x485a6d,.36,.55),handle=mat(0xc2ccd6,.24,.82);
      box(g,1.42,2.48,.085,frame,0,1.24,0);
      const paneMat=isNormal?mat(0x986b45,.72):mats.glass;
      const pane=mesh(g,new THREE.BoxGeometry(1.28,2.34,.018),paneMat,0,1.24,.052);pane.renderOrder=3;
      box(g,.035,2.34,.055,frame,-.62,1.24,.065);box(g,.035,2.34,.055,frame,.62,1.24,.065);
      box(g,1.26,.035,.055,frame,0,2.40,.065);box(g,1.26,.035,.055,frame,0,.08,.065);
      box(g,.025,2.28,.045,frame,0,1.24,.075);
      box(g,.035,.74,.075,handle,.47,1.18,.12);cylinder(g,.025,.025,.035,handle,.45,1.18,.15,16);
      box(g,1.30,.045,.07,handle,0,.035,.08);
      break;
    }
    case 'window': {
      const frame=mat(0x485a6d,.34,.58),seal=mat(0xe8eef4,.58);
      const pane=mesh(g,new THREE.BoxGeometry(2.08,1.35,.018),mats.glass,0,1.84,.04);pane.renderOrder=3;
      box(g,2.18,.055,.09,frame,0,2.53,0);box(g,2.18,.055,.09,frame,0,1.15,0);
      box(g,.055,1.42,.09,frame,-1.06,1.84,0);box(g,.055,1.42,.09,frame,1.06,1.84,0);
      box(g,.035,1.32,.07,frame,0,1.84,.045);
      box(g,2.08,.025,.055,seal,0,1.84,.065);
      break;
    }
    case 'safety-exit': case 'safety-rules': case 'safety-first-aid': case 'safety-electrical': case 'safety-safe-zone': case 'safety-evacuation': {
      const isExit=key==='safety-exit', isRules=key==='safety-rules';
      const presets={
        'safety-exit':{w:.82,h:.42,bg:'#087a45',fg:'#ffffff',title:'SALIDA'},
        'safety-rules':{w:1.02,h:.72,bg:'#f7f9fb',fg:'#17324d',title:'REGLAS DE SEGURIDAD'},
        'safety-first-aid':{w:.62,h:.52,bg:'#087a45',fg:'#ffffff',title:'BOTIQUÍN',symbol:'✚'},
        'safety-electrical':{w:.66,h:.58,bg:'#ffd22e',fg:'#1e293b',title:'RIESGO ELÉCTRICO',symbol:'⚡'},
        'safety-safe-zone':{w:.76,h:.58,bg:'#087a45',fg:'#ffffff',title:'ZONA SEGURA',symbol:'✚'},
        'safety-evacuation':{w:.82,h:.42,bg:'#087a45',fg:'#ffffff',title:'RUTA DE EVACUACIÓN',symbol:'➜'}
      };
      const p=presets[key];
      box(g,p.w,p.h,.055,mat(p.bg,.55),0,1.72,0);
      const c=document.createElement('canvas');c.width=640;c.height=420;const ctx=c.getContext('2d');
      ctx.fillStyle=p.bg;ctx.fillRect(0,0,640,420);ctx.strokeStyle=p.fg;ctx.lineWidth=13;ctx.strokeRect(8,8,624,404);
      ctx.fillStyle=p.fg;ctx.textAlign='center';
      if(isRules){
        ctx.font='bold 39px Arial';ctx.fillText(p.title,320,65);ctx.textAlign='left';ctx.font='bold 29px Arial';
        ['Mantén libre la salida','No bloquees los pasillos','Cuida cables y equipos','Sigue las indicaciones'].forEach((t,i)=>ctx.fillText('• '+t,35,135+i*66));
      } else if(isExit){
        // Rótulo de texto limpio, sin flecha; se coloca centrado sobre la puerta.
        ctx.font='bold 112px Arial';ctx.textBaseline='middle';ctx.fillText('SALIDA',320,220);ctx.textBaseline='alphabetic';
      } else {
        ctx.font=`bold ${key==='safety-evacuation'?47:58}px Arial`;ctx.fillText(p.title,320,key==='safety-electrical'?82:90);
        ctx.font='bold 190px Arial';ctx.fillText(p.symbol||'',320,300);
      }
      const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
      const plane=mesh(g,new THREE.PlaneGeometry(p.w-.025,p.h-.025),new THREE.MeshBasicMaterial({map:tex}),0,1.72,.031);plane.renderOrder=4;
      g.userData.safetySign=true;
      break;
    }
    case 'fire-extinguisher': {
      const red=mat(0xc62828,.42),dark=mat(0x283443,.5),metal=mat(0xaeb8c2,.32,.65);
      cylinder(g,.105,.12,.62,red,0,.40,0,24);
      cylinder(g,.105,.105,.045,mat(0x9f1d1d,.45),0,.72,0,24);
      cylinder(g,.035,.035,.09,metal,0,.79,0,16);
      const handle=box(g,.19,.035,.045,dark,.055,.84,0);handle.rotation.z=-.12;
      const hose=mesh(g,new THREE.TorusGeometry(.105,.012,8,24,Math.PI*1.35),dark,-.11,.70,.025);hose.rotation.z=Math.PI/2;
      box(g,.27,.035,.035,metal,0,.06,0);
      const labelCanvas=document.createElement('canvas');labelCanvas.width=256;labelCanvas.height=128;const lc=labelCanvas.getContext('2d');
      lc.fillStyle='#fff';lc.fillRect(0,0,256,128);lc.fillStyle='#c62828';lc.font='bold 31px Arial';lc.textAlign='center';lc.fillText('EXTINTOR',128,49);lc.font='bold 23px Arial';lc.fillText('ABC',128,88);
      const labelTex=new THREE.CanvasTexture(labelCanvas);labelTex.colorSpace=THREE.SRGBColorSpace;
      mesh(g,new THREE.PlaneGeometry(.18,.09),new THREE.MeshBasicMaterial({map:labelTex}),0,.43,.122);
      g.userData.safetyEquipment=true;
      break;
    }
    case 'whiteboard': {
      box(g,2.4,1.25,.08,mats.metal,0,1.65,0);
      box(g,2.28,1.13,.035,mats.white,0,1.65,.05);
      break;
    }
    case 'fluorescent': {
      const frame=mat(0x64748b,.4,.45),emitter=new THREE.MeshStandardMaterial({color:0xffffff,emissive:0xffffff,emissiveIntensity:2.3,roughness:.25});
      box(g,1.48,.065,.30,frame,0,room.height-.15,0);
      box(g,1.32,.025,.20,emitter,0,room.height-.105,0);
      const light=new THREE.PointLight(0xfff9ed,3.8,6.8,1.7);light.position.set(0,room.height-.28,0);light.castShadow=false;g.add(light);
      break;
    }
    case 'fan': {
      // Mounting plate, downrod and motor are fixed; blades share one centered rotor.
      const ceilingY=room.height-.08;
      cylinder(g,.24,.24,.055,mats.metal,0,ceilingY,0,32);
      cylinder(g,.045,.045,.34,mats.metal,0,room.height-.27,0,20);
      cylinder(g,.19,.19,.20,mat(0x66717d,.42,.45),0,room.height-.49,0,32);
      cylinder(g,.105,.105,.08,mat(0x9da8b3,.35,.5),0,room.height-.63,0,24);
      const rotor=new THREE.Group();
      rotor.position.y=room.height-.64;
      const bladeShape=new THREE.Shape();
      bladeShape.moveTo(-.085,.10);
      bladeShape.quadraticCurveTo(-.17,.42,-.105,.91);
      bladeShape.quadraticCurveTo(-.02,1.10,.105,1.02);
      bladeShape.quadraticCurveTo(.15,.60,.085,.10);
      bladeShape.closePath();
      const bladeGeo=new THREE.ExtrudeGeometry(bladeShape,{depth:.035,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:.012,bevelThickness:.008});
      bladeGeo.rotateX(-Math.PI/2);
      const bladeMat=mat(0xe7ebef,.48,.18);
      for(let i=0;i<3;i++){
        const blade=mesh(rotor,bladeGeo,bladeMat,0,0,0);
        blade.rotation.y=i*Math.PI*2/3;
      }
      cylinder(rotor,.125,.125,.09,mat(0x7d8995,.35,.5),0,.035,0,24);
      g.add(rotor);
      g.userData.fanRotor=rotor;
      break;
    }
    case 'projector': {
      box(g,.48,.18,.42,mats.white,0,room.height-.22,0);
      cylinder(g,.08,.08,.07,mats.black,.23,room.height-.22,0,16).rotation.z=Math.PI/2;
      break;
    }
    case 'plant': {
      cylinder(g,.22,.27,.35,mat(0x9b6546,.85),0,.18,0);
      for(let i=0;i<7;i++){const leaf=mesh(g,new THREE.SphereGeometry(.13,12,8),mat(0x3d8158,.8),Math.cos(i)*.18,.55+Math.sin(i*1.3)*.18,Math.sin(i)*.18);leaf.scale.set(.65,1.5,.65);}
      break;
    }
  }
  return g;
}

  const model=createModel(key,seated,options.personConfig||{});
  if(options.screenMode && model.userData.drawScreen){model.userData.drawScreen(options.screenMode);if(model.userData.screenTexture)model.userData.screenTexture.needsUpdate=true;model.userData.screenMode=options.screenMode;}
  return model;
}
