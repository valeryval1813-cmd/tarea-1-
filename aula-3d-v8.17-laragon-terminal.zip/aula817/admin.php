<?php
declare(strict_types=1);
require_once __DIR__ . '/config/auth.php';
$me = require_admin();
$pdo = db();
$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_is_valid($_POST['csrf_token'] ?? null)) {
        $error = 'La sesión del formulario venció. Recarga la página e inténtalo otra vez.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        try {
            if ($action === 'create_user') {
                $name = trim((string)($_POST['name'] ?? ''));
                $email = strtolower(trim((string)($_POST['email'] ?? '')));
                $password = (string)($_POST['password'] ?? '');
                $role = (($_POST['role'] ?? 'user') === 'admin') ? 'admin' : 'user';
                if ($name === '' || strlen($name) > 120 || !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Ingresa un nombre y correo válidos.');
                if (strlen($password) < 10) throw new RuntimeException('La contraseña debe tener al menos 10 caracteres.');
                $stmt = $pdo->prepare('INSERT INTO users (name,email,password_hash,role,is_active) VALUES (?,?,?,?,1)');
                $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$role]);
                $notice = 'Usuario creado. Ahora puedes asignarle escenarios.';
            } elseif ($action === 'save_user') {
                $id = (int)($_POST['user_id'] ?? 0);
                $name = trim((string)($_POST['name'] ?? ''));
                $email = strtolower(trim((string)($_POST['email'] ?? '')));
                $role = (($_POST['role'] ?? 'user') === 'admin') ? 'admin' : 'user';
                $active = isset($_POST['is_active']) ? 1 : 0;
                if ($id < 1 || $name === '' || strlen($name) > 120 || !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Datos de usuario no válidos.');
                if ($id === (int)$me['id'] && ($role !== 'admin' || $active !== 1)) throw new RuntimeException('No puedes quitarte a ti mismo el rol de administrador ni desactivar tu cuenta.');
                $targetStmt = $pdo->prepare('SELECT role,is_active FROM users WHERE id=?');
                $targetStmt->execute([$id]);
                $targetUser = $targetStmt->fetch();
                if (!$targetUser) throw new RuntimeException('No se encontró el usuario que deseas actualizar.');
                if ($targetUser['role'] === 'admin' && (int)$targetUser['is_active'] === 1 && ($role !== 'admin' || $active !== 1)) {
                    $activeAdmins = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin' AND is_active=1")->fetchColumn();
                    if ($activeAdmins <= 1) throw new RuntimeException('No puedes desactivar o degradar al último administrador activo.');
                }
                $stmt = $pdo->prepare('UPDATE users SET name=?,email=?,role=?,is_active=? WHERE id=?');
                $stmt->execute([$name,$email,$role,$active,$id]);
                $notice = 'Datos del usuario actualizados.';
            } elseif ($action === 'reset_password') {
                $id = (int)($_POST['user_id'] ?? 0);
                $password = (string)($_POST['password'] ?? '');
                if ($id < 1 || strlen($password) < 10) throw new RuntimeException('La nueva contraseña debe tener al menos 10 caracteres.');
                $stmt = $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?');
                $stmt->execute([password_hash($password,PASSWORD_DEFAULT),$id]);
                $notice = 'Contraseña actualizada.';
            } elseif ($action === 'save_access') {
                $id = (int)($_POST['user_id'] ?? 0);
                $check = $pdo->prepare('SELECT role FROM users WHERE id=?');
                $check->execute([$id]);
                $target = $check->fetch();
                if (!$target) throw new RuntimeException('No se encontró el usuario.');
                if ($target['role'] === 'admin') throw new RuntimeException('Los administradores tienen acceso a todos los escenarios automáticamente.');
                $scenarioIds = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['scenario_ids'] ?? [])), static fn($v) => $v > 0)));
                $pdo->beginTransaction();
                $pdo->prepare('DELETE FROM scenario_user_access WHERE user_id=?')->execute([$id]);
                $insert = $pdo->prepare('INSERT INTO scenario_user_access (user_id,scenario_id) SELECT ?,id FROM scenarios WHERE id=?');
                foreach ($scenarioIds as $sid) $insert->execute([$id,$sid]);
                $pdo->commit();
                $notice = 'Permisos de escenarios guardados.';
            } else {
                throw new RuntimeException('Acción desconocida.');
            }
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = str_contains(strtolower($e->getMessage()), 'duplicate') ? 'Ese correo ya está registrado.' : 'No se pudo guardar. Verifica los datos e inténtalo otra vez.';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $e->getMessage();
        }
    }
}

$scenarios = $pdo->query('SELECT id,name,width_m,depth_m,updated_at FROM scenarios ORDER BY name,id')->fetchAll();
$users = $pdo->query('SELECT id,name,email,role,is_active,last_login_at,created_at FROM users ORDER BY role DESC,name ASC')->fetchAll();
$grants = [];
foreach ($pdo->query('SELECT user_id,scenario_id FROM scenario_user_access') as $grant) $grants[(int)$grant['user_id']][] = (int)$grant['scenario_id'];
$initialFor = static function (string $name): string {
    $first = function_exists('mb_substr') ? mb_substr($name, 0, 1, 'UTF-8') : substr($name, 0, 1);
    return function_exists('mb_strtoupper') ? mb_strtoupper($first, 'UTF-8') : strtoupper($first);
};
?>
<!doctype html>
<html lang="es"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#f4f7fb"><title>Administración | Aula 3D</title>
<style>
:root{font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:#17243a;background:#f3f6fb}*{box-sizing:border-box}body{margin:0;background:#f3f6fb}.top{height:70px;background:#fff;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;padding:0 max(22px,calc((100vw - 1240px)/2));gap:16px}.brand{display:flex;align-items:center;gap:11px}.mark{height:40px;width:40px;display:grid;place-items:center;border-radius:13px;background:linear-gradient(140deg,#1459a5,#4d98df);color:#fff;font-weight:950}.brand b{display:block}.brand small{display:block;color:#7c8a9d;margin-top:2px}.top-actions{display:flex;align-items:center;gap:9px}.btn{display:inline-flex;justify-content:center;align-items:center;gap:7px;border:1px solid #d8e1ec;background:#fff;color:#254461;text-decoration:none;border-radius:9px;padding:9px 13px;font-size:12px;font-weight:800;cursor:pointer}.btn.primary{background:#1d62ad;border-color:#1d62ad;color:#fff}.btn.soft{background:#f1f6fc;border-color:#e1eaf4;color:#315779}.btn.danger{color:#a8322b;background:#fff7f6;border-color:#f0d0cd}.wrap{max-width:1240px;margin:30px auto;padding:0 22px}.intro{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin-bottom:22px}.intro h1{font-size:27px;letter-spacing:-.6px;margin:0 0 6px}.intro p{color:#718096;margin:0;font-size:13px}.session{font-size:12px;color:#7b8798}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:13px;margin-bottom:22px}.stat{background:#fff;border:1px solid #e1e8f0;border-radius:14px;padding:15px 17px;display:flex;align-items:center;gap:13px}.stat-icon{height:42px;width:42px;display:grid;place-items:center;border-radius:12px;background:#edf5ff;color:#2468ae;font-size:20px}.stat small{color:#77879b;font-size:11px}.stat b{display:block;font-size:24px;margin-top:2px}.notice,.error{padding:12px 14px;border-radius:10px;margin-bottom:15px;font-size:13px}.notice{background:#eaf7ef;color:#17643a;border:1px solid #ccebd7}.error{background:#fff0ef;color:#a32d27;border:1px solid #f3cfcb}.tabs{display:flex;gap:6px;align-items:center;border-bottom:1px solid #dfe6ef;margin-bottom:17px;overflow:auto}.tab{background:transparent;border:0;border-bottom:3px solid transparent;padding:12px 15px 13px;color:#718198;font:inherit;font-size:13px;font-weight:800;white-space:nowrap;cursor:pointer}.tab.active{color:#1c5d9e;border-color:#2676bd}.tab-panel{display:none}.tab-panel.active{display:block}.panel{background:#fff;border:1px solid #e1e8f0;border-radius:15px;padding:20px;box-shadow:0 5px 20px #1d345409}.panel-head{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:15px}.panel-head h2{font-size:17px;margin:0 0 4px}.panel-head p{color:#7b889a;font-size:12px;margin:0}.head-actions{display:flex;align-items:center;gap:9px}.search{width:min(260px,40vw);padding:10px 12px;border:1px solid #dbe3ec;border-radius:9px;font:inherit;font-size:12px;outline:0}.search:focus{border-color:#4b90d1;box-shadow:0 0 0 3px #4b90d11d}.table-wrap{width:100%;overflow:auto;border:1px solid #e7edf4;border-radius:11px}table{width:100%;border-collapse:collapse;min-width:700px;background:#fff}th{background:#f7f9fc;color:#6c7c91;font-size:10px;text-transform:uppercase;letter-spacing:.7px;font-weight:900;text-align:left;padding:12px 14px;border-bottom:1px solid #e7edf4}td{padding:13px 14px;border-bottom:1px solid #edf1f5;color:#33465e;font-size:12px;vertical-align:middle}tr:last-child td{border-bottom:0}.person{display:flex;align-items:center;gap:10px}.avatar{height:34px;width:34px;flex:0 0 auto;border-radius:11px;background:#edf4fc;color:#245e9b;display:grid;place-items:center;font-weight:900;font-size:12px}.person b{display:block;color:#21364e;font-size:12px}.person small{color:#8794a5;display:block;margin-top:3px}.pill{display:inline-flex;align-items:center;border-radius:100px;padding:5px 8px;font-size:10px;font-weight:900;background:#eef4fb;color:#416184}.pill.admin{background:#eaf1ff;color:#225da6}.pill.on{background:#eaf7ef;color:#1c804a}.pill.off{background:#fff0ef;color:#b53b33}.row-actions{display:flex;gap:6px;justify-content:flex-end;white-space:nowrap}.icon-btn{border:1px solid #dce5ef;background:#fff;color:#34516f;border-radius:8px;padding:7px 9px;font-size:11px;font-weight:800;cursor:pointer}.icon-btn:hover{background:#f0f6fc}.empty{padding:36px;text-align:center;color:#8190a2;font-size:13px}.empty b{display:block;color:#354a62;margin-bottom:5px}.summary-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:14px}.welcome{background:linear-gradient(120deg,#123e70,#2676b7);color:white;border-radius:15px;padding:24px;min-height:190px;position:relative;overflow:hidden}.welcome:after{content:"3D";position:absolute;right:25px;bottom:-48px;font-size:170px;line-height:1;font-weight:950;color:#ffffff0d}.welcome small{letter-spacing:1.4px;color:#b6dcff;font-size:10px;font-weight:900}.welcome h2{font-size:25px;max-width:440px;margin:11px 0 8px;letter-spacing:-.5px}.welcome p{max-width:460px;color:#d7eaff;font-size:13px;line-height:1.6;margin:0}.quick{display:flex;flex-direction:column;gap:9px}.quick a,.quick button{width:100%;min-height:52px;justify-content:flex-start}.mini-note{margin-top:14px;background:#f6f9fc;border:1px solid #e6edf4;border-radius:11px;padding:14px;color:#738196;font-size:12px;line-height:1.55}.muted{color:#8492a4;font-size:11px}.count{font-variant-numeric:tabular-nums;font-weight:850;color:#2c5276}.dialog{width:min(560px,calc(100vw - 28px));max-height:88vh;overflow:auto;padding:0;border:0;border-radius:17px;box-shadow:0 25px 80px #12294455;color:#20354c}.dialog::backdrop{background:#0e223b88;backdrop-filter:blur(3px)}.dialog-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding:19px 21px;border-bottom:1px solid #e8edf3}.dialog-head h3{margin:0 0 4px;font-size:17px}.dialog-head p{margin:0;color:#8390a1;font-size:12px}.close{border:0;background:#f1f4f8;color:#52667d;border-radius:8px;height:30px;width:30px;font-size:18px;cursor:pointer}.dialog-body{padding:20px 21px}.dialog-foot{display:flex;justify-content:flex-end;gap:8px;padding:14px 21px;border-top:1px solid #e8edf3;background:#fbfcfe}.field{display:block;font-size:12px;font-weight:800;color:#43566d;margin:12px 0 6px}.field:first-child{margin-top:0}.field input,.field select{display:block;width:100%;margin-top:7px;padding:11px 12px;border:1px solid #d8e1ec;border-radius:9px;font:inherit;font-size:13px;color:#1b2c42;background:#fcfdff}.field input:focus,.field select:focus{outline:0;border-color:#438bd0;box-shadow:0 0 0 3px #438bd01b}.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.checkline{display:flex;align-items:center;gap:8px;font-size:12px;color:#465970;margin:13px 0}.access-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.access-option{display:flex;align-items:flex-start;gap:8px;padding:10px;border:1px solid #e6edf4;background:#f8fafc;border-radius:9px;font-size:12px;color:#3d526c}.access-option input{margin-top:2px}.access-option small{display:block;color:#8995a5;font-size:10px;margin-top:3px}.dialog-section{padding:13px;background:#f7f9fc;border:1px solid #e7edf4;border-radius:10px;margin-top:12px}.dialog-section strong{font-size:12px}.hint{font-size:11px;color:#8491a2;line-height:1.5;margin:6px 0 0}
@media(max-width:760px){.top{height:auto;padding:13px 16px;align-items:flex-start}.brand small{display:none}.top-actions{flex-wrap:wrap;justify-content:flex-end}.wrap{padding:0 14px;margin:22px auto}.intro{align-items:flex-start;flex-direction:column}.stats{gap:8px}.stat{padding:12px;gap:9px}.stat-icon{height:34px;width:34px}.stat b{font-size:20px}.summary-grid{grid-template-columns:1fr}.panel{padding:14px}.panel-head{align-items:flex-start;flex-direction:column}.head-actions{width:100%}.search{width:100%}.access-grid{grid-template-columns:1fr}.two{grid-template-columns:1fr}}
@media(max-width:480px){.top{flex-direction:column}.top-actions{width:100%;justify-content:flex-start}.stats{grid-template-columns:1fr}.stat{min-height:64px}.stat-icon{height:38px;width:38px}.intro h1{font-size:23px}.dialog{max-height:92vh}}
</style></head>
<body>
<header class="top"><div class="brand"><div class="mark">3D</div><div><b>Administración de Aula 3D</b><small>Gestión del espacio de trabajo</small></div></div><nav class="top-actions"><a class="btn soft" href="./portal.php">↗ Portal</a><a class="btn soft" href="./index.php">▦ Editor</a><form method="post" action="./logout.php"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><button class="btn danger" type="submit">Cerrar sesión</button></form></nav></header>
<main class="wrap">
<section class="intro"><div><h1>Panel de administración</h1><p>Gestiona las cuentas, los permisos y los escenarios desde secciones independientes.</p></div><span class="session">Administrador: <b><?=h($me['name'])?></b></span></section>
<?php if($notice):?><div class="notice">✓ <?=h($notice)?></div><?php endif;?><?php if($error):?><div class="error">! <?=h($error)?></div><?php endif;?>
<section class="stats">
 <article class="stat"><div class="stat-icon">♙</div><div><small>Usuarios registrados</small><b><?=count($users)?></b></div></article>
 <article class="stat"><div class="stat-icon">▦</div><div><small>Escenarios creados</small><b><?=count($scenarios)?></b></div></article>
 <article class="stat"><div class="stat-icon">✓</div><div><small>Cuentas activas</small><b><?=count(array_filter($users,static fn($u)=>(int)$u['is_active']===1))?></b></div></article>
</section>
<nav class="tabs" aria-label="Secciones de administración">
 <button class="tab" data-tab="overview" type="button">Resumen</button><button class="tab" data-tab="users" type="button">Usuarios</button><button class="tab" data-tab="access" type="button">Permisos de acceso</button><button class="tab" data-tab="scenarios" type="button">Escenarios</button>
</nav>
<section class="tab-panel" id="tab-overview"><div class="summary-grid"><div class="welcome"><small>CONTROL CENTRAL · AULA 3D</small><h2>Tu espacio de trabajo, organizado.</h2><p>Administra quién puede entrar y qué entornos puede explorar. Los usuarios autorizados ingresan al portal directamente en modo de recorrido.</p></div><div class="panel"><div class="panel-head"><div><h2>Acciones rápidas</h2><p>Accede a las tareas más frecuentes.</p></div></div><div class="quick"><button class="btn primary" type="button" data-open="create-user">＋ Crear nuevo usuario</button><button class="btn" type="button" data-go-tab="users">♙ Administrar usuarios</button><button class="btn" type="button" data-go-tab="access">⌑ Configurar permisos</button><a class="btn" href="./portal.php">▷ Abrir portal de escenarios</a></div></div></div><div class="mini-note">Los permisos se administran por usuario. Cada persona solo verá en el portal los escenarios que tenga asignados; los administradores mantienen acceso a todos.</div></section>
<section class="tab-panel" id="tab-users"><div class="panel"><div class="panel-head"><div><h2>Usuarios</h2><p>Datos de cuenta, rol y estado. Las modificaciones se realizan en ventanas independientes.</p></div><div class="head-actions"><input class="search" id="user-search" type="search" placeholder="Buscar por nombre o correo"><button class="btn primary" type="button" data-open="create-user">＋ Nuevo usuario</button></div></div>
<?php if(!$users):?><div class="empty"><b>No hay cuentas registradas</b>Crea el primer usuario para habilitar el acceso.</div><?php else:?>
<div class="table-wrap"><table id="users-table"><thead><tr><th>Usuario</th><th>Rol</th><th>Estado</th><th>Último acceso</th><th style="text-align:right">Acciones</th></tr></thead><tbody>
<?php foreach($users as $u): $uid=(int)$u['id']; $userGrants=$grants[$uid]??[]; $initials=$initialFor((string)$u['name']); ?>
<tr data-search="<?=h(strtolower($u['name'].' '.$u['email']))?>"><td><div class="person"><div class="avatar"><?=h($initials)?></div><div><b><?=h($u['name'])?></b><small><?=h($u['email'])?></small></div></div></td><td><span class="pill <?=h($u['role'])?>"><?=h($u['role']==='admin'?'Administrador':'Usuario')?></span></td><td><span class="pill <?=((int)$u['is_active']===1?'on':'off')?>"><?=((int)$u['is_active']===1?'Activo':'Desactivado')?></span></td><td><?=h($u['last_login_at']?:'Nunca')?></td><td><div class="row-actions"><button class="icon-btn" type="button" data-open="edit-user-<?=$uid?>">Editar</button><button class="icon-btn" type="button" data-open="password-user-<?=$uid?>">Contraseña</button></div></td></tr>
<?php endforeach;?></tbody></table></div><?php endif;?></div></section>
<section class="tab-panel" id="tab-access"><div class="panel"><div class="panel-head"><div><h2>Permisos de acceso</h2><p>Asigna los escenarios disponibles a cada cuenta de usuario.</p></div><input class="search" id="access-search" type="search" placeholder="Buscar usuario"></div>
<?php if(!$users):?><div class="empty"><b>No hay usuarios</b>Primero debes crear una cuenta.</div><?php else:?>
<div class="table-wrap"><table id="access-table"><thead><tr><th>Usuario</th><th>Tipo de cuenta</th><th>Escenarios habilitados</th><th style="text-align:right">Administrar</th></tr></thead><tbody>
<?php foreach($users as $u): $uid=(int)$u['id']; $userGrants=$grants[$uid]??[]; $grantCount=$u['role']==='admin'?count($scenarios):count($userGrants); ?>
<tr data-search="<?=h(strtolower($u['name'].' '.$u['email']))?>"><td><div class="person"><div class="avatar"><?=h($initialFor((string)$u['name']))?></div><div><b><?=h($u['name'])?></b><small><?=h($u['email'])?></small></div></div></td><td><span class="pill <?=h($u['role'])?>"><?=h($u['role']==='admin'?'Administrador':'Usuario')?></span></td><td><span class="count"><?=$u['role']==='admin'?'Todos':$grantCount?></span> <span class="muted"><?=$u['role']==='admin'?'Acceso automático':'escenario(s)'?></span></td><td><div class="row-actions"><button class="icon-btn" type="button" data-open="access-user-<?=$uid?>">Gestionar permisos</button></div></td></tr>
<?php endforeach;?></tbody></table></div><?php endif;?></div></section>
<section class="tab-panel" id="tab-scenarios"><div class="panel"><div class="panel-head"><div><h2>Escenarios disponibles</h2><p>Inventario de espacios publicados en el portal de recorridos.</p></div><span class="pill"><?=count($scenarios)?> registrados</span></div>
<?php if(!$scenarios):?><div class="empty"><b>Aún no hay escenarios</b>Guarda un escenario desde el editor para que aparezca aquí.</div><?php else:?>
<div class="table-wrap"><table><thead><tr><th>Escenario</th><th>Dimensiones</th><th>Identificador</th><th>Última actualización</th><th>Acceso</th></tr></thead><tbody>
<?php foreach($scenarios as $s):?><tr><td><div class="person"><div class="avatar">▦</div><div><b><?=h($s['name'])?></b><small>Escenario 3D</small></div></div></td><td><?=h($s['width_m'])?> × <?=h($s['depth_m'])?> m</td><td>#<?= (int)$s['id']?></td><td><?=h($s['updated_at']?:'—')?></td><td><span class="pill on">Disponible</span></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></div></section>
</main>

<dialog class="dialog" id="create-user"><div class="dialog-head"><div><h3>Crear usuario</h3><p>Registra una cuenta y define su nivel de acceso.</p></div><button class="close" type="button" data-close>×</button></div><form method="post" action="./admin.php?tab=users"><div class="dialog-body"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="create_user"><label class="field">Nombre completo<input name="name" maxlength="120" placeholder="Nombre y apellidos" required></label><label class="field">Correo electrónico<input name="email" type="email" maxlength="190" placeholder="usuario@empresa.com" required></label><label class="field">Contraseña inicial<input name="password" type="password" minlength="10" placeholder="Mínimo 10 caracteres" required></label><label class="field">Rol<select name="role"><option value="user">Usuario · solo recorrer escenarios</option><option value="admin">Administrador · control completo</option></select></label><p class="hint">Después de crear la cuenta, podrás asignarle los escenarios habilitados desde la sección Permisos de acceso.</p></div><div class="dialog-foot"><button class="btn" type="button" data-close>Cancelar</button><button class="btn primary" type="submit">Crear cuenta</button></div></form></dialog>

<?php foreach($users as $u): $uid=(int)$u['id']; $userGrants=$grants[$uid]??[]; ?>
<dialog class="dialog" id="edit-user-<?=$uid?>"><div class="dialog-head"><div><h3>Editar usuario</h3><p>Actualiza los datos y el estado de esta cuenta.</p></div><button class="close" type="button" data-close>×</button></div><form method="post" action="./admin.php?tab=users"><div class="dialog-body"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="save_user"><input type="hidden" name="user_id" value="<?=$uid?>"><label class="field">Nombre completo<input name="name" maxlength="120" value="<?=h($u['name'])?>" required></label><label class="field">Correo electrónico<input name="email" type="email" maxlength="190" value="<?=h($u['email'])?>" required></label><label class="field">Rol<select name="role" <?=($uid===(int)$me['id']?'disabled':'')?>><option value="user" <?=$u['role']==='user'?'selected':''?>>Usuario</option><option value="admin" <?=$u['role']==='admin'?'selected':''?>>Administrador</option></select></label><?php if($uid===(int)$me['id']):?><input type="hidden" name="role" value="admin"><input type="hidden" name="is_active" value="1"><p class="hint">No puedes cambiar tu propio rol ni desactivar tu cuenta.</p><?php else:?><label class="checkline"><input type="checkbox" name="is_active" value="1" <?=((int)$u['is_active']===1?'checked':'')?>> Cuenta activa</label><?php endif;?></div><div class="dialog-foot"><button class="btn" type="button" data-close>Cancelar</button><button class="btn primary" type="submit">Guardar cambios</button></div></form></dialog>
<dialog class="dialog" id="password-user-<?=$uid?>"><div class="dialog-head"><div><h3>Restablecer contraseña</h3><p><?=h($u['name'])?> · <?=h($u['email'])?></p></div><button class="close" type="button" data-close>×</button></div><form method="post" action="./admin.php?tab=users"><div class="dialog-body"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="reset_password"><input type="hidden" name="user_id" value="<?=$uid?>"><label class="field">Nueva contraseña<input name="password" type="password" minlength="10" placeholder="Mínimo 10 caracteres" required></label><p class="hint">La contraseña anterior dejará de funcionar inmediatamente.</p></div><div class="dialog-foot"><button class="btn" type="button" data-close>Cancelar</button><button class="btn primary" type="submit">Actualizar contraseña</button></div></form></dialog>
<dialog class="dialog" id="access-user-<?=$uid?>"><div class="dialog-head"><div><h3>Permisos de escenarios</h3><p><?=h($u['name'])?> · define qué escenarios puede recorrer.</p></div><button class="close" type="button" data-close>×</button></div>
<?php if($u['role']==='admin'):?><div class="dialog-body"><div class="dialog-section"><strong>Acceso completo</strong><p class="hint">Esta cuenta tiene rol de administrador y accede automáticamente a todos los escenarios. No requiere asignaciones individuales.</p></div></div><div class="dialog-foot"><button class="btn" type="button" data-close>Cerrar</button></div>
<?php else:?><form method="post" action="./admin.php?tab=access"><div class="dialog-body"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="save_access"><input type="hidden" name="user_id" value="<?=$uid?>"><div class="inline" style="display:flex;justify-content:space-between;margin-bottom:12px"><strong style="font-size:12px">Selecciona escenarios</strong><span class="muted"><?=count($userGrants)?> asignado(s)</span></div>
<?php if(!$scenarios):?><div class="empty">No hay escenarios guardados todavía.</div><?php else:?><div class="access-grid"><?php foreach($scenarios as $s):?><label class="access-option"><input type="checkbox" name="scenario_ids[]" value="<?= (int)$s['id']?>" <?=in_array((int)$s['id'],$userGrants,true)?'checked':''?>><span><b><?=h($s['name'])?></b><small>#<?= (int)$s['id']?> · <?=h($s['width_m'])?> × <?=h($s['depth_m'])?> m</small></span></label><?php endforeach;?></div><?php endif;?></div><div class="dialog-foot"><button class="btn" type="button" data-close>Cancelar</button><?php if($scenarios):?><button class="btn primary" type="submit">Guardar permisos</button><?php endif;?></div></form><?php endif;?></dialog>
<?php endforeach;?>
<script>
(() => {
 const allowed = ['overview','users','access','scenarios'];
 const initial = <?=json_encode(in_array($_GET['tab']??'', ['overview','users','access','scenarios'], true) ? $_GET['tab'] : 'overview')?>;
 function activate(name, updateUrl=true) {
   const tab = allowed.includes(name) ? name : 'overview';
   document.querySelectorAll('[data-tab]').forEach(el => el.classList.toggle('active', el.dataset.tab===tab));
   document.querySelectorAll('.tab-panel').forEach(el => el.classList.toggle('active', el.id===`tab-${tab}`));
   if(updateUrl){const url=new URL(location.href);url.searchParams.set('tab',tab);history.replaceState({},'',url);}
 }
 document.querySelectorAll('[data-tab]').forEach(btn=>btn.addEventListener('click',()=>activate(btn.dataset.tab)));
 document.querySelectorAll('[data-go-tab]').forEach(btn=>btn.addEventListener('click',()=>activate(btn.dataset.goTab)));
 document.querySelectorAll('[data-open]').forEach(btn=>btn.addEventListener('click',()=>document.getElementById(btn.dataset.open)?.showModal()));
 document.querySelectorAll('[data-close]').forEach(btn=>btn.addEventListener('click',()=>btn.closest('dialog')?.close()));
 document.querySelectorAll('dialog').forEach(dialog=>dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();}));
 function filterRows(inputId,tableId){const input=document.getElementById(inputId),table=document.getElementById(tableId);if(!input||!table)return;input.addEventListener('input',()=>{const q=input.value.trim().toLowerCase();table.querySelectorAll('tbody tr').forEach(row=>row.hidden=!row.dataset.search?.includes(q));});}
 filterRows('user-search','users-table');filterRows('access-search','access-table');activate(initial,false);
})();
</script>
</body></html>
